﻿using Monster.JobAds.CommandCenter.Web.Models.Reporting;
using Monster.JobAds.Reporting.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Monster.JobAds.CommandCenter.Web.Helpers
{
    internal static class ReportHelper
    {
        internal static bool ValidationFailed(ReportRequest reportsRequest, out List<ReportErrorModel> errors)
        {
            errors = new List<ReportErrorModel>();
            if (reportsRequest == null)
            {
                errors.Add(new ReportErrorModel("Required Fields Missing.", "Required_Missing"));
                return true;
            }
            else
            {
                bool validationFailed = false;
                if (reportsRequest.ProviderID == 0)
                {
                    errors.Add(new ReportErrorModel("ProviderID", "ProviderID_Required."));
                    validationFailed = true;
                }
                if (reportsRequest.ReportStartDate == DateTime.MinValue)
                {
                    errors.Add(new ReportErrorModel("ReportStartDate", "ReportStartDate_Required."));
                    validationFailed = true;
                }
                if (reportsRequest.ReportEndDate == DateTime.MinValue)
                {
                    errors.Add(new ReportErrorModel("ReportEndDate", "ReportEndDate_Required."));
                    validationFailed = true;
                }
                if (reportsRequest.IntervalBreakDown == 0)
                {
                    errors.Add(new ReportErrorModel("IntervalBreakdown", "IntervalBreakdown_Required."));
                    validationFailed = true;
                }
                if (reportsRequest.ReportType == 0)
                {
                    errors.Add(new ReportErrorModel("ReportType", "ReportType_Required."));
                    validationFailed = true;
                }
                if (reportsRequest.DataPointsRequested == null || reportsRequest.DataPointsRequested.Count == 0)
                {
                    errors.Add(new ReportErrorModel("DataPoints", "DataPoints_Required."));
                    validationFailed = true;
                }
                else
                {
                    if (reportsRequest.DataPointsRequested.Any(a => a == 0))
                    {
                        errors.Add(new ReportErrorModel("DataPoints", "Invalid_DataPoint"));
                        validationFailed = true;
                    }
                }
                return validationFailed;
            }
        }

        internal static List<ReportDetails> FormatReponseToModel(List<ReportingData> reportData, ReportRequest reportRequest)
        {
            List<ReportDetails> objReportDetails = new List<ReportDetails>();
            if (reportData != null && reportData.Any())
            {
                if (reportRequest.ReportType == ReportType.ProviderByJob)
                {
                    objReportDetails = reportData.Select(a => new ReportDetails
                    {
                        ProviderName = a.ProviderName,
                        JobID = a.JobID,
                        JobAdRefCode = a.JobAdRefCode,
                        JobTitle = a.JobTitle,
                        ActiveDate = a.ActiveDate,
                        DaysActive = a.DaysActive,
                        CPC = a.Cpc,
                        DateMonthValue = a.DateMonthValue,
                        Clicks = a.Clicks,
                        Company = a.Company,
                        CityName = a.CityName,
                        StateAbbrev = a.StateAbbrev,
                        LocationID = a.LocationID,
                        Soc3OccupationTitle = a.Soc3OccupationTitle,
                        CampaignID = a.CampaignID,
                        CampaignName = a.CampaignName,
                        DaysInCampaign = a.DaysInCampaign,
                        RecommendedCPC = a.RecommendedCPC,
                        Spend = a.Spend,
                        CampaignBudget = a.CampaignBudget,
                    }).ToList();
                }
                else if (reportRequest.ReportType == ReportType.Provider)
                {
                    objReportDetails = reportData.Select(a => new ReportDetails
                    {
                        ProviderName = a.ProviderName,
                        CPC = a.Cpc,
                        DateMonthValue = a.DateMonthValue,
                        Clicks = a.Clicks,
                        Company = a.Company,
                        CityName = a.CityName,
                        StateAbbrev = a.StateAbbrev,
                        LocationID = a.LocationID,
                        Soc3OccupationTitle = a.Soc3OccupationTitle,
                        CampaignID = a.CampaignID,
                        CampaignName = a.CampaignName,
                        RecommendedCPC = a.RecommendedCPC,
                        Spend = a.Spend,
                        CampaignBudget = a.CampaignBudget,
                    }).ToList();
                }
            }
            return objReportDetails;
        }
    }
}