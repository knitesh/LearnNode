﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Monster.JobAds.CommandCenter.Web.Models.Reporting
{
    [DataContract]
    public class ReportModel
    {
        [DataMember(Name="reportdetails")]
        public List<ReportDetails> ReportDetails { get; set; }

        public ReportModel()
        {
            ReportDetails = new List<ReportDetails>();
        }
    }

    [DataContract]
    public class ReportDetails
    {
        [DataMember(Name = "providername", Order = 1)]
        public string ProviderName { get; set; }

        [DataMember(Name = "jobtitle", Order = 2)]
        public string JobTitle { get; set; }

        [DataMember(Name = "jobadrefcode", Order = 3)]
        public string JobAdRefCode { get; set; }

        [DataMember(Name = "jobid", Order = 4)]
        public long? JobID { get; set; }

        [DataMember(Name = "activedate", Order = 5)]
        public string ActiveDate { get; set; }

        [DataMember(Name = "daysactive", Order = 6)]
        public int? DaysActive { get; set; }

        [DataMember(Name = "daysincampaign", Order = 7)]
        public int? DaysInCampaign { get; set; }

        [DataMember(Name = "clicks", Order = 8)]
        public int? Clicks { get; set; }

        [DataMember(Name = "recommendedcpc", Order = 9)]
        public decimal? RecommendedCPC { get; set; }

        [DataMember(Name = "cpc", Order = 10)]
        public decimal? CPC { get; set; }

        [DataMember(Name = "company", Order = 11)]
        public string Company { get; set; }

        [DataMember(Name = "campaignname", Order = 12)]
        public string CampaignName { get; set; }

        [DataMember(Name = "campaignid", Order = 13)]
        public long? CampaignID { get; set; }

        [DataMember(Name = "campaignbudget", Order = 14)]
        public decimal? CampaignBudget { get; set; }

        [DataMember(Name = "spend", Order = 15)]
        public decimal? Spend { get; set; }

        [DataMember(Name = "cityname", Order = 16)]
        public string CityName { get; set; }

        [DataMember(Name = "state", Order = 17)]
        public string StateAbbrev { get; set; }

        [DataMember(Name = "locationid", Order = 18)]
        public long? LocationID { get; set; }

        [DataMember(Name = "soc3", Order = 19)]
        public string Soc3OccupationTitle { get; set; }

        [DataMember(Name = "datemonthvalue", Order = 20)]
        public string DateMonthValue { get; set; }
    }
}