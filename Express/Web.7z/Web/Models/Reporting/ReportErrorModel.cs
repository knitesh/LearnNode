﻿
using System.Runtime.Serialization;
namespace Monster.JobAds.CommandCenter.Web.Models.Reporting
{
    [DataContract]
    public class ReportErrorModel
    {
        public ReportErrorModel()
        {

        }

        public ReportErrorModel(string errorMessage, string errorCode)
        {
            ErrorMessage = errorMessage;
            ErrorCode = errorCode;
        }

        [DataMember(Name = "errormessage")]
        public string ErrorMessage { get; set; }

        [DataMember(Name = "errorcode")]
        public string ErrorCode { get; set; }
    }
}