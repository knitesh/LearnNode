﻿using System;
using Microsoft.Owin;
using Microsoft.Owin.Security.ActiveDirectory;
using Monster.GlobalFramework.Core.Util;
using Monster.JobAds.Authentication.AD;
using Monster.JobAds.CommandCenter.Web;
using Monster.JobAds.Logging;
using Owin;
using System.IdentityModel.Tokens;

[assembly: OwinStartup(typeof(OwinStartup))]

namespace Monster.JobAds.CommandCenter.Web
{
    public class OwinStartup
    {
        public void Configuration(IAppBuilder app)
        {
            string envName = AwsUtil.envName;
            AppConfig appConfig = AppConfigFactory.Current.Retrieve(AppConfigFactory.CommandCenterAppName, envName);
            if (appConfig == null)
            {
                throw new Exception($"Configuration failed. Reason: Monster.JobAds.Authentication.AD.AppConfig could not be retrieve for appName {AppConfigFactory.CommandCenterAppName}, envName {envName}.");
            }

            IJobAdsLogger logger = JobAdsLogFactory.Current.GetLogger();
            logger.LogInfo("UseWindowsAzureActiveDirectoryBearerAuthentication configuration set with Tenant {0}.", appConfig.Tenant);


            //MonsterADAuthenticationFacade facade = new MonsterADAuthenticationFacade();
            //facade.Initialize(app, AppConfigFactory.CommandCenterAppName, AwsUtil.envName);

            app.UseWindowsAzureActiveDirectoryBearerAuthentication(
                           new WindowsAzureActiveDirectoryBearerAuthenticationOptions
                           {
                               Tenant = appConfig.Tenant,
                               TokenValidationParameters = new TokenValidationParameters { ValidAudience = appConfig.ClientID }
                           });
        }
    }
}
