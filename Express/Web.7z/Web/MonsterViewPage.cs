﻿using System.Web;
using System.Web.Mvc;
using Monster.JobAds.Authentication.AD;
using Monster.JobAds.Configuration.AppConfigs;
using Monster.JobAds.Helpers;
using AppConfigFactory = Monster.JobAds.Authentication.AD.AppConfigFactory;
using IAppConfigFactory = Monster.JobAds.Authentication.AD.IAppConfigFactory;

namespace Monster.JobAds.CommandCenter.Web
{
    //TODO: ksoderst - Move helpers to Context facade
    //TODO: ksoderst - add unit_test

    public class MonsterViewPage<T> : WebViewPage<T>
    {
        private readonly ScriptControlHelper _scriptControlHelper;
        private IAppConfigFactory _appConfigFactory;
        
        public MonsterViewPage()
        {
            _scriptControlHelper = new ScriptControlHelper();  
        }

        public override void Execute()
        {
        }

        public ScriptControlHelper ScriptControlHelper
        {
            get { return _scriptControlHelper; }
        }

        public IHtmlString Msg(string msgAlias, string defaultText)
        {
            return Msg(msgAlias, defaultText, null/*replacementValues*/);
        }
        public IHtmlString Msg(string msgAlias, string defaultText, object replacementValues)
        {
            return Html.Msg(msgAlias, defaultText, replacementValues);
        }

        public bool RequiresAuthentication
        {

            get
            {
                string s;
                bool value = !(AppConfigHelper.TryGetAppConfig("RequiresAuthentication", out s) && s == "false");
                return value;
            }
        }

        public AppConfig ADAppConfig
        {
            get
            {
                if (_appConfigFactory == null)
                {
                    _appConfigFactory = AppConfigFactory.Current;
                }
                return _appConfigFactory.Retrieve(AppConfigFactory.CommandCenterAppName);
            }
        }
    }

    public class MonsterViewPage : WebViewPage
    {
        private readonly ScriptControlHelper _scriptControlHelper;
        private IAppConfigFactory _appConfigFactory;

        public MonsterViewPage()
        {
            _scriptControlHelper = new ScriptControlHelper();
        }

        public override void Execute()
        {
        }

        public ScriptControlHelper ScriptControlHelper
        {
            get { return _scriptControlHelper; }
        }

        public IHtmlString Msg(string msgAlias, string defaultText)
        {
            return Msg(msgAlias, defaultText, null/*replacementValues*/);
        }
        public IHtmlString Msg(string msgAlias, string defaultText, object replacementValues)
        {
            return Html.Msg(msgAlias, defaultText, replacementValues);
        }

        public AppConfig ADAppConfig
        {
            get
            {
                if (_appConfigFactory == null)
                {
                    _appConfigFactory = AppConfigFactory.Current;
                }
                return _appConfigFactory.Retrieve(AppConfigFactory.CommandCenterAppName);
            }
        }

        public bool RequiresAuthentication
        {

            get
            {
                string s;
                bool value = !(AppConfigHelper.TryGetAppConfig("RequiresAuthentication", out s) && s == "false");
                return value;
            }
        }
    }
}