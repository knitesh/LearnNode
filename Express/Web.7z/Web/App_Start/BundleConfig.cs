﻿using System.Web.Optimization;

namespace Monster.JobAds.CommandCenter.Web.App_Start
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.UseCdn = true;   //enable CDN support

            //add link to bootstrap on the CDN
            var bootstrapCdnPath = "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css";
            var fontAwesomeCdnPath = "https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css";

            // libraries will be requested from the CDN while in release mode and the debug version will be fetched locally in debug mode
            bundles.Add(new StyleBundle("~/bundles/bootstrap", bootstrapCdnPath).Include("~/Content/release/bootstrap.css"));
            bundles.Add(new StyleBundle("~/bundles/fontawesome", fontAwesomeCdnPath).Include("~/Content/release/font-awesome.css"));
            bundles.Add(new StyleBundle("~/bundles/selectize").Include("~/Content/release/selectize.bootstrap3.css"));
            bundles.Add(new StyleBundle("~/bundles/chosen").Include("~/Content/release/chosen.css"));
            bundles.Add(new StyleBundle("~/bundles/bootstrap-datepicker").Include("~/Content/release/bootstrap-datepicker3.css"));
            bundles.Add(new StyleBundle("~/bundles/toastr").Include("~/Content/release/toastr.min.css"));



            // Command Center styles
            bundles.Add(new StyleBundle("~/bundles/commandcenter").Include("~/Content/release/commandcenter.css"));
        }
    }
}
