﻿using Monster.JobAds.Mvc;
using Monster.JobAds.Mvc.Filters;
using System.Web.Mvc;

namespace Monster.JobAds.CommandCenter.Web.App_Start
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new CustomRequiresHttpsAttribute { LocalHostSslPort = 44301});
            filters.Add(new NoCacheAttribute());
            filters.Add(new XFrameFilter());
        }
    }
}
