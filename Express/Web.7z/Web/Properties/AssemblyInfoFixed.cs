﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Monster.JobAds.CommandCenter.Web.Tests")]