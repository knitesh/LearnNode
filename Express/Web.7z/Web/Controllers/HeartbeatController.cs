﻿using System;
using System.Globalization;
using System.Text;
//using System.Web;
using System.Web.Mvc;

namespace Monster.JobAds.CommandCenter.Web.Controllers
{
    /// <summary>
    /// This is to support the heartbeat for AWS
    /// </summary>
    public class HeartbeatController : Controller
    {
        /// <summary>
        /// GET: /HeartBeat/
        /// </summary>
        /// <returns>version string</returns>
        [AllowAnonymous]
        [Route("heartbeat")]
        public ActionResult Index()
        {
            const string CONTENT_TYPE = "text/html; charset=utf-8";

            ContentResult result = new ContentResult();
            result.ContentType = CONTENT_TYPE;

            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("v:{0}", HttpContext.Application["BUILD_VERSION"]);
            sb.Append("<br />");
            sb.Append(CultureInfo.CurrentCulture.DisplayName);
            sb.Append(" ");
            sb.Append(CultureInfo.CurrentCulture.Name);
            sb.Append("<br />");
            sb.Append(DateTime.Now);
            sb.Append(" ");
            sb.Append(TimeZoneInfo.Local.DisplayName);

            result.Content = sb.ToString();

            return result;
        }
    }
}