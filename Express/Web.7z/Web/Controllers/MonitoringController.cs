﻿using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using Monster.JobAds.CommandCenter.Web.Models.Monitoring;
using Monster.JobAds.Monitoring;

namespace Monster.JobAds.CommandCenter.Web.Controllers
{
    [AllowAnonymous]
    [RoutePrefix("monitoring")]
    [Route("{action=index}")]
    public class MonitoringController : Controller
    {
        private readonly IMonitoringFactory _monitoringFactory;

        public MonitoringController()
        {
            _monitoringFactory = MonitoringFactory.Current;
        }

        internal MonitoringController(IMonitoringFactory monitoringFactory)
        {
            _monitoringFactory = monitoringFactory;
        }

        // GET: /Monitoring/
        [HttpGet]
        [Route("")]
        [Route("index")]
        public ActionResult Index()
        {
            IEnumerable<IMonitor> monitors = _monitoringFactory.GetMonitors();
            MonitoringView model = new MonitoringView();
            bool hasMonitors = monitors != null && monitors.Any();
            if (hasMonitors)
            {
                model.UnSuccessfulMonitors = new List<IResponse>();
                model.SuccessfulMonitors = new List<IResponse>();
                foreach (var dependency in monitors)
                {
                    var response = dependency.GetResponse();
                    if ((int)response.StatusCode != 200)
                    {
                        model.UnSuccessfulMonitors.Add(response);
                    }
                    else
                    {
                        model.SuccessfulMonitors.Add(response);
                    }
                }
            }

            if (model.HasUnSuccessfulMonitors)
            {
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                Response.TrySkipIisCustomErrors = true;
            }
            else
                Response.StatusCode = (int)HttpStatusCode.OK;
            return View("Index", model);
        }
    }
}