﻿using Monster.GlobalFramework.Logging;
using Monster.JobAds.CommandCenter.Web.Helpers;
using Monster.JobAds.CommandCenter.Web.Models.Reporting;
using Monster.JobAds.Logging;
using Monster.JobAds.Reporting.Contracts;
using Monster.JobAds.Reporting.Data.MySql;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Monster.JobAds.CommandCenter.Web.Controllers
{
    [RoutePrefix("api/report")]
    public class ReportController : ApiController
    {
        private readonly IMySqlReportRepository _reportsRepository;
        private readonly ILogger _logger;

        public ReportController(): this(new MySqlReportRepository(), JobAdsLogFactory.Current.GetLogger())
        {

        }

        internal ReportController(IMySqlReportRepository reportsRepository, ILogger logger)
        {
            _reportsRepository = reportsRepository;
            _logger = logger;
        }

        /// <summary>
        /// Get Report
        /// </summary>
        /// <param name="reportsRequest"></param>
        /// <returns></returns>
        [HttpPost]
        public HttpResponseMessage GetReport(ReportRequest reportsRequest)
        {
            HttpResponseMessage response;
            ReportModel reportModel = new ReportModel();
            List<ReportErrorModel> errors = new List<ReportErrorModel>();
            List<ReportingData> reportData = new List<ReportingData>();
            ReportResultThreshold reportResultThreshold = new ReportResultThreshold();
            try
            {
                reportsRequest.ReportEndDate = new DateTime(reportsRequest.ReportEndDate.Year, reportsRequest.ReportEndDate.Month, reportsRequest.ReportEndDate.Day, 23, 59, 59); 
                _logger.LogInfo("Get Report :: Begin with ProviderID {0}", reportsRequest.ProviderID);
                if (!ReportHelper.ValidationFailed(reportsRequest, out errors))
                {
                    #region GetReportCountAndThreshold
                    reportResultThreshold = _reportsRepository.GetReportCountAndThreshold(reportsRequest);
                    if (reportResultThreshold == null || reportResultThreshold.ReportResultSetCount <= 0)
                    {
                        _logger.LogInfo("Get Report  :: No Data Found :: No Data has been found for ProviderID {0}", reportsRequest.ProviderID);
                        return response = FormatHttpResponse.FormatResponse(reportModel, Request.CreateResponse(HttpStatusCode.OK));
                    }
                    if (reportResultThreshold != null && reportResultThreshold.ReportThresholdCount != 0 && reportResultThreshold.ReportResultSetCount >= reportResultThreshold.ReportThresholdCount)
                    {
                        _logger.LogError("Get Report :: Failed Validation :: Query Returned Rows {0} which exceeded Threshold {1} for Provider ID {2}", reportResultThreshold.ReportResultSetCount, reportResultThreshold.ReportThresholdCount, reportsRequest.ProviderID);
                        errors.Add(new ReportErrorModel("Reached Threshold.", "Reached_Threshold"));
                        return response = FormatHttpResponse.FormatResponse(errors, Request.CreateResponse(HttpStatusCode.InternalServerError));
                    }
                    #endregion

                    #region GetReportInfoByProviderJob
                    
                    if (reportsRequest.ReportType == ReportType.ProviderByJob)
                    {
                        _logger.LogInfo("GetReport :: Begin call to GetReportForProviderByJob to get Report Info for ProviderID {0}", reportsRequest.ProviderID);
                        reportData = _reportsRepository.GetReportForProviderByJob(reportsRequest);
                        _logger.LogInfo("GetReport :: End call to GetReportForProviderByJob to get Report Info for ProviderID {0}", reportsRequest.ProviderID);
                    }
                    else if (reportsRequest.ReportType == ReportType.Provider)
                    {
                        _logger.LogInfo("GetReport :: Begin call to GetReportForProvider to get Report Info for for ProviderID {0}", reportsRequest.ProviderID);
                        reportData = _reportsRepository.GetReportForProvider(reportsRequest);
                        _logger.LogInfo("GetReport :: End call to GetReportForProvider to get Report Info for for ProviderID {0}", reportsRequest.ProviderID);
                    }
                    if (reportData != null && reportData.Any())
                    {
                        reportModel.ReportDetails = ReportHelper.FormatReponseToModel(reportData, reportsRequest);
                    }
                    else
                    {
                        _logger.LogInfo("Get Report  :: No Data Found :: No Data has been found for ProviderID {0}", reportsRequest.ProviderID);
                    }
                    _logger.LogInfo("Get Report :: End with ProviderID {0}", reportsRequest.ProviderID);
                    return response = FormatHttpResponse.FormatResponse(reportModel, Request.CreateResponse(HttpStatusCode.OK));
                    #endregion
                }
                else
                {
                    _logger.LogError("Get Report  :: Failed Request Validation :: The Request Validation has been failed for Provider ID {0}", reportsRequest.ProviderID);
                    return response = FormatHttpResponse.FormatResponse(errors, Request.CreateResponse(HttpStatusCode.InternalServerError));
                }
            }
            catch (MySqlException mex)
            {
                if (mex != null && !string.IsNullOrWhiteSpace(mex.Message) && mex.Message.ToLower().Contains("timeout expired"))
                {
                    errors.Add(new ReportErrorModel("Time Out Exception has occured on the server.", "TimeOut_Exception_Occured"));
                }
                else
                {
                    errors.Add(new ReportErrorModel("Exception has occured on the server.", "Exception_Occured"));
                }
                return response = FormatHttpResponse.FormatResponse(errors, Request.CreateResponse(HttpStatusCode.InternalServerError));
            }
            catch (Exception ex)
            {
                _logger.LogError("Get Report :: Exception Occured :: An Error has occured when calling Get Report for Provider ID {0} Error {1}", reportsRequest.ProviderID, ex.Message);
                errors.Add(new ReportErrorModel ("Exception has occured on the server.", "Exception_Occured"));
                return response = FormatHttpResponse.FormatResponse(errors, Request.CreateResponse(HttpStatusCode.InternalServerError));
            }
        }
    }
}
