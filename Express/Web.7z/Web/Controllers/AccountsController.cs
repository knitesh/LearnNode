﻿using Monster.Members.Authentication;
using System.Web;
using System.Web.Mvc;

namespace Monster.JobAds.CommandCenter.Web.Controllers
{
    public class AccountsController : Controller
    {
        [HttpGet]
        [Route("logout")]
        [Authorize]
        public void Logout()
        {
            MonsterADAuthentication.SignOutAction(HttpContext.GetOwinContext());
        }

        [HttpGet]
        [Route("login")]
        public void Login(string returnUrl)
        {
            MonsterADAuthentication.SignInAction(HttpContext.GetOwinContext(), returnUrl);
        }
    }
}