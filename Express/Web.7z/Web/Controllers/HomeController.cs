﻿using System.Web.Mvc;

namespace Monster.JobAds.CommandCenter.Web.Controllers
{
    public class HomeController : Controller
    {       
        public ActionResult Index()
        {
            return View();
        }       
    }
}