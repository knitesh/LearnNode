﻿using System.Web.Mvc;
using Monster.JobAds.CommandCenter.Models;

namespace Monster.JobAds.CommandCenter.Web.Controllers
{
    public class ErrorController : Controller
    {
        [HttpGet]
        public ActionResult Throw()
        {
            throw new System.ApplicationException("these aren't the droids you're looking for");
        }

        public ActionResult Index(string id)
        {
            return View("Error", new ErrorView { Guid = id });
        }

        public ActionResult NotFound()
        {
            Response.StatusCode = 404;
            Response.ContentType = "text/html";
            return View("404");
        }

    }
}