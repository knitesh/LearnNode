﻿module.exports = function (grunt) {
    grunt.initConfig({
        // variables
        productionPath: '',
        pkg: grunt.file.readJSON('package.json'),

        // tasks
        less: {
            development: {
                options: {
                    compress: false,
                    optimization: null,
                },
                files: {
                    'Content/release/commandcenter.css': 'Content/less/commandcenter.less'
                }
            },
            production: {
                options: {
                    compress: true,
                    optimization: null,
                    sourceMap: true
                },
                files: {
                    'Content/release/commandcenter.min.css': 'Content/less/commandcenter.less'
                }
            }
        },

        requirejs: {
            compile: {
                options: {
                    baseUrl: "Scripts/old",
                    name: "lib/almond",
                    include: "main",
                    mainConfigFile: "Scripts/old/main.js",
                    out: "Scripts/old/main.built.js",
                    wrapShim: true,
                    findNestedDependencies: true,
                    uglify: { except: ["$super"] }
                }
            },
            compile_v2017: {
                options: {
                    baseUrl: "Scripts/v2017",
                    name: "lib/almond",
                    include: "main",
                    mainConfigFile: "Scripts/v2017/main.js",
                    out: "Scripts/v2017/main.built.js",
                    wrapShim: true,
                    findNestedDependencies: true,
                    uglify: { except: ["$super"] }
                }
            },
            compile_v2017_streaming: {
                //v2017.streaming
                options: {
                    baseUrl: "Scripts/v2017.streaming",
                    name: "lib/almond",
                    include: "main",
                    mainConfigFile: "Scripts/v2017.streaming/main.js",
                    out: "Scripts/v2017.streaming/main.built.js",
                    wrapShim: true,
                    findNestedDependencies: true,
                    uglify: { except: ["$super"] }
                }
            }

        },
       
        
        watch: {
            css: {
                files: ['Content/less/**/*.less'],
                tasks: ['less:development'],
                options: {
                    livereload: true
                }
            }
        },

        jasmine: {
            old: {
                src: ['Scripts/old/app.js', 'Scripts/old/models/*.js'],

                options: {
                    specs: 'Scripts/old/tests/**/*.test.js',
                    template: require('grunt-template-jasmine-requirejs'),
                    templateOptions: {
                        version: "Scripts/old/lib/require.js",
                        requireConfigFile: 'Scripts/old/require-config.js',
                        requireConfig: {
                            baseUrl: 'Scripts/old',
                            paths: {
                                "sinon": "lib/sinon",
                                "fixtures": "tests/fixtures"
                            },
                            shim: {
                                'lib/jasmine-sinon': ['sinon']
                            }
                        },
                        callback: function($) {
                            // do initialization stuff here
                        }
                    }
                }
            },
            v2017: {
                src: ['Scripts/v2017/app.js', 'Scripts/v2017/models/*.js'],

                options: {
                    keepRunner: true,
                    specs: 'Scripts/v2017/tests/**/*.test.js',
                    template: require('grunt-template-jasmine-requirejs'),
                    templateOptions: {
                        version: "Scripts/v2017/lib/require.js",
                        requireConfigFile: 'Scripts/v2017/require-config.js',
                        requireConfig: {
                            baseUrl: 'Scripts/v2017',
                            paths: {
                                "sinon": "lib/sinon",
                                "fixtures": "tests/fixtures"
                            },
                            shim: {
                                'lib/jasmine-sinon': ['sinon']
                            }
                        },
                        callback: function ($) {
                            // do initialization stuff here
                        }
                    }
                }
            },
            v2017_streaming: {
                src: ['Scripts/v2017.streaming/app.js', 'Scripts/v2017.streaming/models/*.js'],

                options: {
                    keepRunner: true,
                    specs: 'Scripts/v2017.streaming/tests/**/*.test.js',
                    template: require('grunt-template-jasmine-requirejs'),
                    templateOptions: {
                        version: "Scripts/v2017.streaming/lib/require.js",
                        requireConfigFile: 'Scripts/v2017.streaming/require-config.js',
                        requireConfig: {
                            baseUrl: 'Scripts/v2017.streaming',
                            paths: {
                                "sinon": "lib/sinon",
                                "fixtures": "tests/fixtures"
                            },
                            shim: {
                                'lib/jasmine-sinon': ['sinon']
                            }
                        },
                        callback: function ($) {
                            // do initialization stuff here
                        }
                    }
                }
            }
        }

    });

    // set up
    //grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-contrib-less');
    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.loadNpmTasks('grunt-contrib-requirejs');
    grunt.loadNpmTasks('grunt-contrib-jasmine');

    //grunt.registerTask('default', ['uglify', 'less']);
    grunt.registerTask('default', ['requirejs', 'less', 'jasmine']);
}