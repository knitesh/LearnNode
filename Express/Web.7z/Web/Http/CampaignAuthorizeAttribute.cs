﻿using System.Globalization;
using Monster.JobAds.Authentication;
using Monster.JobAds.CommandCenter.Models.Campaigns;
using Monster.JobAds.Configuration.AppConfigs;
using System;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Web.Http.Controllers;

namespace Monster.JobAds.CommandCenter.Web.Http
{
    /// <summary>
    /// 
    /// </summary>
    /// <remarks>
    /// TODO: ksoderst - review ClaimsPrincipalPermission attribute usage as replacement to custom attribute.
    /// NOTE: Created as ActionFilterAttribute vs. AuthorizeAttribute to obtain access to post-Model binding.
    /// </remarks>
    public class CampaignAuthorizeAttribute : System.Web.Http.Filters.ActionFilterAttribute
    {
        private const int CAMPAIGN_STATUS_ID_ACTIVE = 1;
        private const int CAMPAIGN_STATUS_ID_PENDING = 2;

        private readonly ICampaignContextFacade _campaignContextFacade;

        public CampaignAuthorizeAttribute()
        {
            _campaignContextFacade = CampaignContextFacade.Current;
        }

        internal CampaignAuthorizeAttribute(ICampaignContextFacade campaignContextFacade)
        {
            _campaignContextFacade = campaignContextFacade;
        }

        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            string switchValue;
            if (AppConfigHelper.TryGetAppConfig("RequiresAuthentication", out switchValue) && switchValue == "false") return; /* TODO: make testable */

            var httpMethod = actionContext.Request.Method;

            //All CmdCtr roles have READ access
            if (httpMethod == HttpMethod.Get) return;

            var claimsId = actionContext.RequestContext.Principal.Identity as ClaimsIdentity;
            if (claimsId == null) return;

            //CmdCtrPpcOwner role has full CRUD access
            if (claimsId.FindFirst(
                    x => x.Type == ClaimTypes.Role && String.CompareOrdinal(x.Value, CmdCtrRoleNames.CmdCtrPpcOwner) == 0) != null) return;

            //Non-CmdCtrSales roles only have READ access, Unauthorized
            if (claimsId.FindFirst(
                x => x.Type == ClaimTypes.Role && String.CompareOrdinal(x.Value, CmdCtrRoleNames.CmdCtrSales) == 0) == null)
            {
                HandleUnauthorizedRequest(actionContext);
                return;
            }

            //User is CmdCtrSales

            //CmdCtrSales can perform CRUD on Pending Campaigns ONLY
            bool c = false;
            if (httpMethod == HttpMethod.Delete)
            {
                object o;
                if (!actionContext.ActionArguments.TryGetValue("id", out o))
                {
                    throw new ArgumentException("ActionArgument \"id\" not found in actionContext", "actionContext"); //400 Bad-Request?
                }
                long id;
                if (o == null || !long.TryParse(o.ToString(), out id)) return;

                var campaignDto = _campaignContextFacade.GetCampaignByID(id);
                if (campaignDto == null) return;
                c = campaignDto.CampaignStatusID == CAMPAIGN_STATUS_ID_PENDING;
            }
            if (httpMethod == HttpMethod.Post)
            {
                object o;
                if (!actionContext.ActionArguments.TryGetValue("campaign", out o))
                {
                    throw new ArgumentException("ActionArgument \"campaign\" not found in actionContext", "actionContext"); //400 Bad-Request?
                }
                PostCampaign model;
                if (o == null || (model = o as PostCampaign) == null) return; //default to Model binding

                if (String.IsNullOrEmpty(model.CampaignStatusID))
                {
                    //default new Campaign to Pending
                    model.CampaignStatusID = CAMPAIGN_STATUS_ID_PENDING.ToString(CultureInfo.InvariantCulture);
                    return;
                }
                int campaignStatusId;
                c = (int.TryParse(model.CampaignStatusID, out campaignStatusId) && campaignStatusId == CAMPAIGN_STATUS_ID_PENDING);
            }
            if (httpMethod == HttpMethod.Put)
            {
                object o;
                if (!actionContext.ActionArguments.TryGetValue("campaign", out o))
                {
                    throw new ArgumentException("ActionArgument \"campaign\" not found in actionContext", "actionContext"); //400 Bad-Request?
                }
                PostCampaign model;
                if (o == null || (model = o as PostCampaign) == null || model.ID == 0) return; //default to Model binding

                var campaignDto = _campaignContextFacade.GetCampaignByID(model.ID);
                if (campaignDto == null) return;

                c = campaignDto.CampaignStatusID == CAMPAIGN_STATUS_ID_PENDING;
                if (c)
                {
                    //CmdCtrSales cannot Activate campaigns
                    int campaignStatusId;
                    c = model.CampaignStatusID != null && int.TryParse(model.CampaignStatusID, out campaignStatusId) &&
                        campaignStatusId != CAMPAIGN_STATUS_ID_ACTIVE;
                }
            }
            if (!c)
            {
                HandleUnauthorizedRequest(actionContext);
                return;
            }
            base.OnActionExecuting(actionContext);
        }

        private static void HandleUnauthorizedRequest(HttpActionContext actionContext)
        {
            if (actionContext == null)
            {
                throw new ArgumentNullException("actionContext");
            }
            actionContext.Response = actionContext.ControllerContext.Request.CreateErrorResponse(HttpStatusCode.Unauthorized, "Authorization has been denied for this request.");
        }
    }
}