﻿using System.Collections.Generic;
using Monster.JobAds.Authentication.AD;
using Monster.JobAds.Configuration.AppConfigs;
using System;
using System.Linq;
using System.Security.Claims;

namespace Monster.JobAds.CommandCenter.Web.Http
{
    public class CustomAuthorizeAttribute : System.Web.Http.AuthorizeAttribute
    {
        private readonly IADGroupCollectionFactory _adGroupCollectionFactory;

        public CustomAuthorizeAttribute()
        {
            _adGroupCollectionFactory = ADGroupCollectionFactory.Current;
        }

        internal CustomAuthorizeAttribute(IADGroupCollectionFactory adGroupCollectionFactory)
        {
            _adGroupCollectionFactory = adGroupCollectionFactory;
        }

        public override void OnAuthorization(System.Web.Http.Controllers.HttpActionContext actionContext)
        {
            string switchValue;
            if (AppConfigHelper.TryGetAppConfig("RequiresAuthentication", out switchValue) && switchValue == "false") return; /* TODO: make testable */

            if (!ClaimHasAnyCommandCenterRole(actionContext))
            {
                HandleUnauthorizedRequest(actionContext);
            }
            base.OnAuthorization(actionContext);
        }

        private bool ClaimHasAnyCommandCenterRole(System.Web.Http.Controllers.HttpActionContext actionContext)
        {
            if (actionContext.RequestContext.Principal == null) return false;

            var claimsId = actionContext.RequestContext.Principal.Identity as ClaimsIdentity;
            if (claimsId == null) return false;

            var adGroups =
                _adGroupCollectionFactory.RetrieveReadOnly(ADGroupCollectionFactory.CommandCenterAppName);

            if (adGroups == null || !adGroups.Any()) return true;

            var claimRoles = (claimsId.FindAll(ClaimTypes.Role) ?? new List<Claim>()).ToList();
            bool m = claimRoles.Any();
            if (m)
            {
                foreach (var claimRole in claimRoles)
                {
                    var lc = claimRole;
                    m = adGroups.Any(x => String.CompareOrdinal(x.ObjectID, lc.Value) == 0);
                    if (m)
                    {
                        break;
                    }
                }
            }
            return m;
        }
    }
}