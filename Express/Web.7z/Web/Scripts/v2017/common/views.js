﻿define(["app",
        "tpl!common/templates/breadcrumb.html",
        "tpl!common/templates/breadcrumbItem.html",
        "tpl!common/templates/loading.html",
        "tpl!common/templates/noData.html",
        "tpl!common/templates/customerInfo.html",
        "tpl!common/templates/customerBudgetInfo.html",
        "tpl!common/templates/customerIndicator.html",
        "tpl!common/templates/customerSidebar.html",
        "tpl!common/templates/locations.html",
        "tpl!common/templates/options.html",
        "tpl!common/templates/occupations.html",
        "tpl!common/templates/errors.html",
        "tpl!common/templates/searchBar.html",
        "tpl!common/templates/loginControl.html",
        "tpl!common/templates/youSure.html",
        "tpl!common/templates/404.html",
        "moment"], function (CommandCenter, breadcrumbTemplate, breadcrumbItemsTpl, loadingTpl, noDataTpl, customerInfoTpl, customerBudgetInfoTpl, customerIndicatorTpl, customerSidebarMenuTpl, locationsTpl, optionsTpl, occupationsTpl, errorsTemplate, searchBarTpl, loginControlTpl, youSureTpl,
            error404Template,moment) {
    CommandCenter.module("Common.Views", function (Views, CommandCenter, Backbone, Marionette, $, _) {
        Views.Breadcrumbs = Backbone.Model.extend({
            defaults: {
                title: "",
                url: ""
            },
            idAttribute: 'title'
        });

        Views.BreadcrumbCollection = new Backbone.Collection([], { model: Views.Breadcrumbs });

        Views.BreadcrumbItem = Marionette.ItemView.extend({
            template: breadcrumbItemsTpl,
            tagName: "li"
        });

        Views.BreadcrumbTextItem = Marionette.ItemView.extend({
            template: breadcrumbTemplate,
            tagName: "li"
        });

        Views.Breadcrumb = Marionette.CollectionView.extend({
            tagName: "ul",
            className: "breadcrumb-nav list-inline",
            initialize: function () {
                this.listenTo(this.collection, 'change', this.render);
                //this.render();
            },
            childViewOptions: function(model, index) {
                // do some calculations based on the model
                return {
                    childIndex: index
                }
            },
            getChildView: function(item) {
                // Choose which view class to render,
                // depending on the properties of the item model
                if ((item.get("url") !== "") && (this.collection.indexOf(item) != (this.collection.length - 1))) {
                    return Views.BreadcrumbItem;
                } else {
                    return Views.BreadcrumbTextItem;
                }
            },
            events: {
                "click li a": "goBackUsingBreadcrumb"
            },
            goBackUsingBreadcrumb: function (e) {
                var found = false;
                var that = this;
                _.each(this.collection.models, function (ele, index, list) {
                    if (found) {
                        that.collection.pop(ele);
                    }

                    if (ele.get('title') == e.target.text) { found = true; }
                });
                this.render();
            }
        });

        
        Views.CustomerBudgetInfo = Marionette.ItemView.extend({
            template: customerBudgetInfoTpl,
            tagName: "span",
            initialize: function (options) {
                this.model.on('change', this.render, this);
            },
            templateHelpers: function () {
                return {
                    budgetInfo: numeral(this.model.get('company').availableBudget).format('$0,0.00'),
                    isCampaignFeedEnabled: this.model.get('company').campaignfeedenabled,
                    providerId: this.model.get('company').id
            }
            }
        });

        Views.CustomerInfo = Marionette.ItemView.extend({
            template: customerInfoTpl,
            tagName: "div",
            className: "row",
            initialize: function (options) {
                this.headerText = options.headerText || "Campaigns";
            },
            events: {
                "click a.new-campaign": "newCampaign"
            },
            newCampaign: function () {
                CommandCenter.trigger("campaigns:new", this.model.get("CampaignId"));
            },
            templateHelpers: function () {
                var tab = $('.campaign-tabs li.active a').attr("href");

                var suffix = "";
                switch (tab) {
                    case "#active":
                        suffix = " Spent thus far"
                        break;
                    case "#pending":
                        suffix = " Budgeted"
                        break;
                    case "#inactive":
                        suffix = " Spent"
                        break;
                    default:
                        tab = undefined;
                        suffix = null;
                        break;
                }

                return {
                    
                    budgetInfo: (tab === undefined) ? "" : numeral(this.model.get('spend').get(tab.replace("#", ""))).format('$0,0.00') + suffix,
                    isCampaignFeedEnabled: this.model.get('company').campaignfeedenabled,
                    headerText: this.headerText || "Campaigns"
                }
            }
        });

        Views.CustomerIndicator = Marionette.ItemView.extend({
            template: customerIndicatorTpl,
            tagName: "div"
        });

        Views.CustomerSidebarMenu = Marionette.ItemView.extend({
            template: customerSidebarMenuTpl,
            tagName: "li",
            className: 'dropdown customer-menu',
            onRender: function () {
                // does the customer sidebar menu already exist?
                if ($('.customer-menu').length == 0) {
                    $(".sidebar-nav li:first").before(this.$el);
                }

                $(".customer-menu ul li a").removeClass("selected");
                var url = Backbone.history.getFragment();
                if(_.str.include(url, "campaigns")) {
                    $(".customer-menu ul li[data-items='campaigns'] a").addClass("selected");
                } else if(_.str.include(url, "contracts")) {
                    $(".customer-menu ul li[data-items='contracts'] a").addClass("selected");
                }
                else if (_.str.include(url, "reports")) {              
                    $(".customer-menu ul li[data-items='reports'] a").addClass("selected");
                }
                else if (_.str.include(url, "customers")) {
                    $(".customer-menu ul li[data-items='customers'] a").addClass("selected");
                }
            },
            templateHelpers: function () {
                return {
                    canEditCustomer: CommandCenter.roleForActivity("edit customer")
                }
            }
        });

        Views.NoData = Marionette.ItemView.extend({
            template: noDataTpl,

            title: "We're sorry, no items exist.",
            message: "",

            serializeData: function() {
                return {
                    title: Marionette.getOption(this, "title"),
                    message: Marionette.getOption(this, "message")
                }
            }
        });

        Views.SearchBar = Marionette.ItemView.extend({
            template: searchBarTpl,
            tagName: "div",
            className: "search-table",
            initialize: function () {
                this.listenTo(this.model, 'change', this.render);
            },
            templateHelpers: function () {
                var now = moment();
                var exp = now.unix();
                if (this.model.get('expires') !== "") {
                    exp = this.model.get('expires');
                }

                return {
                    valid: (exp > now.unix()) ? true : false
                }
            }
        });

        Views.LoginControl = Marionette.ItemView.extend({
            template: loginControlTpl,
            tagName: "div",
            className: "",
            initialize: function () {
                this.listenTo(this.model, 'change', this.render);
            },
            templateHelpers: function () {
                var now = moment();
                var exp = now.unix();
                if (this.model.get('expires') !== "") {
                    exp = this.model.get('expires');
                }

                return {
                    valid: (exp > now.unix()) ? true : false
                }
            }
        });

        Views.Loading = Marionette.ItemView.extend({
            template: loadingTpl,

            title: "Loading Data",
            message: "Please wait, data is loading.",

            className: "loading-spinner",

            serializeData: function () {
                return {
                    title: Marionette.getOption(this, "title"),
                    message: Marionette.getOption(this, "message")
                }
            },

            onShow: function () {
                /*
                var opts = {
                    lines: 13, // The number of lines to draw
                    length: 20, // The length of each line
                    width: 10, // The line thickness
                    radius: 30, // The radius of the inner circle
                    corners: 1, // Corner roundness (0..1)
                    rotate: 0, // The rotation offset
                    direction: 1, // 1: clockwise, -1: counterclockwise
                    color: "#000", // #rgb or #rrggbb
                    speed: 1, // Rounds per second
                    trail: 60, // Afterglow percentage
                    shadow: false, // Whether to render a shadow
                    hwaccel: false, // Whether to use hardware acceleration
                    className: "spinner", // The CSS class to assign to the spinner
                    zIndex: 2e9, // The z-index (defaults to 2000000000)
                    top: "30px", // Top position relative to parent in px
                    left: "auto" // Left position relative to parent in px
                };
                $("#spinner").spin(opts);
                */
            }
        });

        Views.AreYouSure = Marionette.ItemView.extend({
            template: youSureTpl,
            className: "text-center",

            title: "Load the jobs",
            message: "<strong>Please note:</strong> Clicking this button will load a large amount of data causing you to have to wait for a long period of time.",

            initialize: function (options) {
                this.customerId = this.options.customerId;
                this.jobcount = this.options.jobcount;
                this.selectedJobs = this.options.selectedJobs;
                this.campaignId = this.options.campaignId;
                this.targeting = this.options.targeting;
            },

            serializeData: function () {
                return {
                    title: Marionette.getOption(this, "title"),
                    message: Marionette.getOption(this, "message")
                }
            },

            events: {
                "click .btn": "loadTheJobs"
            },

            loadTheJobs: function () {
                this.trigger("show:jobs", { customer: this.customerId, CampaignId: this.campaignId, jobcount: this.jobcount, selectedJobs: this.selectedJobs, targeting: this.targeting });
            }
        });

        Views.Options = Marionette.ItemView.extend({
            template: optionsTpl,
            tagName: "option",
            onRender: function () {
                this.$el.attr('value', this.model.get('id'));
            },
            templateHelpers: function () {
                return {
                    hasJobCount: (this.model.get('all_jobs') !== undefined) ? true : false
                }
            }
        });

        Views.Locations = Marionette.CompositeView.extend({
            template: locationsTpl,
            childView: Views.Options,
            childViewContainer: "#select-location",
            templateHelpers: function () {
                return {
                    //items: this.options.customerLocations,
                    customerId: this.options.customerId,
                    isCampaignFeedEnabled: this.options.isCampaignFeedEnabled
                }
            },
            events: {
                "change #select-location": "getLocationOccupations"
            },
            getLocationOccupations: function (e) {
                var val = e.target.value;

                enableButtons();

                // see if occupation is already selected
                var s = $("#select-occupation")[0].selectize,
                    locationId = (val != '') ? val : null,
                    occupationId = (s.getValue() != '') ? s.getValue() : null;

                // get filtered list of occupations
                if ((locationId != null) && (occupationId == null) && (this.options.locOccLookup !== false)) {
                    // if occupation isn't already selected, get the filtered list
                    this.filterOccupationsByLocation(this, this.options.customerId, locationId);
                }

                // is location value blank?
                if ((locationId == null) && (this.options.locOccLookup !== false)) {
                    // get all locations
                    if (this.options.customerLocations !== undefined) {
                        reloadDropDown($("#select-location")[0].selectize, this.options.customerLocations);
                    }

                    //if (locationId == null) {
                    // get all occupations, keeping selection if valid
                    this.getAllOccupations(this);
                    //}
                }

                if ((locationId != null) || (occupationId != null)) {
                    // call the api to get the recommended ppc
                    this.trigger("show:recommendations", { location: locationId, occupation: occupationId });
                    //CommandCenter.CampaignsApp.New.Controller.getRecommendations(null, { location: locationId, occupation: occupationId });

                    // get the number of jobs in the occ or occ / loc combination
                    var regExp = /\(([^)]+)\)/;
                    var jobCount = 0;
                    if (occupationId == null) {
                        // just get the job count from the location
                        var txt = e.target.selectize.getOption(val).text();
                        var matches = regExp.exec(txt);
                        jobCount = (matches !== null) ? matches[1] : null;
                    } else if (locationId == null) {
                        // need to get the job count from the occupation
                        var txt = s.getOption(occupationId).text();
                        var matches = regExp.exec(txt);
                        jobCount = (matches !== null) ? matches[1] : null;
                    } else {
                        // need to get the job count from the smaller of the two
                        var occtxt = s.getOption(occupationId).text();
                        var loctxt = e.target.selectize.getOption(val).text();
                        var occmatches = regExp.exec(occtxt);
                        var locmatches = regExp.exec(occtxt);
                        jobCount = (occmatches !== null && locmatches !== null) ? ((occmatches[1] < locmatches[1]) ? occmatches[1] : locmatches[1]) : null;
                    }

                    //get the jobs
                    this.trigger("show:jobs", { customer: this.options.customerId, location: locationId, occupation: occupationId, jobcount: jobCount });
                }
            },

            filterOccupationsByLocation: function (obj, customerId, locationId) {
                var s = $("#select-occupation")[0].selectize;
                // store full list of occupations
                if (obj.options.customerOccupations === undefined) {
                    obj.options.customerOccupations = s.options;
                }

                var fetchingLocOccs = CommandCenter.request("location:occupations", customerId, locationId);
                $.when(fetchingLocOccs).done(function (occs) {
                    // update location dropdown with new data
                    s.clearOptions();
                    for (var i = 0; i < occs.length; i++) {
                        var occ = occs.at(i);
                        s.addOption({
                            id: occ.get("id"),
                            name: occ.get("name") + " (" + occ.get("all_jobs") + ")"
                        });
                    }
                    s.refreshOptions(false);
                });
            },

            getAllOccupations: function (obj) {
                var s = $("#select-occupation")[0].selectize,
                    selected = s.getValue(),
                    occs = obj.options.customerOccupations;

                if (_.isEmpty(occs) == false) {
                    s.clearOptions();
                    _.each(occs, function (occ) {
                        s.addOption({
                            id: occ.id,
                            name: occ.name
                        });
                    });
                    s.refreshOptions(false);
                }

                if (selected != '') {
                    s.setValue(selected);
                }
            }
        });

        Views.Occupations = Marionette.CompositeView.extend({
            template: occupationsTpl,
            childView: Views.Options,
            childViewContainer: "#select-occupation",
            templateHelpers: function () {
                return {
                    items: this.options.customerOccupations,
                    customerId: this.options.customerId,
                    isCampaignFeedEnabled: this.options.isCampaignFeedEnabled
                }
            },
            events: {
                "change #select-occupation": "getOccupationLocations"
            },
            getOccupationLocations: function (e) {
                var val = e.target.value;

                enableButtons();

                // see if occupation is already selected
                var s = $("#select-location")[0].selectize,
                    occupationId = (val != '') ? val : null,
                    locationId = (s.getValue() != '') ? s.getValue() : null;

                // get filtered list of locations
                if ((occupationId != null) && (locationId == null) && (this.options.locOccLookup !== false)) {
                    // if location isn't already sif (locationId == null) {
                    this.filterLocationsByOccupation(this, this.options.customerId, val);
                }

                if ((occupationId == null) && (this.options.locOccLookup !== false)) {
                    // get all occupations
                    if (this.options.customerOccupations !== undefined) {
                        reloadDropDown($("#select-occupation")[0].selectize, this.options.customerOccupations);
                    }

                    //if (locationId == null) {
                    // get all locations, keeping selection if valid
                    this.getAllLocations(this);
                    //}
                }

                if ((occupationId != null) || (locationId != null)) {
                    // call the api to get the recommended ppc
                    this.trigger("show:recommendations", { location: locationId, occupation: occupationId });
                    //CommandCenter.CampaignsApp.New.Controller.getRecommendations(null, { location: locationId, occupation: occupationId });

                    // get the number of jobs in the occ or occ / loc combination
                    var regExp = /\(([^)]+)\)/;
                    var jobCount = 0;
                    if (locationId == null) {
                        // just get the job count from the occupation
                        var txt = e.target.selectize.getOption(val).text();
                        var matches = regExp.exec(txt);
                        jobCount = (matches !== null) ? matches[1] : null;
                    } else if (occupationId == null) {
                        // just get the job count from the location
                        var txt = s.getOption(locationId).text();
                        var matches = regExp.exec(txt);
                        jobCount = (matches !== null) ? matches[1] : null;
                    } else {
                        // need to get the job count from the smaller of the two
                        var occtxt = e.target.selectize.getOption(val).text();
                        var loctxt = s.getOption(locationId).text();
                        var occmatches = regExp.exec(occtxt);
                        var locmatches = regExp.exec(occtxt);
                        jobCount = (occmatches !== null && locmatches !== null) ? ((occmatches[1] < locmatches[1]) ? occmatches[1] : locmatches[1]) : null;
                    }

                    //get the jobs
                    this.trigger("show:jobs", { customer: this.options.customerId, location: locationId, occupation: occupationId, jobcount: jobCount });
                }
            },

            getAllLocations: function (obj) {
                var s = $("#select-location")[0].selectize,
                    selected = s.getValue(),
                    locs = obj.options.customerLocations;

                if (_.isEmpty(locs) == false) {
                    s.clearOptions()
                    _.each(locs, function (loc) {
                        s.addOption({
                            id: loc.id,
                            name: loc.name
                        });
                    });
                    s.refreshOptions(false);
                }

                if (selected != '') {
                    s.setValue(selected);
                }
            },

            filterLocationsByOccupation: function (obj, customerId, occupationId) {
                var s = $("#select-location")[0].selectize;

                // store full list of locations
                if (obj.options.customerLocations === undefined) {
                    obj.options.customerLocations = s.options;
                }

                var fetchingOccLocs = CommandCenter.request("occupation:locations", customerId, occupationId);
                $.when(fetchingOccLocs).done(function (locs) {
                    // update location dropdown with new data
                    s.clearOptions();
                    for (var i = 0; i < locs.length; i++) {
                        var loc = locs.at(i);
                        s.addOption({
                            id: loc.get("id"),
                            name: loc.get("name") + " (" + loc.get("all_jobs") + ")"
                        });
                    }
                    s.refreshOptions(false);
                });
            }
        });
        /* Errors */
        Views.FormErrors = Marionette.ItemView.extend({
            template: errorsTemplate,
            tagName: "div",
            className: "panel panel-danger",
            templateHelpers: function () {
                return {
                    errors: this.options.errors,
                    title: "Errors"
                }
            }
        });

        Views.Error404 = Marionette.ItemView.extend({
            template: error404Template,
            tagName: "div",
            templateHelpers: function () {
                return {
                    title: this.options.title || "404",
                    subtitle: this.options.message || "Oops, the page you're looking for doesn't exist."
                }
            }
        });

        function enableButtons() {
            var loc = $("#select-location")[0].selectize.getValue();
            var occ = $("#select-occupation")[0].selectize.getValue();

            if (loc != "" || occ != "") {
                $(".btn-campaign").removeClass("disabled");
                $("#newCampaignForm .campaignForm").removeClass("hidden");

                // calculate the budget
                $("#campaign-clicks-per-job, #campaign-ppc").on("keyup change", function (e) {
                    if (($(".selected-job-count").is(":visible")) && (Number($(".selected-job-count").text()) >= 0)) {
                        var budget = ($(".selected-job-count").text() * $("#campaign-clicks-per-job").val()) * $("#campaign-ppc").val();
                        $("#campaign-budget").val(numeral(budget).format('0,0.00'));
                    }
                });
                // end budget calculation

                // show the description
                if ($("#campaign-description").length > 0) {
                    var desc = "",
                        regex = /\s+\(\d+\)/g,
                        o = $("#select-occupation")[0].selectize,
                        l = $("#select-location")[0].selectize;
                    if ((occ != "") && (loc == "")) {
                        desc = (o.getItem(occ)[0].innerHTML).replace(regex, "") + " jobs";
                    } else if ((loc != "") && (occ == "")) {
                        desc = "Jobs in " + (l.getItem(loc)[0].innerHTML).replace(regex, "");
                    } else if ((occ != "") && (loc != "")) {
                        desc = (o.getItem(occ)[0].innerHTML).replace(regex, "") + " jobs in " + (l.getItem(loc)[0].innerHTML).replace(regex, "");
                    }

                    $("#campaign-description").val(desc);
                }
            } else {
                $(".btn-campaign").addClass("disabled");
                $("#newCampaignForm .campaignForm").addClass("hidden");
            }
        }

        function reloadDropDown(obj, items) {
            obj.clearOptions();
            _.each(items, function (item) {
                var itext = item.name + ((item['all_jobs'] !== undefined) ? ' (' + item['all_jobs'] + ')' : '');
                obj.addOption({
                    id: item.id,
                    name: itext
                });
            });
            obj.refreshOptions(false);
        }
    });

    return CommandCenter.Common.Views;
});