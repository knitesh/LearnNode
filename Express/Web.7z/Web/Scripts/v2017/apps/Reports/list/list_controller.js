﻿define(['app','apps/reports/list/list_view','moment'], function (CommandCenter, View,moment) {
    CommandCenter.module("ReportsApp.List",
        function(List, CommandCenter, Backbone, Marionette, $, _) {
            List.Controller = {
                viewReports: function (id) {
                    require(['common/views', 'models/Customer', 'models/Reports', 'datepicker', 'chosen'],
                        function(CommonViews) {

                            // get the customer information
                            var fetchingCustomer = CommandCenter.request("customer:entity", id);

                            var fetchingReports = CommandCenter.request("report:entities", id);


                            // loading view goes here, when available
                            var loadingView = new CommonViews.Loading();
                            var reportFormLayout = new View.Layout();
                            //CommandCenter.contentRegion.show(loadingView);

                            CommandCenter.contentRegion.show(reportFormLayout);
                            reportFormLayout.loadingRegion.show(loadingView);

                            //Remove these lines
                            var fetchingCustomers = CommandCenter.request("customer:entities");
                            var customersListLayout = new View.Layout();
                            var formLayout = new View.Layout();


                            $.when(fetchingCustomer)
                                .done(function(customer) {

                                    // show the customer sidebar menu items
                                    var cI = new CommonViews.CustomerIndicator({ model: customer });
                                    CommandCenter.customerIndicatorRegion.show(cI);
                                    var customerSidebar = new CommonViews.CustomerSidebarMenu({ model: customer });
                                    customerSidebar.render();

                                });


                            $.when(fetchingReports)
                                .done(function(report) {

                                    reportFormLayout.loadingRegion.empty();

                                    var newReport = CommandCenter.request("report:entity:new", id);
                                    newReport.set("provider", id);
                                    var ReportFormView = new View.ReportForm({ model: newReport });

                                    reportFormLayout.reportForm.show(ReportFormView);

                                    // new report
                                    ReportFormView.on("form:submit",
                                        function(data) {
                                            require(["apps/reports/list/list_view"],
                                                function(ListView) {
                                                  

                                                    var loadingView = new CommonViews.Loading();

                                                    reportFormLayout.loadingRegion.show(loadingView);

                                                    var options = {
                                                        success: function(model, repsonse, options) {

                                                            var obj = repsonse.reportdetails;

                                                            if (obj.length > 0) {

                                                                

                                                                try {

                                                                    
                                                                    createCSV(obj, model);
                                                                    newReport.set("provider", id);
                                                                    
                                                                    reportFormLayout.loadingRegion.empty();
                                                                } catch (err) {

                                                                    reportFormLayout.loadingRegion.empty();
                                                                }
                                                            } else {
                                                               
                                                               
                                                                var response = {};
                                                                response.responseJSON = [];
                                                                response.responseJSON[0] = {};
                                                                response.responseJSON[0].errorcode = 'No Results';
                                                                response.responseJSON[0].errormessage = 'There is no data for your query.  Please adjust your report parameters and try again.';
                                                                ReportFormView.triggerMethod("form:data:invalid", response.responseJSON);
                                                                reportFormLayout.loadingRegion.empty();
                                                            }
                                                        },

                                                        error: function(model, response, options) {

                                                            ReportFormView.triggerMethod("form:data:invalid",response.responseJSON);
                                                            reportFormLayout.loadingRegion.empty();

                                                        }
                                                    }

                                                    if (!newReport.save(data, options)) {

                                                        ReportFormView.triggerMethod("form:data:invalid",newReport.validationError);
                                                        reportFormLayout.loadingRegion.empty();

                                                    }

                                                });
                                        });
                                });

                        });
                }
            };
        });

    function createCSV(obj, model) {

        
        var selectedDataPoints = model.attributes;

        var Assoc = [];

        var reportType = [];
        reportType[1] = 'Results by job';
        reportType[2] = 'Results by provider';


        var theDataList = [];
        //theDataList[4] = { displayName: 'JobID', dbName: 'jobid' };
        theDataList[3] = { displayName: 'Job Ad Ref Code', dbName: 'jobadrefcode' };
        theDataList[2] = { displayName: 'Job Title', dbName: 'jobtitle' };

        theDataList[10] = { displayName: 'Company', dbName: 'company' };
        theDataList[12] = { displayName: 'Location ID', dbName: 'locationid' };
        theDataList[13] = { displayName: 'Occupation (soc3)', dbName: 'occupation' };
        theDataList[11] = { displayName: 'Campaign (Campaign Name, Campaign ID, Campaign Budget, Days In Campaign)', dbName: 'campaign' };
        //theDataList[] = { displayName: 'Job Pricing Type Name', dbName: 'jobadpricingtype' };
        theDataList[5] = { displayName: 'Active Date', dbName: 'activedate' };
        theDataList[6] = { displayName: 'Days Active', dbName: 'daysactive' };
        //theDataList[7] = { displayName:'Clicks', dbName:'clicks'};
        theDataList[8] = { displayName: 'Recommended CPC', dbName: 'recommendedcpc' };
        theDataList[9] = { displayName: 'CPC, Spend', dbName: 'cpcspend' };

       
        for (var key1 in selectedDataPoints.DataPointsRequested) {
            Assoc[theDataList[selectedDataPoints.DataPointsRequested[key1]].dbName] = theDataList[selectedDataPoints.DataPointsRequested[key1]].displayName;
        }

        
   
        var JSONData = [];
        JSONData = obj;

        var ReportTitle = reportType[selectedDataPoints.ReportType];

        ReportTitle = ReportTitle +
            ' report ' +
            selectedDataPoints.ReportStartDate +
            '  to  ' +
            selectedDataPoints.ReportEndDate +
            '  generated on ' +
            moment().toString();

        var ShowLabel = true;

        //If JSONData is not an object then JSON.parse will parse the JSON string in an Object
        var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;


        var CSV = '';
        //Set Report title in first row or line

        CSV += ReportTitle + '\r\n\n';
      
        //This condition will generate the Label/Header
        if (ShowLabel) {
            var row = "";

            //This loop will extract the label from 1st index of on array
            for (var index in arrData[0]) {
                
                if (index in Assoc) {

                    //Now convert each value to string and comma-seprated
                    row += Assoc[index] + ',';

                } else {

                }


                if (selectedDataPoints.ReportType == 1) {

                    if ((index == 'soc3') &&
                    ('occupation' in Assoc)) {
                     
                        if (index == 'soc3') {
                            row += 'Occupation - SOC3' + ',';
                        }

                    }

                    if ((index == 'cpc' || index == 'spend') && ('cpcspend' in Assoc)) {
                        if (index == 'cpc') {
                            row += 'Cpc' + ',';
                        }
                        if (index == 'spend') {
                            row += 'Spend' + ',';
                        }
                    }


                    if ((index == 'campaignid' || index == 'daysincampaign' || index == 'campaignname' || index == 'campaignbudget') &&
                    ('campaign' in Assoc)) {
                        if (index == 'campaignid') {
                            row += 'Campaign Id' + ',';
                        }
                        if (index == 'daysincampaign') {
                            row += 'Days In Campaign' + ',';
                        }
                        if (index == 'campaignname') {
                            row += 'Campaign Name' + ',';
                        }
                        if (index == 'campaignbudget') {
                            row += 'Campaign Budget' + ',';
                        }

                    }


                    if ((index == 'cityname' || index == 'state') && ('locationid' in Assoc)) {
                        if (index == 'cityname') {
                            row += 'City Name' + ',';
                        }
                        if (index == 'state') {
                            row += 'State' + ',';
                        }

                    }

                    if (index == 'jobid') {

                        row += 'JobId' + ',';

                    }

                } else {

                    if (index == 'soc3' && 'occupation' in Assoc) {

                        if (index == 'soc3') {
                            row += 'Occupation - SOC3' + ',';
                        }

                    }

                    if ((index == 'cpc' || index == 'spend') && ('cpcspend' in Assoc)) {
                        if (index == 'cpc') {
                            row += 'Cpc' + ',';
                        }
                        if (index == 'spend') {
                            row += 'Spend' + ',';
                        }
                    }

                    if ((index == 'campaignid' || index == 'campaignname' || index == 'campaignbudget') && 'campaign' in Assoc) {
                        if (index == 'campaignid') {
                            row += 'Campaign Id' + ',';
                        }

                        if (index == 'campaignname') {
                            row += 'Campaign Name' + ',';
                        }

                        if (index == 'campaignbudget') {
                            row += 'Campaign Budget' + ',';
                        }
                    }

                    if ((index == 'cityname' || index == 'state') && ('locationid' in Assoc)) {
                        if (index == 'cityname') {
                            row += 'City Name' + ',';
                        }
                        if (index == 'state') {
                            row += 'State' + ',';
                        }
                    }

                }

                if (index == 'providername') {

                    row += 'Provider Name' + ',';

                }

               

                if (index == 'billableclicks' || index == 'nonbillableclicks') {

                    if (index == 'billableclicks') {

                        row += 'Billable PPC Clicks' + ',';

                    } 

                    if (index == 'nonbillableclicks') {

                        row += 'Non-Billable PPC Clicks' + ',';

                    }
                }

                if (index == 'datemonthvalue') {

                    //Day IntervalBreakDown
                    if (selectedDataPoints.IntervalBreakDown == 1) {
                        row += 'Day' + ',';
                    }
                    //Month IntervalBreakDown
                    if (selectedDataPoints.IntervalBreakDown == 2) {
                        row += 'Date' + ',';
                    }
                    

                }

            }

            row = row.slice(0, -1);

            //append Label row with line break
            CSV += row + '\r\n';
        }

        //1st loop is to extract each row
        for (var i = 0; i < arrData.length; i++) {
            var row = "";
            
            //2nd loop will extract each column and convert it in string comma-seprated
            for (var index in arrData[i]) {
                
                if (index in Assoc) {

                    if (index == 'recommendedcpc') {

                        row += '"$' + arrData[i][index].toFixed(2) + '",';

                    }
                    else {

                        row += '"' + arrData[i][index] + '",';
                        
                    }
                }


                if (selectedDataPoints.ReportType == 1) {
                   
                    if ( index == 'soc3' && 'occupation' in Assoc) {

                        row += '"' + arrData[i][index] + '",';


                    }

                    if ((index == 'cpc' || index == 'spend') && ('cpcspend' in Assoc)) {

                        row += '"$' + arrData[i][index].toFixed(2) + '",';

                    }

                    if ((index == 'campaignid' || index == 'daysincampaign' || index == 'campaignname' || index == 'campaignbudget') &&
                    ('campaign' in Assoc)) {

                        if (index == 'campaignbudget')
                        {
                            if (arrData[i][index] == null) {

                                row += '"None",';

                            } else {
                                row += '"$' + arrData[i][index].toFixed(2) + '",';
                            }
                        }
                        else
                        {
                            row += '"' + arrData[i][index] + '",';
                        }
                    }
                    if ((index == 'cityname' || index == 'state') && ('locationid' in Assoc)) {
                        row += '"' + arrData[i][index] + '",';

                    }

                    if (index == 'jobid') {

                        row += '"' + arrData[i][index] + '",';

                    }
                } else {

                    if (index == 'soc3' && ('occupation' in Assoc)) {

                        row += '"' + arrData[i][index] + '",';


                    }

                    if ((index == 'cpc' || index == 'spend') && ('cpcspend' in Assoc)) {

                        row += '"$' + arrData[i][index].toFixed(2) + '",';

                    }


                    if ((index == 'campaignid' || index == 'campaignname' || index == 'campaignbudget') && ('campaign' in Assoc)) {

                        if (index == 'campaignbudget') {

                            if (arrData[i][index] == null) {

                                row += '"None",';

                            } else {
                                row += '"$' + arrData[i][index].toFixed(2) + '",';
                            }
                        }
                        else {
                            row += '"' + arrData[i][index] + '",';
                        }


                    }
                    if ((index == 'cityname' || index == 'state') && ('locationid' in Assoc)) {
                       
                        row += '"' + arrData[i][index] + '",';

                    }

                   

                }


                if (index == 'providername') {


                    row += '"' + arrData[i][index] + '",';

                }
               
                if ((index == 'billableclicks' || index == 'nonbillableclicks')) {

                    row += '"' + arrData[i][index] + '",';

                }
                if (index == 'datemonthvalue') {

                    if (arrData[i][index]) {
                        row += '"' + arrData[i][index] + '",';
                    }
                    

                }

            }

            row.slice(0, row.length - 1);

            //add a line break after each row
            CSV += row + '\r\n';
        }

        if (CSV == '') {
            alert("Invalid data");
            return;
        }



        //Generate a file name
        var fileName = "";
        //this will remove the blank-spaces from the title and replace it with an underscore
        fileName += ReportTitle.replace(/ /g, "_");

        //Initialize file format you want csv or xls

        if (window.navigator.msSaveOrOpenBlob) {
            var blob = new Blob([decodeURIComponent(encodeURI(CSV))],
            {
                type: "text/csv;charset=utf-8;"
            });
            navigator.msSaveBlob(blob, fileName + '.csv');
        } else {

            var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);


            //this trick will generate a temp <a /> tag
            var link = document.createElement("a");
            link.href = uri;

            //set the visibility hidden so it will not effect on web-layout
            link.style = "visibility:hidden";
            link.download = fileName + ".csv";

            //this part will append the anchor tag and remove it after automatic click
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);


        }


    };

    return CommandCenter.ReportsApp.List.Controller;
});