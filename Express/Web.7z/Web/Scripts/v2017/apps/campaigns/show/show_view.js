﻿define(["app",
        "tpl!apps/campaigns/show/templates/campaignDetailLayout.html",
        "tpl!apps/campaigns/show/templates/noJobs.html",
        
        "tpl!apps/campaigns/show/templates/info.html",
        "tpl!apps/campaigns/show/templates/stats.html",
        "tpl!apps/campaigns/show/templates/jobs.html",
        "tpl!apps/campaigns/show/templates/job.html",
        "tpl!apps/campaigns/show/templates/campaignPerformanceChart.html",

        "tpl!apps/campaigns/common/templates/Modal/generatedBooleanExpression.html",
        "moment",
        "chartjs",
        "underscore-string"],
      function (CommandCenter,layoutTemplate,noDataTpl, infoTemplate, statsTemplate, jobsTemplate, jobDetailTemplate, viewTemplate, expressionTpl, moment) {
          CommandCenter.module("CampaignsApp.Show.View", function (View, CommandCenter, Backbone, Marionette, $, _) {

              View.Layout = Marionette.LayoutView.extend({
                  template: layoutTemplate,
                  tagName: "div",
                  className: "row",
                  regions: {
                      campaignInfo: "#campaignInfo",
                      campaignStats: "#campaignStats",
                      campaign: "#campaignPerformance",
                      campaignJobs: "#campaignJobs",
                      booleanExpression: ".boolean-expression"
                  }
              });

              View.Campaign = Marionette.ItemView.extend({
                  template: viewTemplate,
                  tagName: "div",
                  className: "row",
                  events: {
                      "click .chart-timeframe > a": "changeChartTimeframe"
                  },
                  changeChartTimeframe: function (e) {
                      e.preventDefault();

                      $(e.target).siblings().removeClass("active disabled");
                      $(e.target).addClass("active disabled");

                      this.trigger("reloadChartData", $(e.target).attr("data-content"));
                  }
              });

              View.CampaignInfo = Marionette.ItemView.extend({
                  template: infoTemplate,
                  tagName: "div",
                  className: "row",
                  initialize: function (options) {
                      this.customer = options.customer.get('company');
                  },
                  templateHelpers: function () {
                      return {
                          isCampaignFeedEnabled: this.customer.campaignfeedenabled
                      }
                  },
                  events: {
                      "click .delete-campaign": "deleteCampaign",
                      "click i[class*='fa-toggle']": "toggleText",
                      "click .truncated-text": "toggleText"
                  },
                  deleteCampaign: function (e) {
                      e.preventDefault();
                      CommandCenter.request("campaign:delete", this.model);
                  },
                  toggleText: function (e) {
                      e.preventDefault();

                      var obj;
                      obj = ($(e.target).hasClass('truncated-text')) ? $(e.target) : $(e.target).parent();
                      obj.toggleClass("truncated");
                      obj.find('.fa').toggleClass("fa-toggle-right fa-toggle-down");
                  }
              });

              View.CampaignStats = Marionette.ItemView.extend({
                  template: statsTemplate,
                  tagName: "div",
                  className: "row",
                  initialize: function (options) {
                      this.customer = options.customer.get('company');
                  },
                  events: {
                      'click #btnViewCriteriaBolleanExpression': "showBooleanExpression",
                  },
                  templateHelpers: function () {

                      var totalBudget = this.model.get('Budget');
                      var campaignPerformance = this.model.get('CampaignPerformance');
                      var currentDailyCap = this.model.get('CurrentDailyCap');

                      var pctbudgetUsed = campaignPerformance.TotalSpend / totalBudget;

                      var dailyCapUsedPct = 0;

                      dailyCapUsedPct = currentDailyCap ? ((campaignPerformance.DailySpend ? campaignPerformance.DailySpend : 0) / currentDailyCap) * 100 : 0;

                      return {
                          pctComplete: numeral(pctbudgetUsed).format('0%'),
                          pctUnformatted: (pctbudgetUsed) * 100,
                          isCampaignFeedEnabled: this.customer.campaignfeedenabled,
                          dailyCapsProgressTemplate: function () {

                              var usedDailyCaps = Math.floor(numeral(dailyCapUsedPct));

                              return (
                                  '<div class="daily-provider-progress progress"><div id="dailyCapsProgressBar" class="progress-bar daily-progress-bar-info progress-bar-striped" role="progressbar" ' +
                                      'aria-valuenow=' + usedDailyCaps + ' aria-valuemin="0" aria-valuemax="100" style="width : ' + usedDailyCaps + '%" ></div></div><label>' +
                                      usedDailyCaps + '% Daily Cap Used </label>');
                          },
                          CampaignPerformance: campaignPerformance
                      }
                  },
                  onDomRefresh: function () {
                      if ((!this.customer.campaignfeedenabled) && ($(this.$el).find("#budget-chart").parent().css("display") !== "none")) {
                          var that = this;
                          var totalBudget = this.model.get('Budget');
                          var campaignPerformance = this.model.get('CampaignPerformance');

                          var pctComplete = campaignPerformance.TotalSpend / totalBudget;

                          var doughnut_overrides = {
                              animationSteps: 20,
                              percentageInnerCutout: 82,
                              segmentShowStroke: true,
                              showTooltips: false,
                              //responsive: true,
                              onAnimationComplete: function () {
                                  var chart = $("#budget-chart");

                                  canvasObj.font = "1.6em 'Helvetica Neue', Helvetica, Arial, sans-serif";
                                  canvasObj.textBaseline = "middle";
                                  canvasObj.fillStyle = "#333";

                                  var canvasWidth = $(chart).width(),
                                      canvasHeight = $(chart).height(),
                                      chartText = numeral(pctComplete).format('0%'),
                                      textWidth = canvasObj.measureText(chartText).width,
                                      textPosX = Math.round((canvasWidth - textWidth) / 2);

                                  canvasObj.fillText(chartText, textPosX, (canvasHeight / 2));
                              }
                          };


                          var pctLeft = (1 - pctComplete);
                          var data = [
                              { value: pctComplete, color: "#F7464A", highlight: "#FF5A5E", label: "Red" },
                              { value: ((pctLeft > 0) ? pctLeft : 0), color: "#d3d3d3" }
                          ];
                          // chart.js donut charts
                          // Get context with jQuery - using jQuery's .get() method.
                          var canvasObj = $(this.$el).find("#budget-chart").get(0).getContext("2d");
                          var chartObj = new Chart(canvasObj).Doughnut(data, doughnut_overrides);
                      }
                  },
                  showBooleanExpression: function (e) {
                      e.preventDefault();
                      this.trigger("btn:ShowBooleanExpression:clicked");
                  }
              });

              View.NoData = Marionette.ItemView.extend({
                  template: noDataTpl,
                  tagName: "tr",

                  title: "We're sorry, no items exist.",
                  message: "",

                  serializeData: function () {
                      return {
                          title: Marionette.getOption(this, "title"),
                          message: Marionette.getOption(this, "message")
                      }
                  }
              });

              View.BooleanExpressionView = Marionette.ItemView.extend({
                  id: "boolean-wrap",
                  template: expressionTpl,
                  templateHelpers: function () {
                      return {
                          bodyContent: this.options.expression
                      };
                  }
              });

              View.CampaignJob = Marionette.ItemView.extend({
                  template: jobDetailTemplate,
                  tagName: "tr",
                  className: function() {
                      return (!this.model.get('active')) ? "text-muted" : "";
                  },

                  initialize: function (options) {
                      this.jobclicklimit = options.jobclicklimit;
                  },

                  templateHelpers: function () {
                      return {
                          jobclicklimit: this.jobclicklimit
                      }
                  }
              });

              View.CampaignJobs = Marionette.CompositeView.extend({
                  tagName: "div",
                  className: "row",
                  template: jobsTemplate,
                  initialize: function (options) {
                      this.jobclicklimit = options.jobclicklimit;
                  },

                  childView: View.CampaignJob,
                  childViewContainer: "tbody",
                  childViewOptions: function (model, index) {
                      return {
                          jobclicklimit: this.jobclicklimit
                      }
                  },

                  getEmptyView: function () {
                      return View.NoData;
                  },
                  emptyViewOptions: {
                      title: "No jobs currently exist in the campaign.",
                      message: ""
                  },

                  viewComparator: function (item) {
                      return [!item.get("isactiveincampaign"), item.get("title")]
                  }
              });

              
          });

          return CommandCenter.CampaignsApp.Show.View;
      });