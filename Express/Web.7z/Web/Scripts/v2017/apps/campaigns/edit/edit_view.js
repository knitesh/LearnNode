define(["app",
        "tpl!apps/campaigns/common/templates/layout.html",
        "tpl!apps/campaigns/common/templates/header.html",

        "tpl!apps/campaigns/common/templates/basic/campaignBasicFieldSetloading.html",
        "tpl!apps/campaigns/common/templates/basic/campaignBasicFieldSet.html",
        "tpl!apps/campaigns/common/templates/basic/campaignBasicFieldSetForFeedBased.html",

        "tpl!apps/campaigns/common/templates/Criteria/campaignCriteria.html",
        "tpl!apps/campaigns/common/templates/Criteria/campaignCriterion.html",

        
        "tpl!apps/campaigns/common/templates/Jobs/campaignedJobWithClicks.html",
        "tpl!apps/campaigns/common/templates/Jobs/campaignedJobsWithClicks.html",
        "tpl!apps/campaigns/common/templates/Jobs/job.html",
        "tpl!apps/campaigns/common/templates/Jobs/jobs.html",
        "tpl!apps/campaigns/common/templates/Jobs/jobCount.html",

        "tpl!apps/campaigns/common/templates/Modal/generatedBooleanExpression.html",
        "tpl!apps/campaigns/common/templates/Modal/campaignCreateWarning.html",
        "moment",
        "lib/jquery.tablesorter",
        "backbone.syphon",
        "underscore-string"],
  function (
              CommandCenter,

              layoutTemplate,
              headerTemplate,

              basicFieldSetloadingTpl,
              basicFieldListTpl,
              basicFieldListForFeedBasedTpl,

              criteriaTpl,
              criterionTpl,
              
              campaignedJobTmpl,
              campaignedJobsTmpl,
              jobTemplate,
              jobsTemplate,
              jobCountTemplate,

              expressionTpl,
              warningTpl,

              moment
      ) {
      CommandCenter.module("CampaignsApp.Edit.View", function (View, CommandCenter, Backbone, Marionette, $, _) {
          /*Boolean*/
        View.Layout = Marionette.LayoutView.extend({
            template: layoutTemplate,
            tagName: "div",
            regions: {
                //contentArea: "#edit_campaign",
                header: "#header",
                basicFieldList: "#basic-field-list",
                formRegion: ".form-region",
                errorRegion: ".form-errors",
                warning: ".warning-modal",

                criteria: ".criteria",

                campaignedJobsRegion: ".selectedJobList",

                jobListBasedOnCriteria: '.jobListBasedOnCriteria',

                customerBudgetInfo: "#customerBudgetInfo",

                booleanExpression: ".boolean-expression",

                jobCount: ".js-job-count"
            },
            childEvents: {
                'selected:job': function (childView, job) {
                    this.getRegion('formRegion').currentView.trigger('select:job', job);
                },
                'unselected:job': function (childView, job) {
                    this.getRegion('formRegion').currentView.trigger('unselect:job', job);
                    this.getRegion('alacarteRegion').currentView.trigger('uncampaign:job', job);
                }
            },
            onSaveCampaignClicked: function() {
                /*Disable Create Button on Screen*/
                      $('[class*="btn-save"]').attr('disabled', true);
                      
                      var data = Backbone.Syphon.serialize(this);

                      this.trigger("Campaign:save",data);
            }
        });

        View.BasicFieldSetLoading = Marionette.ItemView.extend({
            template: basicFieldSetloadingTpl,

            title: "Loading Campaign Data",

            serializeData: function () {
                return {
                    title: Marionette.getOption(this, "title"),
                    message: Marionette.getOption(this, "message")
                }
            }
        });

        View.Header = Marionette.ItemView.extend({
            template: headerTemplate,
            tagName: "div",
            className: "col-xs-12",
            templateHelpers: function () {
                return {
                    headervalue: "Edit Campaign",
                    submitBtnText: 'Save Changes'
                };
            },
            events: {
                "click .btn-cancel": "goBackToCampaign",
                "click .btn-save": "saveCampaignEdits"
            },
            goBackToCampaign: function (e) {
                e.preventDefault();
                CommandCenter.trigger("campaigns:show", this.model.get("id"));
            },
            saveCampaignEdits: function (e) {
                e.preventDefault();
                this.trigger("btn:saveCampaign:clicked");
            }
        });

        View.BasicFieldList = Marionette.ItemView.extend({
            getTemplate: function(){
                if (this.model.get('IsFeedBasedCustomer')) {
                    return basicFieldListForFeedBasedTpl;
                } else {
                    return basicFieldListTpl;
                }
            },
            tagName: "div",
            attributes: {
                "id": "editCampaignBasicFieldSet",
                "role": "form"
            },
            ui: {
                campaignStatuses: "#campaign-status",
                campaignName: "#campaign-name",
                campaignCriteria: ".campaign-criteria",
                campaignJobCount: "#campaign-job-count",
                locationId: "#campaign-location",
                occupationId: "#campaign-occupation",
                ppcAmount: "#campaign-ppc",
                budget: "#campaign-budget",
                submitButton: ".btn-campaign",
                getPPCRecommendation: "#get-ppc-recommendation",
                campaignType: "#campaign-is-dynamic"
            },
            events: {
                "click #utcTime": "showUtcTime",
                "submit form": "editCampaign",
                "mouseover .dateRange": "datepicker_datetimepicker",
                "click #btnStartDateOverride": "startDateOverride",
                "click #btnModalClose": "closeStartDateModal",
                "click #btnClosePopUp": "CloseStartDatePopUp"
            },
            modelEvents: {
                "change:isdynamic": "changeCampaignType"
            },
            onShow: function () {
                //Enable Bootstrap tooltip
                $('[data-toggle="tooltip"]').tooltip();
            },
            datepicker_datetimepicker: function (ev) {
                var status = this.model.get("CampaignStatus");

                var initialEndDate = '-0d';

                var isCampaignFeedEnabled = this.model.get('IsFeedBasedCustomer');
                if (isCampaignFeedEnabled) {return;}



                if (status && (status.toLowerCase() !== "active" && status.toLowerCase() !== "disabled")) {
                    $("#createStartDate").datepicker({ autoclose: true, startDate: '-0d', clearBtn: true })
                        .on("changeDate", function () {
                            if ($('#createStartDate').datepicker('getFormattedDate').length > 0) {

                                $('#createEndDate').datepicker('setStartDate', $('#createStartDate').datepicker('getFormattedDate'));

                                if ($('#createEndDate').datepicker('getFormattedDate') === "") {
                                    $('#campaign-end-date').val('');
                                }
                            } else {
                                $('#createEndDate').datepicker('setStartDate', '-0d');
                            }
                        });
                    //Check if Start date is present
                    if ($("#createStartDate").datepicker('getFormattedDate').length > 0) {
                        initialEndDate = $('#createStartDate').datepicker('getDate');
                        var todayDate = new Date();
                        var utceditDate = new Date(todayDate.getTime() + todayDate.getTimezoneOffset() * 60000);
                        utceditDate = new Date(utceditDate.getFullYear(), utceditDate.getMonth(), utceditDate.getDate());
                        if (initialEndDate < utceditDate) {
                            initialEndDate = '-0d';
                        }
                    }
                    $("#createEndDate").datepicker({ autoclose: true, startDate: initialEndDate, clearBtn: true })
                        .on("changeDate", function () {
                            $('#createStartDate').datepicker('setEndDate', $('#createEndDate').datepicker('getFormattedDate'));
                        });
                }
                else {
                    if ($("#createStartDate").datepicker('getFormattedDate').length > 0) {

                        initialEndDate = $('#createStartDate').datepicker('getDate');
                        var todayDateNew = new Date();
                        var utceditDateNew = new Date(todayDateNew.getTime() + todayDateNew.getTimezoneOffset() * 60000);
                        utceditDateNew = new Date(utceditDateNew.getFullYear(), utceditDateNew.getMonth(), utceditDateNew.getDate());
                        if (initialEndDate < utceditDateNew) {
                            initialEndDate = '-0d';
                        }
                    }
                    $("#createEndDate").datepicker({ autoclose: true, startDate: initialEndDate, clearBtn: true })
                       .on("changeDate", function () {
                           $('#createStartDate').datepicker('setEndDate', $('#createEndDate').datepicker('getFormattedDate'));
                       });
                }
            },
            changeCampaignType: function () {
                if (this.model.get("isdynamic")) {
                    this.ui.getPPCRecommendation.removeClass("hidden");
                } else {
                    this.ui.getPPCRecommendation.addClass("hidden");
                }

                this.ui.campaignType.val(this.model.get("isdynamic"));
            },
            showUtcTime: function(e) {
                    e.preventDefault();
                    var date = new Date();
                    $('#utcTime')[0].innerHTML = date.toUTCString();
                },
            formReset: function () {
                // no need to reset the form if it isn't shown
                if ($(this.$el).is(":hidden")) { return; }

                this.ui.campaignName.val("");
                this.ui.campaignJobCount.val("");
                this.ui.campaignCriteria.empty();
                this.ui.ppcAmount.val("");
                this.ui.budget.val("");
                this.ui.submitButton.removeClass("disabled");

                // remove any form errors
                $('.form-group, .input-group').removeClass('has-error');
                $('.tab-pane.active .form-errors').hide();

                // reactivate the filter box
                $('.tab-pane.active .filter-box').removeAttr("disabled");
            },
            uncampaign: function (e) {
                e.preventDefault();

                // reset the selected card
                $("li.card a i.fa-check-square-o").toggleClass("fa-plus-circle fa-check-square-o");

                // unhighlight the selected card
                $("li.card.selected").removeClass("selected");

                // reset the form values
                $(e.target).parent().remove();
                this.ui.campaignJobCount.val("");

                this.formReset();
                this.hideForm();
            },
            createCampaign: function (e) {
                e.preventDefault();
                $('.btn-campaign').addClass('disabled');
                var data = Backbone.Syphon.serialize(this);
                this.trigger("form:submit", data);
            },
            hideForm: function () {
                // hide the form
                $(this.$el).addClass("hidden");
            },
            getPPCRecommendation: function (e) {
                e.preventDefault();

                // if it is an a la carte campaign just return out of here
                if (!this.model.get("isdynamic")) { return false; }

                var locs = this.model.get("locations") || [],
                    occs = this.model.get("occupations") || [];

                // see if they have 1 loc/occ or have selected multiple  
                if ((locs.length > 1) || (occs.length > 1)) {
                    // multiple selected, get the default ppc
                    this.trigger("show:recommendations");
                } else if ((locs.length == 1) || (occs.length == 1)) {
                    // only one selected, use them to get the recommendation, like always
                    this.trigger("show:recommendations", { location: locs[0], occupation: occs[0] });
                } else {
                    // they haven't chosen anything, just return the highest
                    this.trigger("show:recommendations");
                }
            },
            templateHelpers: function () {
                return {
                    isEdit: true,
                    ShowCampaignType : true,
                    newCampaignForm: false,
                    isClone: false,
                    customer: this.model.get('customer'),
                    statuses:this.options.statuses,
                    canActivate: CommandCenter.roleForActivity("activate campaign"),
                    campaignStatus: function () {
                        return this.CampaignStatusID;
                    },
                    hasLocations: function () { return (this.locations || []).length },
                    locationString: _.chain(this.model.get('locations')).sortBy('Name').pluck('Name').map(function (val, key) {
                        return '<span class="label label-cc-default">' + val + '</span>';
                    }).value().join(" "),
                    hasOccupations: function () { return (this.occupations || []).length },
                    occupationString: _.chain(this.model.get('occupations')).sortBy('Name').pluck('Name').map(function (val, key) {
                        return '<span class="label label-cc-default">' + val + '</span>';
                    }).value().join(" "),
                    isCampaignFeedEnabled: this.model.get('iscampaignfeedenabled'),
                    StartDate: this.model.get('StartDate') ? moment(this.model.get('StartDate')).format('MM/DD/YYYY') : '',
                    EndDate: this.model.get('EndDate') ? moment(this.model.get('EndDate')).format('MM/DD/YYYY') : ''
                }
            }
        });

        View.CreateWarningView = Marionette.ItemView.extend({
            id: "createCampaign-warning",
            template: warningTpl,
            templateHelpers: function () {
                return {
                    isDynamic: this.options.isDynamic,
                    warningContent: this.options.bodyText,
                    btnContinueText: this.options.btnText
                };
            },
            events: {
                "click #btnReturn": "btnReturnHandler"
            },
            btnReturnHandler: function () {
                $('#campaign-create-warning-Modal').modal('hide');
                $('.btn-save').each(function () {
                    $(this).removeAttr('disabled');
                });
            }
        });

        View.BooleanExpressionView = Marionette.ItemView.extend({
            id: "boolean-wrap",
            template: expressionTpl,
            templateHelpers: function () {
                return {
                    bodyContent: this.options.expression
                };
            }
        });

          /*          Start : Criteria View            */
        View.CampaignCriterion = Marionette.ItemView.extend({
            tagName: "tbody",

            className: "criterion-table-body",

            template: criterionTpl,

            attributes: function () {
                return {
                    id: this.model.get('ScreenOrder')
                }
            },

            initialize: function (options) {

            },

            events: {
                "click .btn-add-criteria": "addNewCriteriaRow",
                "click .btn-remove-criteria": "removeCriteriaRow"
            },

            onRender: function () {
                if (this.model.get('selected')) {
                    this.ui.checkbox.addClass('checked');
                }
            },

            onShow: function () {

            },
            templateHelpers: function () {
                return {
                    id: this.model.get('ScreenOrder')
                };
            },

            addNewCriteriaRow: function (e) {
                //  this.$el.append(new view.CampaignCriterionRelation().render().el);
                e.preventDefault();
                this.trigger("add:MoreCriteria:clicked");
            },

            removeCriteriaRow: function (e) {
                e.preventDefault();
                this.trigger("remove:criteria", { id: this.options.model.get("ScreenOrder") });

            }
        });

        View.CampaignCriteria = Marionette.CompositeView.extend({
            template: criteriaTpl,

            tagName: "div",

            childView: View.CampaignCriterion,

            childViewContainer: "table",

            emptyView: View.CampaignCriterion,

            initialize: function (options) {
                this.listenTo(this.options.collection, "change reset add remove", this.modelRemoved);
            },
            templateHelpers: function () {
                return {
                    submitBtnText: 'Save Changes',
                    targetingCritieriaCount: this.collection.length,
                    showTargetingCriteriaCount: true
                };
            },
            onShow: function() {
                $("#btnAddCampaignCriteria").text("Show/Add Criteria");
                $('[data-toggle="tooltip"]').tooltip();
            },
            events: {
                "click #btnAddCampaignCriteria": "displayCriteriaDropDownArea",
                "click #btnCreateCampaign": "submitCampaignForm",
                "click #btnViewCriteriaBolleanExpression": "showBooleanExpression",
                "click #btnViewJobsBasedOnCriteria": "showJobsBasedOnCritieria",
                "click .js-viewJobs": "showJobsBasedOnCritieria" // View Jobs When No Criteria View is Shown
            },

            collectionEvents: {
                "destroy": "modelRemoved"
            },

            modelRemoved: function () {
                if (!this.collection.length) {
                    this.triggerMethod("hideCriteriaDropDownArea");
                }
            },

            onChildviewCriteriaRelation: function (childView, model) {
                if (this.collection.length < 5) {
                    this.triggerMethod("add:connectingCondition:criteria");
                }
            },

            onChildviewAddMoreCriteriaClicked: function (childView, model) {
                if (this.collection.length < 5) {
                    this.triggerMethod('add:criteria:row',true);
                }
            },

            onChildviewRemoveCriteria: function (childView, model) {

                var thisitem = this.collection.get(model.id);
                var jobCount = this.model.campaignedJobs().length;
                this.collection.remove(thisitem);
                if (!this.collection.length) {
                    this.hideCriteriaDropDownArea();
                }
                if (this.model.get("IsDynamic")) {
                    $('#txtlblAllJobCampaignInfo')
                      .text("All jobs will be campaigned, if no campaign criteria (Locations, Occuapation or Custom key-values) is added.");

                } else {
                    $('#txtlblAllJobCampaignInfo')
                        .text("Only selected jobs will be campaigned.");
                }

                //add Keys for other dropdown if any exist
                this.triggerMethod('add:criteria:keyToExistingRow', thisitem);
            },

            onChildviewCriteriaValueChaged: function () {
                this.triggerMethod("show:Job:Count");
            },

            submitCampaignForm: function (e) {
                e.preventDefault();
                this.trigger("btn:CreateCampaign:clicked");
            },

            displayCriteriaDropDownArea: function (e) {
                e.preventDefault();
                $("#btnAddCampaignCriteria").hide();
                $("#lblAllJobCampaignInfo").hide();
                $(".js-viewJobs").hide();
                $(".criteria-dropdowns-area").fadeIn(1000);

                this.triggerMethod('add:criteria:row',false); //Add first Criteria row
            },

            hideCriteriaDropDownArea: function () {
                $(".criteria-dropdowns-area").hide();
                $("#btnAddCampaignCriteria").fadeIn();
                $(".js-viewJobs").fadeIn();
                $("#lblAllJobCampaignInfo").fadeIn();

            },

            showBooleanExpression: function (e) {
                e.preventDefault();
                this.trigger("btn:ShowBooleanExpression:clicked");
            },

            showJobsBasedOnCritieria: function (e) {
                e.preventDefault();
                this.trigger("btn:showJobsBasedOnCritieria:clicked");
            }
        });


          /*          ENDS : Criteria View            */


          /*          Selected/Campaigned Job View             */
        View.SelectedJob = Marionette.ItemView.extend({
            template: campaignedJobTmpl,
            tagName: "tr",
            initialize: function (options) {
                this.isCampaignFeedEnabled = options.isCampaignFeedEnabled;
                this.IsDynamic = options.IsDynamic;
            },
            events: {
                "click .remove-from-campaign": "removeJob"
            },
            templateHelpers: function () {
                return {
                    isCampaignFeedEnabled: this.isCampaignFeedEnabled,
                    IsDynamic: this.IsDynamic
                };
            },
            removeJob: function (e) {
                e.preventDefault();

                this.model.set("selectedForCampaign", false);

                this.trigger("job:unselected", { job: this });
            }
        });

        View.SelectedJobList = Marionette.CompositeView.extend({
            id: "selectedJobsList",
            template: campaignedJobsTmpl,
            childView: View.SelectedJob,
            childViewContainer: "tbody",
            childViewOptions: function (model, index) {
                return {
                    isCampaignFeedEnabled: this.isCampaignFeedEnabled,
                    IsDynamic: this.IsDynamic
                }
            },
            initialize: function (options) {
                this.IsDynamic = options.IsDynamic;
                this.isCampaignFeedEnabled = options.isCampaignFeedEnabled;
                this.listenTo(this.collection, "add", this.collectionChanged);
                this.listenTo(this.collection, "remove", this.collectionChanged);
            },
            templateHelpers: function () {
                return {
                    isCampaignFeedEnabled: this.isCampaignFeedEnabled,
                    IsDynamic: this.IsDynamic
                };
            },
            onShow: function () {
                if (this.collection.length > 0) {
                    $('.selectedJobList').show();
                    $(".selected-job-count").text(this.collection.length);
                    // toogle collapse button icon
                    $(".selectedJobCountToggle").toggleClass("fa-angle-right fa-angle-down");

                    // toggle showing the selected jobs
                    $(".selectedJobs").toggleClass("hidden");
                }
                if (this.IsDynamic) {
                    $('#txtlblAllJobCampaignInfo')
                      .text("All jobs will be campaigned, if no campaign criteria (Locations, Occuapation or Custom key-values) is added.");

                } else {
                    $('#txtlblAllJobCampaignInfo')
                        .text("Only selected jobs will be campaigned.");
                }
            },
            collectionChanged: function () {
                // update selected job count
                this.triggerMethod('update:jobcount', this.collection);
                if (this.IsDynamic) {
                    $('#txtlblAllJobCampaignInfo')
                      .text("All jobs will be campaigned, if no campaign criteria (Locations, Occuapation or Custom key-values) is added.");

                } else {
                    $('#txtlblAllJobCampaignInfo')
                        .text("Only selected jobs will be campaigned.");
                }
            },

            onChildviewJobUnselected: function (childView, model) {
                this.triggerMethod('job:unselected', model);
                this.triggerMethod('uncampaign:job', model);
                var checkBox = $("#toggleSelectAll");
                if (checkBox.prop("checked")) {
                    checkBox.prop("checked", !checkBox.prop("checked"));
                    $(".switch").attr('data-original-title', 'Select All Jobs.');
                }
            },
            events: {
                "click .selectedJobCountToggle": "toggleSelectedJobs"
            },
            toggleSelectedJobs: function (e) {
                e.preventDefault();
                // toogle collapse button icon
                $(".selectedJobCountToggle").toggleClass("fa-angle-right fa-angle-down");

                // toggle showing the selected jobs
                $(".selectedJobs").toggleClass("hidden");
            }
        });
          /*          ENDS : Selected/Campaigned Job View            */
        
          /* ALL Job List*/
        View.JobBasedOnCriteria = Marionette.ItemView.extend({
            template: jobTemplate,
            tagName: "tr",
            initialize: function (options) {
                this.customerId = options.customerId;
                this.isCampaignFeedEnabled = options.isCampaignFeedEnabled;
                this.IsDynamic = options.IsDynamic;
            },
            templateHelpers: function () {
                var cId = this.customerId;
                return {
                    isCampaignFeedEnabled: this.isCampaignFeedEnabled,
                    IsDynamic: this.IsDynamic
                }
            },
            modelEvents: {
                'change': 'render'
            },
            events: {
                "click .campaign-toggle": "campaignToggle"
            },
            campaignToggle: function (e) {
                e.preventDefault();
                // add the selected job to the collection
                if (this.model.get("selectedForCampaign")) {
                    this.model.set("selectedForCampaign", false);
                    $(this.$el).find("button").attr("title", "Add to Campaign");
                    this.trigger("job:unselected", { job: this });
                } else {
                    this.model.set("selectedForCampaign", true);
                    $(this.$el).find("button").attr("title", "Remove from Campaign");
                    this.trigger("job:selected", { job: this });
                }

            }
            
        });
        View.JobListBasedOnCriteria = Marionette.CompositeView.extend({
            id: "jobs",
            template: jobsTemplate,
            initialize: function(options) {
                this.IsDynamic = options.IsDynamic;
                this.isCampaignFeedEnabled = options.isCampaignFeedEnabled;
            },
            templateHelpers: function () {
                return {
                    isCampaignFeedEnabled: this.isCampaignFeedEnabled,
                    IsDynamic: this.IsDynamic
                };
            },
            events: {
                "click .js-add-all-jobs": "campaignAllJobs"
            },
            onShow: function () {
                //Enable Bootstrap tooltip
                $('[data-toggle="tooltip"]').tooltip();
            },
            childView: View.JobBasedOnCriteria,
            childViewContainer: "tbody",
            childViewOptions: function (model, index) {
                return {
                    customerId: this.customerId,
                    IsDynamic: this.IsDynamic,
                    isCampaignFeedEnabled: this.isCampaignFeedEnabled,
                }
            },
            onChildviewJobSelected: function (childView, model) {
                this.triggerMethod('job:selected', model);
            },
            onChildviewJobUnselected: function (childView, model) {
                this.triggerMethod('job:unselected', model);

                var checkBox = $("#toggleSelectAll");
                if (checkBox.prop("checked")) {
                    checkBox.prop("checked", !checkBox.prop("checked"));
                    $(".switch").attr('data-original-title', 'Select All Jobs.');
                }
            },
            campaignedJobsChanged: function (job) {
                var jobItem = this.collection.findWhere({ id: job.id });
                if (jobItem !== undefined && jobItem !== null) {
                    jobItem.set("selectedForCampaign", false);
                }
            },
            campaignAllJobs: function (e) {
                e.preventDefault();
                var self = this;
                var collectionItems = self.collection;

                var checkBox = $("#toggleSelectAll");
                checkBox.prop("checked", !checkBox.prop("checked"));

                if (checkBox.prop("checked")) {
                    $(".switch").attr('data-original-title', 'Deselect All Jobs.');
                    _.each(collectionItems.models,
                        function (jobItem) {
                            // mark all the items shown as selected
                            self.trigger('job:selected:all', jobItem);
                            jobItem.set("selectedForCampaign", true);

                        });
                } else {
                    $(".switch").attr('data-original-title', 'Select All Jobs.');
                    _.each(collectionItems.models, function (jobItem) {

                        self.trigger('job:unselected:all', jobItem);
                        // mark all the items shown as selected
                        jobItem.set("selectedForCampaign", false);

                    });
                }
            }
        });
          /* ENDS : JOB List */

          /* Job count */
        View.JobCount = Marionette.ItemView.extend({

            template: jobCountTemplate,

            tagName: "div",

            templateHelpers: function () {
                return {
                    title: "Total Job Count",
                    jobCount: this.options.count
                };
            }
        });
          /* Ends Boolean Work */

          /*Ends Boolean*/
      
    });

    return CommandCenter.CampaignsApp.Edit.View;
});