define(["app", "apps/campaigns/edit/edit_view", "apps/campaigns/common/utility", "selectize", "moment", "toastr"], function (CommandCenter, View, $utility, selectize, moment, toastr) {
    CommandCenter.module("CampaignsApp.Edit", function (Edit, CommandCenter, Backbone, Marionette, $, _) {
        Edit.Controller = {
            editCampaign: function(id) {
                require(['common/views', 'models/Campaign', 'models/Customer', 'datepicker', 'chosen'],
                    function(CommonViews) {
                        var fetchCampaign = CommandCenter.request("campaign:entity", id);
                        var fetchstatuses = "";
                        // loading data view
                        var customerCampaign,
                            loadingBasicFieldSetView = new View.BasicFieldSetLoading(),
                            campaignLayout = new View.Layout(),
                            basicCampaignFieldView,
                            headerView,
                            criteriaView,
                            criteriaId,
                            criteriaCollection,
                            thisController = Edit.Controller;

                        CommandCenter.contentRegion.show(campaignLayout);
                        campaignLayout.basicFieldList.show(loadingBasicFieldSetView);

                        toastr.options = {
                            "closeButton": true,
                            "newestOnTop": true,
                            "positionClass": "toast-bottom-left",
                            "preventDuplicates": true
                        };

                        var showCustomerLevelInfo = function(customer) {
                            // show the customer sidebar menu
                            var customerSidebar = new CommonViews.CustomerSidebarMenu({ model: customer });
                            customerSidebar.render();
                            //show Customer Icon
                            var cI = new CommonViews.CustomerIndicator({ model: customer });
                            CommandCenter.customerIndicatorRegion.show(cI);
                            //show customer Budget Info
                            var customerBudgetInfo = new CommonViews.CustomerBudgetInfo({ model: customer });
                            campaignLayout.customerBudgetInfo.show(customerBudgetInfo);

                        }

                        var fetchCampaignHandler = function(campaign) {
                            customerCampaign = campaign;
                            var statusId = campaign.get('CampaignStatusID');
                           
                            fetchstatuses = CommandCenter.request("campaign:statuses", campaign.get('CampaignId'), statusId);
                            var tempIndex = 0, statuses = [];


                            $.when(fetchstatuses).done(function(data) {

                                    while (data.get(tempIndex) != undefined) {
                                        statuses.push(data.get(tempIndex++));
                                    }

                                    // setup the new campaign
                                    campaign.set({ customer: campaign.get('ProviderID') });

                                    var customerId = campaign.get('ProviderID');

                                    basicCampaignFieldView = new View.BasicFieldList({ model: campaign, statuses: statuses }),

                                    headerView = new View.Header({ model: campaign });

                                    campaignLayout.header.show(headerView);


                                    headerView.on("btn:saveCampaign:clicked",
                                        function() {
                                            campaignLayout.triggerMethod("SaveCampaignClicked");
                                        });

                                   
                                    campaignLayout.basicFieldList.show(basicCampaignFieldView);

                                   
                                   if (!campaign.get('IsFeedBasedCustomer')) {
                                            criteriaCollection = new Backbone.Collection(campaign.get('Targetings'));
                                            criteriaView = new View.CampaignCriteria({ model: campaign, collection: criteriaCollection });

                                            campaignLayout.criteria.show(criteriaView);

                                            if (criteriaCollection.length > 0) {
                                                _.each(criteriaCollection.models, function (item) {
                                                    item.set({ id: item.ScreenOrder || item.get("ScreenOrder") });
                                                    item.id = item.ScreenOrder || item.get("ScreenOrder");

                                                    Edit.Controller.initializeCriteriaView(item, customerId, campaignLayout);
                                                });

                                            }

                                            //Criteria View Events

                                            criteriaView.on("btn:ShowBooleanExpression:clicked", function () {
                                                var getBooleanExpression = CommandCenter.request("TargetingCriteria:Get:BooleanExpress", $utility.criteria.createCriteriaExpression());

                                                $.when(getBooleanExpression)
                                                    .done(function (data) {
                                                        campaignLayout.booleanExpression.show(new View.BooleanExpressionView({ expression: JSON.stringify(data) }));
                                                        $('#boolean-expression-Modal').modal('show');
                                                    });


                                            });

                                            criteriaView.on("btn:showJobsBasedOnCritieria:clicked", function () {

                                                thisController.staticCampaign({ customer: customerId, baseview: campaignLayout, campaign: campaign });

                                            });

                                            criteriaView.on("add:criteria:keyToExistingRow", function (item) {
                                                setTimeout($utility.jobs.jobCountView(campaignLayout, customerId,View), 0);
                                                Edit.Controller.refreshExistingCriteriaKey(customerId);
                                            });


                                            var addCriteriaRowHandler = function (value) {
                                                //Display or update Job Count
                                                $utility.jobs.jobCountView(campaignLayout, customerId,View);

                                                Edit.Controller.addCriteriaRowHandler(campaign.get('ProviderID'), criteriaCollection, value, campaignLayout);
                                            }

                                            criteriaView.on("add:criteria:row", addCriteriaRowHandler);

                                            criteriaView.on("btn:CreateCampaign:clicked", function () {
                                                campaignLayout.triggerMethod("SaveCampaignClicked");
                                            });

                                            criteriaView.on("show:Job:Count", $utility.jobs.jobCountView(campaignLayout, customerId,View));
                                        }
                                    
                                    
                                    

                                //TODO:Knitesh: If it's a Static Campaign, show Jobs which are in Campaign. Does it matter anymore as User will be able to convert Static to Dynamic and vice versa

                                   var fetchingJobs = campaign.get('campaignedJobs').fetch({
                                       data: { onlyCurrentJobs: true },
                                       cache: false,
                                       async: false
                                   });

                                   $.when(fetchingJobs).done(function (jobs) {
                                       Edit.Controller.showCampaignedJobs({
                                           baseview: campaignLayout,
                                           campaign: campaign
                                       });
                                   });
                            });

                            return campaign.get('ProviderID');
                        }

                        //TODO: Extract below function to some common module
                       

                        var fetchCustomerHandler = function(customerId) {
                            // get the customer information
                            var fetchingCustomer = CommandCenter.request("customer:entity", customerId);
                            $.when(fetchingCustomer).done(showCustomerLevelInfo);
                        }

                        $.when(fetchCampaign)
                            .then(fetchCampaignHandler)
                             .fail(function () {
                                 campaignLayout.basicFieldList.reset();
                                 campaignLayout.errorRegion.show(new CommonViews.Error404());
                             })
                            .done(fetchCustomerHandler);


                        /** Save Campaign Event**/
                        campaignLayout.on("Campaign:save", function (data) {

                            //check if any row has empty key
                            if ($utility.criteria.isAnyFieldInCriteriaRowsEmpty()) {
                                $('[class*="btn-save"]').attr('disabled', false);
                                return;
                            }

                            var self = this;
                                //based on whether we have Selected Jobs create dynamic or statis campaign
                                //TODO: find out a best way to decalre below variables
                            if (data.IsDynamic !== "false") {
                                campaignLayout.warning.show(new View.CreateWarningView({
                                    isDynamic: true,
                                    btnText: 'Save Dynamic Campaign'
                                }));
                            } else {
                                campaignLayout.warning.show(new View.CreateWarningView({
                                    isDynamic: false,
                                    btnText: 'Save Static Campaign'
                                }));
                            }
                              
                                $('#campaign-create-warning-Modal').modal({ backdrop: 'static', keyboard: false });

                                $('#campaign-create-warning-Modal #btnContinue').click(function(e) {

                                        _.each($(".btn-save-spinner"), function (item) {
                                            $(item).show();
                                        });

                                        e.preventDefault();
                                        $('#campaign-create-warning-Modal').modal('hide');
                                        

                                        var noweditCampaign = new Date();

                                        var startDateToday = new
                                                Date(noweditCampaign.getTime() +noweditCampaign.getTimezoneOffset() * 60000),
                                            startDateInCamp = new Date(data.startdate);

                                        startDateToday = new Date(startDateToday.getFullYear(), startDateToday.getMonth(), startDateToday.getDate());

                                        if (startDateInCamp) {
                                            var startDateInCampaign = new Date(startDateInCamp.getFullYear(),startDateInCamp.getMonth(),startDateInCamp.getDate());
                                        }

                                        var campaignStatus = customerCampaign.get('status');
                                        var isActivateCampaign = (data && data.campaignstatusid === "1");
                                        var isValidationError = false;
                                        var cId = data.ProviderID;
                                        // compile the list of jobids
                                        var jobs = customerCampaign.campaignedJobs().models;
                                        data.Jobs = [];
                                        if (data.IsDynamic === "false") {
                                            if (jobs.length > 0) {
                                                _.each(jobs, function (job) {
                                                    data.Jobs.push({ JobId: job.id });
                                                });
                                            }
                                        }


                                        // hide the form errors
                                        $('.form-group').removeClass('has-error');
                                        var me = this;
                                        var options = {
                                            success: function (model, response, options) {
                                                _.each($(".btn-save-spinner"),function(item) {
                                                        $(item).hide();
                                                    });
                                                // clear the campaigns from cache
                                                Backbone.fetchCache.clearItem("api/customers/" + cId);
                                                CommandCenter.trigger("campaigns:list", cId);
                                            },
                                            error: function (model, response, options) {
                                                _.each($(".btn-save-spinner"), function (item) {
                                                    $(item).hide();
                                                });
                                                // requires errors response from the server to get here
                                                $('[class*="btn-save"]').removeAttr('disabled');

                                                $('.form-errors').show();
                                                //TODO: Structure of error messages has been changed from Api, Confirm that they are passing correct Property Name in "name"
                                                var serverErrors = response.responseJSON;
                                                var errors = [];

                                                if (serverErrors) {
                                                    _.each(serverErrors, function (item) {
                                                        if (!item.message) {
                                                            errors.push({
                                                                name: "",
                                                                message: "An Error has occured on the Server"
                                                            });
                                                        } else {
                                                            errors.push({
                                                                name: item.name,
                                                                message: item.message
                                                            });
                                                        }
                                                    });
                                                }

                                                campaignLayout.errorRegion.show(new CommonViews.FormErrors({errors: errors}));
                                            }
                                        };

                                        // client-side validation
                                        Backbone.listenTo(customerCampaign, 'invalid', function (model, errors, options) {

                                            _.each($(".btn-save-spinner"), function (item) {
                                                $(item).hide();
                                            });
                                            _.each(errors, function (error) {
                                                isValidationError = true;
                                                var controlGroup = $('[name="' + error.name + '"]').parent();
                                                controlGroup.addClass('has-error');
                                            }, this);

                                            $('[class*="btn-save"]').removeAttr('disabled');

                                            isValidationError = true;
                                            campaignLayout.errorRegion.show(new CommonViews.FormErrors({ errors: errors }));
                                        });

                                        if (isValidationError === false &&
                                            startDateToday &&
                                            startDateInCampaign &&
                                            (campaignStatus && campaignStatus.toLowerCase() === 'pending') &&
                                            isActivateCampaign) {
                                            if ((startDateToday.getTime() !== startDateInCampaign.getTime()) &&
                                                (!data.startDtOverride)) {
                                                data.isEdit = true;
                                                var campaignJobs = campaign.get('jobs');
                                                data.jobs = campaignJobs;
                                                var validationErrors = campaign.validate(data, options);
                                                if (!validationErrors) {
                                                    $('#startDateModal').modal('show');
                                                    return;
                                                }
                                            }
                                        }
                                        if (data.startDtOverride) {
                                            data.startdate = moment().utc().format('MM/DD/YYYY');
                                        }
                                        data.isEdit = true;
                                        data.Targetings = $utility.criteria.createCriteriaObject();
                                        customerCampaign.save(data, options);
                                    });
                            });

                    });
            },

            showCampaignedJobs: function (args) {
                var campaign = args.campaign,
                    baseView = args.baseview,
                     newCampaign = baseView.basicFieldList.currentView.model;;
               
                var jobView = new View.SelectedJobList({
                    collection: campaign.campaignedJobs(),
                    isCampaignFeedEnabled: campaign.get('IsFeedBasedCustomer'),
                    IsDynamic: campaign.get('IsDynamic')
                });

                baseView.campaignedJobsRegion.show(jobView);


                jobView.on("update:jobcount",function(collection) {
                        $(".selected-job-count").text(collection.length);
                        if (collection.length > 0) {
                            $('.selectedJobList').show(500);
                        } else {
                            $('.selectedJobList').hide(500);
                        }
                    });
                jobView.on("job:unselected",function(item) {
                        campaign.campaignedJobs().remove(item.job.model);
                    });

                baseView.on("job:selected", function (item) {
                    newCampaign.campaignedJobs().add(item.job.model);

                });
                baseView.on("job:unselected", function (item) {
                    newCampaign.campaignedJobs().remove(item.job.model);
                });

                baseView.on("job:selected:all", function (item) {
                    newCampaign.campaignedJobs().add(item);

                });
                baseView.on("job:unselected:all", function (item) {
                    newCampaign.campaignedJobs().remove(item);
                });
            },

            /* Static campaigning */
            //TODO: KNitesh Extract to Common Module
            staticCampaign: function (args) {
                require(['models/Campaign', 'models/Job', 'backbone.fetch-cache'], function () {
                    var id = args.customer,
                        baseView = args.baseview,
                        campaign = args.campaign,
                        newCampaign = baseView.basicFieldList.currentView.model,
                        targeting = $utility.criteria.createCriteriaObject();

                    $utility.jobs.count(id).done(function (jobcount) {
                        var jobListArgs = {
                            customer: id,
                            targeting: targeting,
                            selectedJobs: newCampaign.campaignedJobs(),
                            jobcount: jobcount,
                            campaign: campaign
                        };
                        Edit.Controller.showJobs(baseView, jobListArgs);
                    });
                }); // end require
            },
            //TODO:Knitesh Extract to Common Module
            showJobs: function (baseView, args) {
                if (args.jobcount <= 500 || args.showTheJobs) {
                    // show the jobs
                    require(['common/views', 'models/Job'], function (commonViews) {

                        // loading data view
                        var loadingView = new commonViews.Loading({
                            title: "Loading Job Data",
                            message: "Please wait while the job data is loading."
                        });

                        baseView.jobListBasedOnCriteria.show(loadingView);

                        //TODO: Knitesh- Send targeting Object
                        var fetchingJobs = CommandCenter.request("job:entities", args.customer, args.targeting);

                        $.when(fetchingJobs).done(function (jobs) {

                            // see if the user has already put the job in the campaign
                            if (args.selectedJobs && args.selectedJobs.length > 0) {
                                // user has selected jobs to be campaigned
                                var selected = _.pluck(args.selectedJobs.models, 'id');
                                var available = _.pluck(jobs.models, 'id');
                                var alreadySelected = _.intersection(selected, available);
                                _.each(alreadySelected, function (jId) {
                                    jobs.findWhere({ id: jId }).set("selectedForCampaign", true);
                                });
                            }

                            var jobListView = new View.JobListBasedOnCriteria({
                                collection: jobs,
                                customerId: args.customer,
                                IsDynamic: args.campaign.get("IsDynamic"),
                                isCampaignFeedEnabled: args.campaign.get("IsFeedBasedCustomer")
                            });

                            baseView.jobListBasedOnCriteria.show(jobListView);

                            baseView.on("childview:uncampaign:job", function (childview, args) {
                                if (jobs.get(args.job.model) !== undefined) {
                                    jobs.get(args.job.model).set("selectedForCampaign", false);
                                }
                            });

                            $("table").tablesorter({ debug: false });

                            jobListView.on("job:selected", function (data) {
                               
                                baseView.trigger('job:selected', data);
                            });
                            jobListView.on("job:unselected", function (data) {
                               
                                baseView.trigger('job:unselected', data);
                            });
                            jobListView.on("job:selected:all", function (data) {
                                // baseView.trigger('job:selected', data);
                                baseView.trigger('job:selected:all', data);
                            });
                            jobListView.on("job:unselected:all", function (data) {
                                // baseView.trigger('job:selected', data);
                                baseView.trigger('job:unselected:all', data);
                            });
                        })
                         .fail(function () {
                             baseView.jobListBasedOnCriteria.reset();
                             baseView.jobListBasedOnCriteria.show(new commonViews.Error404({ title: '...', message: "An error occurred while retreiving Jobs list. Please try later." }));
                         });

                    });
                    $('.selectedJobList')[0].scrollIntoView(true);
                } else {
                    // clear the jobs, if currently shown
                    baseView.jobListBasedOnCriteria.empty();

                    // show a button to confirm they want to load the volume of data
                    require(['common/views'], function (commonViews) {
                        var areYouSureView = new commonViews.AreYouSure({ customerId: args.customer, targeting: args.targeting, jobcount: args.jobcount, selectedJobs: args.selectedJobs });

                        baseView.jobListBasedOnCriteria.show(areYouSureView);

                        areYouSureView.on("show:jobs", function (args) {
                            args.showTheJobs = true;
                            Edit.Controller.showJobs(baseView, args);
                        });
                    });
                }
                //Scroll to Job View
                $(".jobListBasedOnCriteria")[0].scrollIntoView(true);
            },
            /* end of Static campaigning */

            /* Utility Functions */

         

            initializeCriteriaView: function (item, customerId,baseView) {
                var rowId = item.id || item.get("id");


                var onChangeCriteriaRelationHandler = function (value) {
                    $utility.jobs.jobCountView(baseView, customerId, View);
                }
                var onChangeCriteriaConditionHandler = function (value) {
                    $utility.jobs.jobCountView(baseView, customerId, View);
                }
                //Criteria Relation Drop Down
                var $criteriaFunction = $('#' + rowId + ' .criterionRelations').selectize({
                    sortField: 'text',
                    onChange: onChangeCriteriaRelationHandler
                });

                //Criteria Boolean Conditin Drop Down
                var $criteriaConditionDropDown = $('#' + rowId + ' .booleanConditions').selectize({
                    sortField: 'text',
                    onChange: onChangeCriteriaConditionHandler
                });
               
                var onChangeCriteriaValueHandler = function (value) {
                    var self = this;
                    Edit.Controller.onChangeCriteriaValueHandler(self, value, baseView, customerId);
                }

                var $selectValuesdropDown = $('#' + rowId + ' .targetValues')
                    .selectize({
                        plugins: ['remove_button'],
                        maxItems: null,
                        persist: true,
                        highlight: true,
                        hideSelected: true,
                        onChange: onChangeCriteriaValueHandler,
                        sortField: 'value'
                    }); //
                var onChangeCriteriaKeyHandler = function (value) {
                 
                    var self = this;
                   $utility.criteria.onChangeCriteriaKeyHandler(self,
                            value,
                            customerId,
                            $selectValuesdropDown,
                            $criteriaConditionDropDown);
                }

                var selectValuesdropDown = $selectValuesdropDown[0].selectize;
                var conditionDropDown = $criteriaConditionDropDown[0].selectize;
                var criteriaFunction = $criteriaFunction[0].selectize;

                var $selectKeydropDown = $('#' + rowId + ' .targetKeys')
                                        .selectize({
                                            maxItems: 1,
                                            hideSelected: true,
                                            onChange: onChangeCriteriaKeyHandler,
                                        }); // Cri


                var selectKeydropDown = $selectKeydropDown[0].selectize;
                /*
                *Intialize Criteria Key drop downs
               */

                var fetchCustomerKeys = CommandCenter.request('TargetingCriteria:key', customerId);


                $.when(fetchCustomerKeys).then(function (data) {
                        var dataForKeyDropDown = _.map(data.models,
                            function (item) {
                                return { text: item.get('Text'), value: item.get('Value') }
                            });
                        //Check if any of above value is already used

                        var selectedKey = $(".targetKeys > .full.has-items>div");

                        if (selectedKey.length > 0) {

                            _.each(selectedKey,function (keys) {
                                    dataForKeyDropDown = _.filter(dataForKeyDropDown,function (keyItem) {
                                            return keyItem.text !== keys.textContent;
                                        });
                                });
                        }

                        selectKeydropDown.addOption(dataForKeyDropDown);
                        selectKeydropDown.refreshOptions(false);
                       
                    }).then(function() {
                        //Add Initial Items to Drop Down
                        var value = item.get('Criteria');
                        selectKeydropDown.addItem(value, true);

                        var conditionValues = $utility.criteria.getConditionDropDownValues(value);

                        if (value !== "Locations" && value !== "Occupations") {
                            selectValuesdropDown.settings.create = true;
                        }

                        conditionDropDown.load(function (callback) {
                            conditionDropDown.enable();
                            callback(conditionValues);
                        });

                    }).done(function () {
                        //TODO : Knitesh: - Repeating code from onChangeCriteriaKeyHandler -- Extract a commom module
                        var value = item.get('Criteria');

                        conditionDropDown.addItem(item.get('Condition'), true);

                        criteriaFunction.addItem(item.get('Function'), true);

                        selectValuesdropDown.load(function (callback) {
                            //get below result based on the value passed :value

                            var fetchCustomerTargetKeyValues = CommandCenter.request("TargetingCriteria:Key:Values", customerId, value);

                            $.when(fetchCustomerTargetKeyValues).then(function (data) {

                                var dataForValueDropDown = _.map(data.models, function (item) {
                                    return { text: item.get('Text'), value: item.get('Value') }
                                });

                                dataForValueDropDown.push({ text: "Select All/Clear All", value: '-9999' });

                                var results = dataForValueDropDown;

                                selectValuesdropDown.enable();

                                callback(results);

                            })
                            .done(function () {
                                if (value === "Locations" || value === "Occupations") {
                                    _.each(item.get('Values'),
                                        function (value) {
                                            selectValuesdropDown.addItem(value,true);

                                        });
                                } else {
                                    _.each(item.get('Values'),
                                       function (value) {
                                           selectValuesdropDown.createItem(value,true);

                                       });
                                }
                            })
                            .fail(function (jqXHR, textStatus, errorThrown) {
                                console
                                    .log('Error while getting Targetting Values:: ' + JSON.stringify(jqXHR) + errorThrown);
                            });

                        });

                    })
                    .fail(function (jqXhr, textStatus, errorThrown) {
                        console.log('Error while getting Targetting Keys: ' +JSON.stringify(jqXhr) +errorThrown);
                    });
               
            },
          
            addCriteriaRowHandler: function (customerId, criteriaCollection, show, baseView) {

                //return if you already have five rows or if this is the first time showing criteria row where Campaign has atleast one criteria and called for the first time
                if (criteriaCollection.length >= 5 || (criteriaCollection.length > 0 && !show)) 
                {
                    return;
                }
                //check if any row has empty key
                if ($utility.criteria.isAnyFieldInCriteriaRowsEmpty()) {
                    return;
                }

               var criteriaId = moment().unix();
             
               criteriaCollection.add({ "id": criteriaId, "ScreenOrder": criteriaId });

               var onChangeCriteriaRelationHandler = function (value) {
                   $utility.jobs.jobCountView(baseView, customerId, View);
               }
               var onChangeCriteriaConditionHandler = function (value) {
                   $utility.jobs.jobCountView(baseView, customerId, View);
               }
                //Criteria Relation Drop Down
               $('#' + criteriaId + ' .criterionRelations').selectize({
                   sortField: 'text',
                   onChange: onChangeCriteriaRelationHandler
               });

                //Criteria Boolean Conditin Drop Down
               var $criteriaConditionDropDown = $('#' + criteriaId + ' .booleanConditions').selectize({
                   sortField: 'text',
                   onChange: onChangeCriteriaConditionHandler
               });
              
                var onChangeCriteriaValueHandler = function (value) {
                    var self = this;
                    Edit.Controller.onChangeCriteriaValueHandler(self, value, baseView, customerId);
                }
                var $selectValuesdropDown = $('#' + criteriaId + ' .targetValues')
                    .selectize({
                        plugins: ['remove_button'],
                        maxItems: null,
                        persist: true,
                        highlight: true,
                        hideSelected: true,
                        onChange: onChangeCriteriaValueHandler,
                        sortField: 'value'
                    }); // Criteria Value Drop Down

                var selectValuesdropDown = $selectValuesdropDown[0].selectize;
                var conditionDropDown = $criteriaConditionDropDown[0].selectize;

                selectValuesdropDown.disable();
                conditionDropDown.disable();

                var onChangeCriteriaKeyHandler = function (value) {

                    var self = this;
                    $utility.criteria.onChangeCriteriaKeyHandler(self,value,
                            customerId,
                            $selectValuesdropDown,
                            $criteriaConditionDropDown);
                }

                var $selectKeydropDown = $('#' + criteriaId + ' .targetKeys')
                    .selectize({
                        maxItems: 1,
                        hideSelected: true,
                        onChange: onChangeCriteriaKeyHandler
                    }); // Criteria Key Drop Down

                /*
                 *Intialize Criteria Key drop downs
                */

                var fetchCustomerKeys = CommandCenter.request('TargetingCriteria:key', customerId);


                $.when(fetchCustomerKeys).done(function (data) {

                        var dataForKeyDropDown = _.map(data.models,function(item) {
                                return { text: item.get('Text'), value: item.get('Value') }
                            });
                        //Check if any of above value is already used

                        var selectedKey = $(".targetKeys > .full.has-items>div");

                        if (selectedKey.length > 0) {

                            _.each(selectedKey,function(keys) {
                                    dataForKeyDropDown = _.filter(dataForKeyDropDown,
                                        function(keyItem) {
                                            return keyItem.text !== keys.textContent;
                                        });
                                });
                        }

                        $selectKeydropDown[0].selectize.addOption(dataForKeyDropDown);
                        $selectKeydropDown[0].selectize.refreshOptions(false);
                    })
                    .fail(function(jqXhr, textStatus, errorThrown) {
                        console.log('Error while getting Targetting Keys: ' +
                            JSON.stringify(jqXhr) +
                            errorThrown);
                    });
            },

            onChangeCriteriaValueHandler: function (self, value, baseView, providerId) {

                var key = _.find(value, function (key) {
                    return key === "-9999";
                });
                if (key != null && key === "-9999") {
                    if (self.items.length === Object.keys(self.options).length) {
                        //self.setValue('', true);
                        self.clear(true);
                        self.refreshOptions(true);
                    } else {
                        var keys = _.keys(self.options);
                        self.setValue(_.without(keys, "-9999"), true);
                        self.refreshOptions(false);
                    }

                }

                $utility.jobs.jobCountView(baseView, providerId,View);

            },

            refreshExistingCriteriaKey: function (customerId) {
                var criteriaKey = $('form').find('select[name="criteriaKey"]');

                _.map(criteriaKey, function (key) {

                    var fetchCustomerKeys = CommandCenter.request('TargetingCriteria:key', customerId);

                    $.when(fetchCustomerKeys).done(function (data) {
                        var dataForKeyDropDown = _.map(data.models,
                            function (item) {
                                return { text: item.get('Text'), value: item.get('Value') }
                            });
                        //Check if any of above value is already used

                        var selectedKey = $(".targetKeys > .full.has-items>div");
                        if (selectedKey.length > 0) {
                            _.each(selectedKey, function (keys) {
                                dataForKeyDropDown = _.filter(dataForKeyDropDown,
                                    function (keyItem) {
                                        return keyItem.text !== keys.textContent;
                                    });
                            });
                        }
                        if ($(key)[0].selectize) {
                            $(key)[0].selectize.addOption(dataForKeyDropDown);
                            $(key)[0].selectize.refreshOptions(false);
                        }
                    })
                        .fail(function (jqXHR, textStatus, errorThrown) {
                            console.log('Error while getting Targetting Keys: ' +
                                JSON.stringify(jqXHR) +
                                errorThrown);
                        });


                });

            },

        /* End -- Utility Functions */
        }
    });//ENd Edit Controller

    return CommandCenter.CampaignsApp.Edit.Controller;
});