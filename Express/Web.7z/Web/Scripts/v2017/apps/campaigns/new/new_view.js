define(["app",
        "tpl!apps/campaigns/common/templates/layout.html",
        "tpl!apps/campaigns/common/templates/header.html",
        "tpl!apps/campaigns/common/templates/basic/campaignBasicFieldSet.html",

        "tpl!apps/campaigns/common/templates/Criteria/campaignCriteria.html",
        "tpl!apps/campaigns/common/templates/Criteria/campaignCriterion.html",

        "tpl!apps/campaigns/common/templates/Modal/generatedBooleanExpression.html",
        "tpl!apps/campaigns/common/templates/Modal/campaignCreateWarning.html",

        "tpl!apps/campaigns/common/templates/errors.html",

        "tpl!apps/campaigns/common/templates/Jobs/campaignedJob.html",
        "tpl!apps/campaigns/common/templates/Jobs/campaignedJobs.html",
        "tpl!apps/campaigns/common/templates/Jobs/job.html",
        "tpl!apps/campaigns/common/templates/Jobs/jobs.html",
        "tpl!apps/campaigns/common/templates/Jobs/jobCount.html",
        "moment",
        "bootstrap",
        "backbone.syphon",
        "lib/jquery.tablesorter",
        "numeral"
],
      function (commandCenter,
                newCampaignTpl,
                headerTemplate,
                basicFieldListTpl,
                criteriaTpl,
                criterionTpl,
                expressionTpl,
                warningTpl,
                errorsTemplate,
                selectedJobTemplate,
                selectedJobsTemplate,
                jobTemplate,
                jobsTemplate,
                jobCountTemplate,
                moment) {
          commandCenter.module("CampaignsApp.New.View", function (view, CommandCenter, Backbone, Marionette, $, _) {

              /* Boolean Work */
              view.NewCampaign = Marionette.LayoutView.extend({

                  template: newCampaignTpl,

                  tagName: "div",

                  regions: {
                      header: "#header",
                      basicFieldList: "#basic-field-list",
                      form: ".new-campaign-form",
                      booleanExpression: ".boolean-expression",
                      warning: ".warning-modal",
                      criteria: ".criteria",

                      selectedJobList: '.selectedJobList',

                      jobListBasedOnCriteria: '.jobListBasedOnCriteria',

                      errorRegion: ".form-errors",

                      customerBudgetInfo: "#customerBudgetInfo",

                      jobCount: ".js-job-count"
                  },

                  ui: {
                      campaignType: ".new-campaign-type",
                      selectedJobCount: ".selected-job-count"
                  },

                  events: {
                      "click .new-campaign-type > button": "switchCampaignType",
                      "click .selectedToggle": "toggleSelectedJobs"
                  },

                  childEvents: {
                      'update:jobcount': function (childView, collection) {
                          this.ui.selectedJobCount.text(collection.length);

                          // trigger a budget recalculation
                          $("#campaign-ppc").trigger("change");
                      },
                      'uncampaign:job': function (childView, job) {
                          this.triggerMethod('uncampaign:job', job);
                      }
                  },
                  onCreateCampaignClicked: function () {

                      /*Disable Create Button on Screen*/
                      $('[class*="btn-save"]').attr('disabled', true);
                      
                      var data = Backbone.Syphon.serialize(this);

                      this.trigger("Campaign:create",data);
                  },
                  switchCampaignType: function (e) {
                      e.preventDefault();

                      // don't do anything if they clicked the button that is already active
                      if ($(e.target).hasClass("active")) { return; }

                      $(e.target).parent().children().toggleClass("active");
                      $(this.ui.selectedJobCount).text(0);

                      this.triggerMethod("switch:campaign:type", this);
                  },

                  toggleSelectedJobs: function (e) {
                      e.preventDefault();

                      // toogle collapse button icon
                      $(".selectedToggle").toggleClass("fa-angle-right fa-angle-down");

                      // toggle showing the selected jobs
                      $("#selectedJobs").toggleClass("open");
                  }
              });

              view.Header = Marionette.ItemView.extend({

                  template: headerTemplate,

                  tagName: "div",

                  className: "col-xs-12",

                  templateHelpers: function () {
                      return {
                          headervalue: "Create a new Campaign",
                          submitBtnText: 'Create Campaign'
                      };
                  },

                  events: {
                      "click .btn-cancel": "goBackToHistory",
                      "click .btn-save": "createNewCampaign"
                  },

                  goBackToHistory: function (e) {
                      e.preventDefault();
                      Backbone.history.history.back();
                  },

                  createNewCampaign: function (e) {
                      e.preventDefault();
                      this.trigger("btn:CreateCampaign:clicked");
                  }
              });

              view.BasicFieldList = Marionette.ItemView.extend({

                  template: basicFieldListTpl,

                  tagName: "div",

                  attributes: {
                      "id": "newCampaignForm",
                      "role": "form"
                  },

                  ui: {
                      campaignName: "#campaign-name",
                      campaignCriteria: ".campaign-criteria",
                      campaignJobCount: "#campaign-job-count",
                      locationId: "#campaign-location",
                      occupationId: "#campaign-occupation",
                      ppcAmount: "#campaign-ppc",
                      budget: "#campaign-budget",
                      submitButton: ".btn-campaign",
                      getPPCRecommendation: "#get-ppc-recommendation",
                      campaignType: "#campaign-is-dynamic"
                  },

                  events: {
                      "click #utcTime": "showUtcTime",
                      "click .campaign-close": "uncampaign",
                      "submit": "createCampaign",
                      'click @ui.getPPCRecommendation': 'getPPCRecommendation',
                      "mouseover .dateRange": "setDatepickerElements"
                  },

                  onShow: function() {
                      //Enable Bootstrap tooltip
                      $('[data-toggle="tooltip"]').tooltip();
                  },

                  onCreateCampaignclicked: function () {
                  },
                  showUtcTime: function(e) {
                      e.preventDefault();
                      var date = new Date();
                      $('#utcTime')[0].innerHTML = date.toUTCString();
                  },
                  setDatepickerElements: function (ev) {
                      $('#createStartDate').datepicker({ autoclose: true, startDate: '-0d', clearBtn: true })
                          .on("changeDate", function () {
                              if ($("#createStartDate").datepicker('getFormattedDate').length > 0) {
                                  $('#createEndDate').datepicker('setStartDate', $('#createStartDate').datepicker('getFormattedDate'));
                              } else {
                                  $('#createEndDate').datepicker('setStartDate', '-0d');
                              }
                          });
                      $('#createEndDate').datepicker({ autoclose: true, startDate: '-0d', clearBtn: true })
                          .on("changeDate", function () {
                              $('#createStartDate').datepicker('setEndDate', $('#createEndDate').datepicker('getFormattedDate'));
                          });
                  },

                  changeCampaignType: function () {
                      if (this.model.get("isdynamic")) {
                          this.ui.getPPCRecommendation.removeClass("hidden");
                      } else {
                          this.ui.getPPCRecommendation.addClass("hidden");
                      }

                      this.ui.campaignType.val(this.model.get("isdynamic"));
                  },

                  formReset: function () {
                      // no need to reset the form if it isn't shown
                      if ($(this.$el).is(":hidden")) { return; }

                      this.ui.campaignName.val("");
                      this.ui.campaignJobCount.val("");
                      this.ui.campaignCriteria.empty();
                      this.ui.ppcAmount.val("");
                      this.ui.budget.val("");
                      this.ui.submitButton.removeClass("disabled");

                      // remove any form errors
                      $('.form-group, .input-group').removeClass('has-error');
                      $('.tab-pane.active .form-errors').hide();

                      // reactivate the filter box
                      $('.tab-pane.active .filter-box').removeAttr("disabled");
                  },
                
                  getPPCRecommendation: function (e) {
                      e.preventDefault();
                      this.trigger("show:recommendations");
                  },

                  templateHelpers: function () {
                      var todaysDate = moment().utc().format('MM/DD/YYYY');
                      return {
                          isEdit: false,
                          isClone: false,
                          newCampaignForm: true,
                          StartDate: todaysDate,
                          EndDate: '',
                          ShowCampaignType : false
                      };
                  }
              });
              //TODO :Knitesh - Extract to campaings/common/view.js file
              view.SubmitFormErrors = Marionette.ItemView.extend({
                  template: errorsTemplate,
                  tagName: "div",
                  className: "panel panel-danger",
                  templateHelpers: function () {
                      return {
                          errors: this.options.errors,
                          title: "Errors"
                      }
                  }
              });
              //TODO :Knitesh - Extract to campaings/common/view.js file
              view.SubmitFormMessages = Marionette.ItemView.extend({
                  template: errorsTemplate,
                  tagName: "div",
                  className: "panel panel-success",
                  templateHelpers: function () {
                      return {
                          errors: this.options.messages,
                          title: "Notifications"
                      }
                  }
              });

              /*Campaign Criteria AV-1531*/
              view.CampaignCriterion = Marionette.ItemView.extend({
                  tagName: "tbody",

                  className:"criterion-table-body",

                  template: criterionTpl,

                  attributes: function () {
                      return {
                          id: this.model.get('id')
                      }
                  },

                  initialize: function (options) {

                  },

                  events: {
                      "click .btn-add-criteria": "addNewCriteriaRow",
                      "click .btn-remove-criteria": "removeCriteriaRow",
                      "click .selectAllValues": "selectAllValuesHandler"
                  },

                  onRender: function() {
                      if (this.model.get('selected')) {
                          this.ui.checkbox.addClass('checked');
                      }
                  },

                  onShow: function () {
                      var self = this;
                      $("#" + self.model.get('id') + " .selectAllValues").change(function () {
                          var rowId = self.model.get('id');
                          if (this.checked) {
                              self.trigger("select:allValues", { row: rowId });
                          } else {
                              self.trigger("unSelect:allValues", { row: rowId });
                          }
                      });
                  },
                  templateHelpers: function() {
                      return {
                          id: this.model.get('id')
                      };
                  },

                  addNewCriteriaRow: function (e) {
                    //  this.$el.append(new view.CampaignCriterionRelation().render().el);
                      e.preventDefault();
                      this.trigger("add:MoreCriteria:clicked");
                  },

                  removeCriteriaRow: function (e) {
                      e.preventDefault();
                      this.trigger("remove:criteria", { id: this.options.model.get("id") });

                  }
              });

              view.CampaignCriteria = Marionette.CompositeView.extend({
                      template: criteriaTpl,

                      tagName: "div",

                      childView: view.CampaignCriterion,

                      childViewContainer: "table",

                      emptyView: view.CampaignCriterion,

                      initialize: function(options) {
                          this.listenTo(this.options.collection, "change reset add remove", this.modelRemoved);
                      },
                      templateHelpers: function () {
                          return {
                              submitBtnText: 'Create Campaign',
                              targetingCritieriaCount: this.collection.length,
                              showTargetingCriteriaCount: false
                          };
                      },

                      events: {
                          "click #btnAddCampaignCriteria": "displayCriteriaDropDownArea",
                          "click #btnCreateCampaign": "submitCampaignForm",
                          "click #btnViewCriteriaBolleanExpression": "showBooleanExpression",
                          "click #btnViewJobsBasedOnCriteria": "showJobsBasedOnCritieria",
                          "click .js-viewJobs": "showJobsBasedOnCritieria" // View Jobs When No Criteria View is Shown
              },

                  collectionEvents: {
                      "destroy": "modelRemoved"
                  },

                  modelRemoved: function () {
                      if (!this.collection.length) {
                          this.triggerMethod("hideCriteriaDropDownArea");
                      }
                  },

                  onChildviewCriteriaRelation: function (childView, model) {
                      if (this.collection.length < 5) {
                          this.triggerMethod("add:connectingCondition:criteria");
                      }
                  },

                  onChildviewAddMoreCriteriaClicked: function (childView, model) {
                      if (this.collection.length < 5) {
                          this.triggerMethod('add:criteria:row');
                      }
                  },

                  onChildviewRemoveCriteria: function (childView, model) {

                      var thisitem = this.collection.get(model.id);
                      var jobCount = this.model.campaignedJobs().length;
                      this.collection.remove(thisitem);

                      if (!this.collection.length) {
                          this.hideCriteriaDropDownArea();
                      }
                      if (jobCount > 0) {
                          $('#txtlblAllJobCampaignInfo')
                              .text(
                                  "Only selected jobs will be campaigned.");
                      } else {
                          $('#txtlblAllJobCampaignInfo')
                             .text(
                                 "All jobs will be campaigned, if no campaign criteria (Locations, Occuapation or Custom key-values) is added.");

                      }
                      //add Keys for other dropdown if any exist
                      this.triggerMethod('add:criteria:keyToExistingRow', thisitem);
                     
                      //Update Job Count

                      this.triggerMethod("show:Job:Count");
                  },

                  onChildviewSelectAllValues: function (row) {
                      this.triggerMethod('select:allValues',row);
                  },

                  onChildviewUnSelectAllValues: function (row) {
                      console.log("Select all Values in a drop down for " );
                      this.trigger("unselect:allValues", row);
                  },
                 

                  submitCampaignForm: function(e) {
                          e.preventDefault();
                          this.trigger("btn:CreateCampaign:clicked");
                  },

                  displayCriteriaDropDownArea: function (e) {
                      e.preventDefault();
                      $("#btnAddCampaignCriteria").hide();
                      $("#lblAllJobCampaignInfo").hide();
                      $(".js-viewJobs").hide();
                      $(".criteria-dropdowns-area").fadeIn(1000);

                      this.triggerMethod("show:Job:Count");

                      this.triggerMethod('add:criteria:row'); //Add first Criteria row
                  },

                  hideCriteriaDropDownArea: function () {
                      $(".criteria-dropdowns-area").hide();
                      $("#btnAddCampaignCriteria").fadeIn();
                      $(".js-viewJobs").fadeIn();
                      $("#lblAllJobCampaignInfo").fadeIn();
                    
                  },

                  showBooleanExpression: function (e) {
                      e.preventDefault();
                      this.trigger("btn:ShowBooleanExpression:clicked");
                  },

                  showJobsBasedOnCritieria: function(e) {
                      e.preventDefault();
                      this.trigger("btn:showJobsBasedOnCritieria:clicked");
                  }
              });

              /*End Campaign Criteria*/

              /* Job View for Static Campaigns */
              view.SelectedJob = Marionette.ItemView.extend({
                  template: selectedJobTemplate,
                  tagName: "tr",
                  events: {
                      "click .remove-from-campaign": "removeJob"
                  },
                  initialize: function (options) {
                      this.isCampaignFeedEnabled = options.isCampaignFeedEnabled;
                      this.IsDynamic = options.IsDynamic;
                  },
                  templateHelpers: function () {
                      return {
                          isCampaignFeedEnabled: this.isCampaignFeedEnabled,
                          IsDynamic: this.IsDynamic
                      };
                  },
                  removeJob: function (e) {
                      e.preventDefault();

                      this.model.set("selectedForCampaign", false);

                      this.trigger("job:unselected", { job: this });
                  }
              });
              view.SelectedJobList = Marionette.CompositeView.extend({
                  id: "selectedJobsList",
                  template: selectedJobsTemplate,
                  childView:  view.SelectedJob,
                  childViewContainer: "tbody",
                  childViewOptions: function (model, index) {
                      return {
                          isCampaignFeedEnabled: this.isCampaignFeedEnabled,
                          IsDynamic: this.IsDynamic
                      }
                  },
                  initialize: function (options) {
                      this.IsDynamic = false;//On Create Screen keep Campaign as Static
                      this.isCampaignFeedEnabled = false;// User should not be able to come to this screen if Is FeedBased Customer
                      this.listenTo(this.collection, "add", this.collectionChanged);
                      this.listenTo(this.collection, "remove", this.collectionChanged);
                  },
                  templateHelpers: function () {
                      return {
                          isCampaignFeedEnabled: this.isCampaignFeedEnabled,
                          IsDynamic: this.IsDynamic
                      };
                  },
                  collectionChanged: function () {
                      // update selected job count
                      this.triggerMethod('update:jobcount', this.collection);
                      if (this.collection.length === 0) {
                          $('#txtlblAllJobCampaignInfo')
                            .text(
                                "All jobs will be campaigned, if no campaign criteria (Locations, Occuapation or Custom key-values) is added.");

                      }else {
                          $('#txtlblAllJobCampaignInfo')
                              .text(
                                  "Only selected jobs will be campaigned.");

                      }
                  },

                  onChildviewJobUnselected: function (childView, model) {
                      this.triggerMethod('job:unselected', model);
                      this.triggerMethod('uncampaign:job', model);

                      var checkBox = $("#toggleSelectAll");
                      if (checkBox.prop("checked")) {
                          checkBox.prop("checked", !checkBox.prop("checked"));
                          $(".switch").attr('data-original-title', 'Select All Jobs.');
                      }
                  },
                  events: {
                      "click .selectedJobCountToggle": "toggleSelectedJobs"
                  },
                  toggleSelectedJobs: function (e) {
                      e.preventDefault();
                      // toogle collapse button icon
                      $(".selectedJobCountToggle").toggleClass("fa-angle-right fa-angle-down");

                      // toggle showing the selected jobs
                      $(".selectedJobs").toggleClass("hidden");
                  }
              });

              //TODO :Knitesh - Extract to campaings/common/view.js file
              view.JobBasedOnCriteria = Marionette.ItemView.extend({
                  template: jobTemplate,
                  tagName: "tr",
                  initialize: function (options) {
                      this.customerId = options.customerId;
                      this.isCampaignFeedEnabled = options.isCampaignFeedEnabled;
                      this.IsDynamic = options.IsDynamic;
                  }
                  ,
                  templateHelpers: function () {
                      var cId = this.customerId;
                      return {
                          isCampaignFeedEnabled: this.isCampaignFeedEnabled,
                          IsDynamic: this.IsDynamic
                      }
                  },
                  modelEvents: {
                      'change': 'render'
                 },
                  events: {
                      "click .campaign-toggle": "campaignToggle"
                  },
                  campaignToggle: function (e) {
                      e.preventDefault();
                      // add the selected job to the collection
                      if (this.model.get("selectedForCampaign")) {
                          this.model.set("selectedForCampaign", false);
                          $(this.$el).find("button").attr("title", "Add to Campaign");
                          this.trigger("job:unselected", { job: this });
                      } else {
                          this.model.set("selectedForCampaign", true);
                          $(this.$el).find("button").attr("title", "Remove from Campaign");
                          this.trigger("job:selected", { job: this });
                      }

                  }
              });
              view.JobListBasedOnCriteria = Marionette.CompositeView.extend({
                  id: "jobs",
                  template: jobsTemplate,
                  initialize: function() {
                      this.IsDynamic = false; //By Default on Create Make it False....
                      this.isCampaignFeedEnabled = false; // User should not be able to come on this page if It is a feed based customer
                  },
                  templateHelpers: function () {
                      return {
                          isCampaignFeedEnabled: this.isCampaignFeedEnabled,
                          IsDynamic: this.IsDynamic
                      };
                  },
                  onShow: function () {
                      //Enable Bootstrap tooltip
                      $('[data-toggle="tooltip"]').tooltip();
                  },
                  events: {
                      "click .js-add-all-jobs": "campaignAllJobs"
                  },
                  childView: view.JobBasedOnCriteria,
                  childViewContainer: "tbody",
                  childViewOptions: function (model, index) {
                      return {
                          customerId: this.customerId
                      }
                  },
                  onChildviewJobSelected: function (childView, model) {
                     
                      this.triggerMethod('job:selected', model);
                  },
                  onChildviewJobUnselected: function (childView, model) {

                      this.triggerMethod('job:unselected', model);

                      var checkBox = $("#toggleSelectAll");
                      if (checkBox.prop("checked")) {
                          checkBox.prop("checked", !checkBox.prop("checked"));
                          $(".switch").attr('data-original-title', 'Select All Jobs.');
                      }
                  },
                  campaignedJobsChanged: function (job) {
                      var jobItem = this.collection.findWhere({ id: job.id });
                      if (jobItem !== undefined && jobItem !==null) {
                          jobItem.set("selectedForCampaign", false);
                      }
                  },
                  campaignAllJobs: function (e) {
                      e.preventDefault();

                      var self = this;
                      var collectionItems = self.collection;

                      var checkBox = $("#toggleSelectAll");
                      checkBox.prop("checked", !checkBox.prop("checked"));

                      if (checkBox.prop("checked")) {
                          $(".switch").attr('data-original-title', 'Deselect All Jobs.');
                          _.each(collectionItems.models,
                              function(jobItem) {
                                  // mark all the items shown as selected
                                  self.trigger('job:selected:all', jobItem);
                                  jobItem.set("selectedForCampaign", true);

                              });
                      } else {
                          $(".switch").attr('data-original-title', 'Select All Jobs.');
                          _.each(collectionItems.models, function (jobItem) {

                              self.trigger('job:unselected:all', jobItem);
                              // mark all the items shown as selected
                              jobItem.set("selectedForCampaign", false);

                          });
                      }

                  }
              });

              /* End Job View for Static Campaigns */
              //TODO :Knitesh - Extract to campaings/common/view.js file
              view.BooleanExpressionView = Marionette.ItemView.extend({
                  id: "boolean-wrap",
                  template: expressionTpl,
                  templateHelpers: function () {
                      return {
                          bodyContent: this.options.expression
                      };
                  }
              });

              //TODO :Knitesh - Extract to campaings/common/view.js file
              view.CreateWarningView = Marionette.ItemView.extend({
                  id: "createCampaign-warning",
                  template: warningTpl,
                  templateHelpers: function () {
                      return {
                          isDynamic : this.options.isDynamic,
                          warningContent: this.options.bodyText,
                          btnContinueText: this.options.btnText
                      };
                  },
                  events : {
                      "click #btnReturn" : "btnReturnHandler"
                  },
                  btnReturnHandler: function () {
                      $('#campaign-create-warning-Modal').modal('hide');
                      $('.btn-save').each(function() {
                          $(this).removeAttr('disabled'); 
                      });
                  }
              });


              /* Job count */
              //TODO :Knitesh - Extract to campaings/common/view.js file
              view.JobCount = Marionette.ItemView.extend({

                  template: jobCountTemplate,

                  tagName: "div",

                  templateHelpers: function () {
                      return {
                          title: "Total Job Count",
                          jobCount: this.options.count
                      };
                  }
              });
              /* Ends Boolean Work */


             
          });

          return commandCenter.CampaignsApp.New.View;
      });