﻿define(["app", "apps/campaigns/list/list_view", 'moment'], function (CommandCenter, View, moment) {
    CommandCenter.module("CampaignsApp.List", function (List, CommandCenter, Backbone, Marionette, $, _) {
        List.Controller = {
            listCampaigns: function (id) {
                require(['common/views', 'models/Customer', 'backbone.fetch-cache', 'rickshaw'], function (CommonViews) {
                    var fetchingCustomer = CommandCenter.request("customer:entity", id);

                    // loading data view
                    var loadingView = new CommonViews.Loading();
                    var customerLayout = new View.Layout();

                    CommandCenter.contentRegion.show(customerLayout);
                    customerLayout.campaignRegion.show(loadingView);

                    $.when(fetchingCustomer).done(function (customer) {
                        var campaignView,
                            customerInfo,
                            customerBudgetInfo,
                            customerID = customer.get("id");
                        if (customer !== undefined) {
                            var cI = new CommonViews.CustomerIndicator({ model: customer });
                            CommandCenter.customerIndicatorRegion.show(cI);

                            customerInfo = new CommonViews.CustomerInfo({ model: customer });
                            customerLayout.customerHeader.show(customerInfo);

                            //show customer Budget Info
                             customerBudgetInfo = new CommonViews.CustomerBudgetInfo({ model: customer });
                             customerLayout.customerBudgetInfo.show(customerBudgetInfo);
                            // show the customer sidebar menu
                            var customerSidebar = new CommonViews.CustomerSidebarMenu({ model: customer });
                            customerSidebar.render();

                            // campaign tabs
                            campaignView = new View.CustomerCampaigns({ model: customer });
                            customerLayout.campaignRegion.show(campaignView);

                                // ensure the card sizes when switching tabs
                                $('.campaign-tabs a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
                                    var campaignType = $(e.target).attr("href").replace("#", "");
                                    var region = campaignView.getRegion(campaignType + 'Campaigns');

                                    if (region !== undefined) {
                                        // does the tab have cards?
                                        var campaignCount = $($(e.target).attr("href")).find(".card").length;
                                        if (campaignCount == 0) {
                                            var fetchingCampaigns = customer.get('campaigns').fetch({ cache: false, remove: false, data: { customerId: customerID, status: campaignType } });
                                            var campaignsView,showProviderChart;

                                            var loadingView = new CommonViews.Loading();
                                            region.show(loadingView);

                                            $.when(fetchingCampaigns).done(function (campaigns) {
                                                switch (campaignType) {
                                                    case "overview":
                                                        campaignsView = new View.ProviderOverView({ model: customer, fnRenderProviderDailyCapsChart: renderProviderChart });
                                                        showProviderChart = true;
                                                        break;
                                                    case "active":
                                                        campaignsView = new View.ActiveCampaigns({ model: customer, collection: customer.campaigns() });
                                                        showProviderChart = false;
                                                        var arr = campaigns.where({ active: "Active" });
                                                        if (arr.length != 0) {
                                                            // calculate how much money is currently spent
                                                            var total_spend = _.reduce(_.map(arr, function (item, key) { return item.get('realized'); }), function (prev, cur) {
                                                                return prev + cur;
                                                            });
                                                            customer.get("spend").set({ active: total_spend });
                                                        }

                                                        break;
                                                    case "pending":
                                                        campaignsView = new View.PendingCampaigns({ model: customer, collection: customer.campaigns() });
                                                        showProviderChart = false;
                                                        var arr = campaigns.where({ active: "Pending" });
                                                        if (arr.length != 0) {
                                                            // calculate how much money is currently budgeted
                                                            var total_budget = _.reduce(_.map(arr, function (item, key) { return item.get('budget'); }), function (prev, cur) {
                                                                return prev + cur;
                                                            });
                                                            customer.get("spend").set({ pending: total_budget });
                                                        }

                                                        break;
                                                    case "inactive":
                                                        campaignsView = new View.InactiveCampaigns({ model: customer, collection: customer.campaigns() });
                                                        showProviderChart = false;
                                                        var arr = campaigns.where({ active: "Disabled" });
                                                        if (arr.length != 0) {
                                                            // calculate how much money was spent
                                                            var total_spent = _.reduce(_.map(arr, function (item, key) { return item.get('realized'); }), function (prev, cur) {
                                                                return prev + cur;
                                                            });
                                                            customer.get("spend").set({ inactive: total_spent });
                                                        }

                                                        break;
                                                    case "paused":
                                                        campaignsView = new View.PausedCampaigns({ model: customer, collection: customer.campaigns() });
                                                        showProviderChart = false;
                                                        var arr = campaigns.where({ active: "Paused" });
                                                        if (arr.length != 0) {
                                                            // calculate how much money was spent
                                                            var total_spent = _.reduce(_.map(arr, function (item, key) { return item.get('realized'); }), function (prev, cur) {
                                                                return prev + cur;
                                                            });
                                                            customer.get("spend").set({ inactive: total_spent });
                                                        }

                                                        break;
                                                    case "completed":
                                                        campaignsView = new View.CompletedCampaigns({ model: customer, collection: customer.campaigns(), userContext: CommandCenter.loggedInUser });
                                                        showProviderChart = false;
                                                        var arr = campaigns.where({ active: "Completed" });
                                                        if (arr.length != 0) {
                                                            // calculate how much money was spent
                                                            var total_spent = _.reduce(_.map(arr, function (item, key) { return item.get('realized'); }), function (prev, cur) {
                                                                return prev + cur;
                                                            });
                                                            customer.get("spend").set({ inactive: total_spent });
                                                        }

                                                        break;
                                                };

                                                campaignsView.on("show", function (e) {
                                                    $('.card [data-toggle="popover"]').popover({
                                                        container: 'body',
                                                        html: true,
                                                        trigger: 'focus',
                                                        placement: 'auto'
                                                    });
                                                    if (showProviderChart) {
                                                        /*Daily Cap Performance Chart*/
                                                        var fetchCampaignPerf = customer.get('dailyCapPerformance').fetch();
                                                        $.when(fetchCampaignPerf).done(function (data) {
                                                            renderProviderChart(data);
                                                        });
                                                    }
                                                });

                                                region.show(campaignsView);
                                                customerInfo.trigger("showspend");

                                                // if the tab panel has cards and they haven't been resized, resize them
                                                if (campaigns.length > 0) {
                                                    smartresize();
                                                }
                                            });
                                        } else {
                                            smartresize();
                                            customerInfo.trigger("showspend");
                                        }
                                    } else {
                                        // overview tab
                                        customerInfo.trigger("showspend");
                                    }
                                });
                            // Show Provider Overview by Default
                                $('.campaign-tabs a[href="#overview"]').trigger('shown.bs.tab');
                        }
                    });
                });
            }
        }
    });

    function smartresize() {
        // do stuff as soon as the user stops resizing his browser for longer than 200ms

        // fix the cards
        //$("#customer-campaigns .tab-pane.active .card-container .card").setAllToMaxHeight();
        $("#customer-campaigns .tab-pane.active .card-container .card-header").attr("style", "").setAllToMaxHeight();
        //$("#customer-campaigns .tab-pane.active .card-container .card-content").setAllToMaxHeight();
    }


    function clearGraph() {
        $('#legend').empty();
        $('#chart_container').html(
          '<div id="providerChart"></div><div id="x_axis"></div>'
        );
    }

    function renderProviderChart(data) {
        //Reset Graph
        clearGraph();

        var providerChartData = data.get("ProviderDailyCapChartData");
        var dailyCapHistoryData = data.get("DailyCapHistoryData") || [];

        if (providerChartData.length > 0) {


            var maxDailyCapValue = _.max(dailyCapHistoryData.DailyCaps, function (cData) { return cData.Cap; }).Cap;
            var maxDailySpendValue = _.max(providerChartData, function (cData) { return cData.DailySpend; }).DailySpend;
            var maxYValue = maxDailyCapValue > maxDailySpendValue ? maxDailyCapValue : maxDailySpendValue;

            var providerGraph = new Rickshaw.Graph({
                element: document.querySelector("#providerChart"),
                series: [
                    {
                        name: 'Cap by Day',
                        data: dailyCapHistoryData.DailyCaps.map(function (d, index, array) {
                            var utcDte = moment.unix(d.CapStartDate).utc();
                            var dt = utcDte.unix();
                            return { x: dt, y: d.Cap };
                        }),
                        color: '#3e885d',
                        renderer: 'bar'
                    },
                    {
                        name: 'Total PPC',
                        data: providerChartData.map(function (d, index, array) {
                            var utcDte = moment.unix(d.Date).utc();
                            var dt = utcDte.unix();
                            return { x: dt, y: d.DailySpend, clicks: d.DailyClicks };
                        }),
                        color: '#0075C2',
                        renderer: 'area'
                    }
                ],
                renderer: 'multi',

                stroke: true,
                strokeWidth: 2,
                max: Number(maxYValue) + 10,
                interpolation: 'monotone'
            });

            var time = new Rickshaw.Fixtures.Time();
            // vary the number of ticks depending on the number of days displaying
            if (providerChartData.length < 30) {
                time.units.push({
                    name: 'providerX-AxisData',
                    seconds: 86400, // 1 day
                    formatter: function (d) { return d3.time.format.utc('%b %e')(d); }
                });
            } else if (providerChartData.length >= 30 && providerChartData.length < 60) {
                time.units.push({
                    name: 'providerX-AxisData',
                    seconds: 172800, // 2 days
                    formatter: function (d) { return d3.time.format.utc('%b %e')(d); }
                });
            } else if (providerChartData.length >= 60 && providerChartData.length < 90) {
                time.units.push({
                    name: 'providerX-AxisData',
                    seconds: 432000, // 5 days
                    formatter: function (d) { return d3.time.format.utc('%b %e')(d); }
                });
            } else {
                time.units.push({
                    name: 'providerX-AxisData',
                    seconds: 864000, // 10 days
                    formatter: function (d) { return d3.time.format.utc('%b %e')(d); }
                });
            }
            var seconds = time.unit('providerX-AxisData');

            var x_axis = new Rickshaw.Graph.Axis.Time({
                graph: providerGraph,
                orientation: 'bottom',
                element: document.getElementById('x_axis'),
                timeUnit: seconds,
                //timeFixture: new Rickshaw.Fixtures.Time.Local()
                timeFixture: new Rickshaw.Fixtures.Time()
            });

            var y_axis = new Rickshaw.Graph.Axis.Y({
                graph: providerGraph,
                orientation: 'right',
                tickFormat: Rickshaw.Fixtures.Number.formatKMBT,
                element: document.getElementById('y_axis'),
                ticksTreatment: 'glow'
            });

            y_axis.render();

            var legend = new Rickshaw.Graph.Legend({
                graph: providerGraph,
                element: document.querySelector('#legend')
            });

            var highlighter = new Rickshaw.Graph.Behavior.Series.Highlight({
                graph: providerGraph,
                legend: legend,
                disabledColor: function () { return 'rgba(0, 0, 0, 0.2)' }
            });

            var shelving = new Rickshaw.Graph.Behavior.Series.Toggle({
                graph: providerGraph,
                legend: legend
            });

            var hover = new Rickshaw.Graph.HoverDetail({
                graph: providerGraph,
                formatter: function (series, x, y) {

                    var dt = moment.unix(x).utc().format("ddd, MMM DD, YYYY");
                    var dateObj = '<span>' + dt + '</span>';
                    var valObj = '';
                    switch (series.name) {
                        case "Cap by Day":
                            valObj = '<span>' + series.name + ': $' + Number(y).toFixed(2) + '</span>' + '<br />' + dateObj;
                            break;
                        case "Total PPC":
                            var point = _.find(providerChartData, function (obj) {
                                return obj.Date === x;
                            });

                            var dailyCapReachedDateobj = point.DailyCapReachedDateTime > 0 ? moment.unix(point.DailyCapReachedDateTime).utc().format("ddd, MMM DD, YYYY, h:mm:ss a") : 'N/A';

                            valObj = '<span> Daily Spend: $' + Number(y).toFixed(2) +
                                       ' <br /> Daily Clicks: ' + point.DailyClicks +
                                       '<br /> Daily Cap reached :' + dailyCapReachedDateobj +
                                       '</span>';
                            break;
                    }
                    return valObj;
                },
                xFormatter: function (x) { return null; },
                yFormatter: function (y) { return null; }
            });


            providerGraph.render();

            var providerGraphResize = function () {
                providerGraph.configure({
                    width: window.innerWidth * 0.75
                });
                providerGraph.render();
            }

            $(window)
                .resize(function () {
                    providerGraphResize();
                });
        } else {
            document.querySelector("#providerChart").innerHTML = "<h3 class='text-info text-center'> Provider Level Daily Caps Performance Data is not available</h3>";
        }
    }

    return CommandCenter.CampaignsApp.List.Controller;
});
