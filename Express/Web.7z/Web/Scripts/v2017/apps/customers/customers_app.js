﻿define(['app', 'numeral', 'underscore-string', 'routefilter'], function (CommandCenter) {
    CommandCenter.module("CustomersApp", function (CustomersApp, CommandCenter, Backbone, Marionette, $, _) {
        CustomersApp.startWithParent = false;

        CustomersApp.onStart = function () {
            // enable the search box
            $("#search-box").prop("disabled", false);
        };

        CustomersApp.onStop = function () {
            // remove search box events
            $("#search-box").off("keyup.customers");
        }

        CustomersApp.routePermissionsMap = {
            "customers/:id/edit": {
                roles: ['3ddf5a27-7f09-4d5c-b594-db94b96c142e']
            }
        };

        CustomersApp.canAccess = function (route) {
            var retVal = true;

            if ((typeof window.CommandCenter.Server.adalconfig != 'undefined') && (window.CommandCenter.Server.adalconfig.active === "true")) {
                // ensure we have the users roles
                if ((typeof CommandCenter.loggedInUser === 'undefined') || (CommandCenter.loggedInUser.get("roles").length == 0)) {
                    CommandCenter.setUserRoles(CommandCenter.CustomersApp.canAccess, [route]);
                    return;
                }

                // ensure they have permission to the url
                if (_.has(CommandCenter.CustomersApp.routePermissionsMap, route)) {
                    var roles = CommandCenter.CustomersApp.routePermissionsMap[route].roles;

                    // check user roles
                    if (_.intersection(roles, CommandCenter.loggedInUser.get("roles")).length === 0) {
                        // no access, don't let them continue
                        retVal = false;
                    }
                }
            }

            return retVal;
        }
    });

    CommandCenter.module("Routers.CustomersApp", function (CustomerAppRouter, CommandCenter, Backbone, Marionette, $, _) {
        CustomerAppRouter.Router = Marionette.AppRouter.extend({
            appRoutes: {
                "customers(/filter/criterion::criterion)": "listCustomers",
                "customers/:id/edit": "editCustomer"
            },
            before: function (route, params) {
                // return false to stop execution
                return CommandCenter.CustomersApp.canAccess(route);
            }
        });

        var executeAction = function (action, arg) {
            CommandCenter.startSubApp("CustomersApp");
            action(arg);
        };

        var API = {
            listCustomers: function (criterion) {
                // remove the customers menu from sidebar
                $(".sidebar-nav li.customer-menu").remove();

                require(["apps/customers/list/list_controller"], function (ListController) {
                    executeAction(ListController.listCustomers, criterion);
                });
            },

            editCustomer: function (id) {
                require(["apps/customers/edit/edit_controller"], function (EditController) {
                    executeAction(EditController.editCustomer, id);
                });
            }
        };

        CommandCenter.on("customers:list", function () {
            CommandCenter.navigate("customers");
            API.listCustomers();
        });

        CommandCenter.on("customer:edit", function (id) {
            CommandCenter.navigate("customers/" + id + "/edit");
            API.editCustomer(id);
        });

        CommandCenter.on("customers:filter", function (criterion) {
            if (criterion) {
                CommandCenter.navigate("customers/filter/citerion:" + criterion);
            } else {
                CommandCenter.navigate("customers");
            }
        });

        CommandCenter.addInitializer(function () {
            new CustomerAppRouter.Router({
                controller: API
            });
        });
    });

    return CommandCenter.CustomerAppRouter;
});