﻿define(['app', 'apps/customers/edit/edit_view'], function (CommandCenter, View) {
    CommandCenter.module("CustomersApp.Edit", function (Edit, CommandCenter, Backbone, Marionette, $, _) {
        Edit.Controller = {
            editCustomer: function (id) {
              require(['common/views', 'models/Customer', 'backbone.fetch-cache', 'datepicker'], function (CommonViews) {
                    // loading data view
                    var loadingView = new CommonViews.Loading();

                    // Customer edit layout view
                    var customerLayout = new View.Layout();

                    // put the page layout in place
                    CommandCenter.contentRegion.show(customerLayout);

                    // show the loading view
                    customerLayout.editCustomerRegion.show(loadingView);

                    // get the customer information
                    var fetchingCustomer = CommandCenter.request("customer:entity", id);
                    
                    $.when(fetchingCustomer).done(function (customer) {
                        // show the customer sidebar menu items
                        var cI = new CommonViews.CustomerIndicator({ model: customer });
                        CommandCenter.customerIndicatorRegion.show(cI);
                        var customerSidebar = new CommonViews.CustomerSidebarMenu({ model: customer });
                        customerSidebar.render();

                        // show the customer budget form (for entering new contracts)
                        var formView = new View.FormView({ model: customer });
                        customerLayout.editCustomerRegion.show(formView);

                        var options = {
                            success: function (model, response, options) {
                                // close up the view
                                //customerLayout.editCustomerRegion.reset();

                                // show success message
                                console.log(formView.$el.find('.alert-success').removeClass('hidden'));
                            },
                            error: function (model, response, options) {
                                // requires errors response from the server to get here
                                formView.triggerMethod("form:data:invalid", response.responseJSON);

                                console.log(formView.$el.find('.alert-success').addClass('hidden'));
                            }
                        };

                        formView.on("form:submit", function (data) {
                            if (!customer.save(data, options)) {
                                console.log("ERROR:: HANDLE IT");
                                console.log(customer.validationError);
                            //    view.triggerMethod("form:data:invalid", model.validationError);
                            }
                        });
                    });
                });
            }
        };
    });

    return CommandCenter.CustomersApp.Edit.Controller;
});