﻿define(['app'],
    function (CommandCenter) {
        CommandCenter.module("Models", function (Models, CommandCenter, Backbone, Marionette, $, _) {
            Models.CampaignPerformance = Backbone.Model.extend({
                urlRoot: "api/v2/campaigns",

                defaults: {
                    name: ""
                }
            });
        });

        return;
    });
