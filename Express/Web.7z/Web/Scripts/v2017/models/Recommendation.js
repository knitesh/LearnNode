﻿define(['app'],
    function (CommandCenter) {
        CommandCenter.module("Models", function (Models, CommandCenter, Backbone, Marionette, $, _) {
    

            var API = {
                getRecommendationEntity: function (targetings) {

                    var defer = $.Deferred();

                    $.ajax({
                        type: "POST",
                        url: '/api/recommendations/criteria',
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        data: JSON.stringify(targetings),
                        success: function (data) {
                            defer.resolve(data);
                        },
                        error: function (error) {
                            console.log("ERROR: Request For Recommended PPC failed!");
                        }
                    });

                    return defer.promise();
                }
            };

            CommandCenter.reqres.setHandler("recommendation:entity", function (targetings) {
                return API.getRecommendationEntity(targetings);
            });
        });

        return;
    });
