﻿define(['app'],
    function (commandCenter) {
        commandCenter.module("Models", function (Models, CommandCenter, Backbone, Marionette, $, _) {
            Models.TargetingCriteria = Backbone.Model.extend({
                urlRoot: "api/TargetingCriteria",

                defaults: {
                    Text: "",
                    Value: "",
                    selected: false
                }
            });

            Models.TargetingCriteriaKeyCollection = Backbone.Collection.extend({
                url: "/api/TargetingCriteria/Key",
                model: Models.TargetingCriteria,
                comparator: "value"
               
            });


            Models.TargetingCriteriaValueCollection = Backbone.Collection.extend({
                url: "/api/TargetingCriteria/Value",
                model: Models.TargetingCriteria,
                comparator: "Value"

            });

            Models.CustomersTargetingCriteriaValueCollection = Backbone.Collection.extend({
                url: function () { return 'api/customers/' + this.customerId + '/TargetingCriteria/' +this.keyname +'/Values'},
                model: Models.TargetingCriteria,
                initialize: function (models, options) {
                    this.customerId = options.customerId;
                    this.keyname = options.keyname;
                }
            });

            Models.CustomersTargetingCriteriaKeyCollection = Backbone.Collection.extend({
                url: function () { return 'api/customers/' + this.customerId + '/TargetingCriteria/Keys' },
                model: Models.TargetingCriteria,
                initialize: function (models, options) {
                    this.customerId = options.customerId;
                }
            });

            /*      *Just for Boolean Representaiton*       */
            Models.BooleanRepresentation = Backbone.Model.extend({
                urlRoot: "api/v2/criteria",

                defaults: {
                    Function: "",
                    ScreenOrder: "",
                    Criteria: "",
                    Condition: "",
                    Values: null
                }
            });


            Models.BooleanRepresentationCollection = Backbone.Collection.extend({
                urlRoot: "api/v2/criteria",
                model: Models.BooleanRepresentation
            });

         

            var api = {
                getAllTargetingCriteriaKey: function (customerId) {
                    var customersTargetingCriteriaKeyCollection = new Models.CustomersTargetingCriteriaKeyCollection([],{
                        customerId: customerId
                    });
                    var defer = $.Deferred();
                    customersTargetingCriteriaKeyCollection.fetch({
                        cache: true,
                        async:true,
                        success: function(data) {
                            defer.resolve(data);
                        }
                    });
                    return defer.promise();
                },
                getAllTargetingCriteriaValueForGivenKey: function (customerId, keyname) {
                   
                    var customersTargetingCriteriaValueCollection = new Models.CustomersTargetingCriteriaValueCollection([],{
                        customerId: customerId,
                        keyname: keyname
                    });
                    var defer = $.Deferred();
                    customersTargetingCriteriaValueCollection.fetch({
                        cache: true,
                        async: true,
                        success: function (data) {
                            defer.resolve(data);
                        }
                    });
                    return defer.promise();
                },
                getBooleanExpressionForGivenCriteriaObject: function (criteriaObject) {

                    var criteriaBooleanRepresentation = new Models.BooleanRepresentationCollection({
                        criteria: criteriaObject
                    });
                    var defer = $.Deferred();
                    criteriaBooleanRepresentation.save({
                        cache: false,
                        async: true,
                        success: function (data) {
                            defer.resolve(data);
                        }
                    });
                    return defer.promise();
                }
            };

            CommandCenter.reqres.setHandler("TargetingCriteria:key", function (customerId) {
                return api.getAllTargetingCriteriaKey(customerId);
            });

            CommandCenter.reqres.setHandler("TargetingCriteria:Key:Values", function (customerId, keyname) {
                return api.getAllTargetingCriteriaValueForGivenKey(customerId, keyname);
            });

            CommandCenter.reqres.setHandler("BooleanExpression:entity:new", function (id) {
                return new Models.BooleanRepresentationCollection([]);
            });

            CommandCenter.reqres.setHandler("TargetingCriteria:Get:BooleanExpress", function (criteriaObject) {
                //TODO : Check whether using backbone model make sense, if yes use a model
                //TODO : Also try to convert it to $.post, if not using backbone model -KNitesh
                var defer = $.Deferred();

                $.ajax({
                    type: "POST",
                    url: 'api/v2/criteria',
                    data: JSON.stringify(criteriaObject),
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    success: function (data) { //call successfull
                        defer.resolve(data);
                    },
                    error: function (xhr) {
                        console.log("Error Occured while getting boolean expression from API");
                    }
                });

                return defer.promise();
            });

          
        });

        return;
    });
