﻿define(['app','localstorage'],
    function (CommandCenter) {
        CommandCenter.module("Models", function (Models, CommandCenter, Backbone, Marionette, $, _) {
            Models.Job = Backbone.Model.extend({
                urlRoot: "api/jobs",

                defaults: {
                    title: "",
                    selectedForCampaign: false
                }
            });

            Models.JobsCollection = Backbone.Collection.extend({
                url: function () {
                    var url = "",
                        baseUrl = 'api/customers/';

                    return baseUrl + this.customerId + url + '/jobs';
                },
                model: Models.Job,
                comparator: "title",
                initialize: function (models, options) {
                    this.customerId = options.customerId;
                    this.targeting = options.targeting;
                }
            });

            Models.CampaignJobs = Backbone.Collection.extend({
                localStorage: new Backbone.LocalStorage("CampaignJobs"),
                model: Models.Job
            });
            

            var API = {

                getJobEntities: function (providerId, targeting) {
                    //TODO: Knitesh- Modify to send Targeting Object similar as of GetJobsCount
                    var defer = $.Deferred();

                    var jobEntityUrl = "api/customers/" + providerId + '/jobs';

                    function getJobsRequest() {
                        if (typeof getJobEntityRequest !== 'undefined') {
                            window.getJobEntityRequest.abort();
                        }
                        //TODO:Knitesh - Change the method to POST once Post API is available to take Targeting Criteria
                        window.getJobEntityRequest = Backbone.ajax({
                            //TODO: Change it to POST once API is ready
                            method: 'POST',
                            dataType: "json",
                            url: jobEntityUrl,
                            contentType: 'application/json',
                            beforeSend: function () {
                                if (window.getJobEntityRequest != null) {
                                    window.getJobEntityRequest.abort();
                                }
                            },
                            data: JSON.stringify(targeting),
                            success: function (data) {
                                defer.resolve(new Models.JobsCollection(data, { customerId: providerId, targeting: targeting }));
                            },
                            error: function (jqXhr, textStatus, err) {
                                console.log(err);
                                defer.reject();
                            }
                        });

                    }

                    getJobsRequest();

                    return defer.promise();
                },

                getJobsCount: function (providerId, targeting) {

                    var jobCountUrl = "api/customers/" + providerId + "/Jobcounts";

                    var defer = $.Deferred();

                    function makeRequest() {
                        if (typeof currentRequest !== 'undefined') {
                            window.currentRequest.abort();
                        }

                        window.currentRequest = Backbone.ajax({
                            method: 'POST',
                            dataType: "json",
                            contentType: 'application/json',
                            url: jobCountUrl,
                            beforeSend: function () {
                                if (window.currentRequest != null) {
                                    window.currentRequest.abort();
                                }
                            },
                            data:  JSON.stringify(targeting),
                            success: function (val) {
                                defer.resolve(val);
                            }
                        });

                    }

                    makeRequest();

                    return defer.promise();
                }
            };

            //TODO: Knitesh: Confirm whether we ever goingh to display a indivudal job  detail on UI
            //CommandCenter.reqres.setHandler("job:entity", function (id) {
            //    return API.getJobEntity(id);
            //});

            CommandCenter.reqres.setHandler("job:entities", function (companyId, targeting) {
                return API.getJobEntities(companyId, targeting);
            });

            CommandCenter.reqres.setHandler("job:count", function (providerId, targeting) {
                return API.getJobsCount(providerId, targeting);
            });

        });

        return;
    });
