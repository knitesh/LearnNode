﻿define(['app', 'numeral'], function (App) {
    describe("Campaign Model", function () {
        beforeEach(function () {
            this.campaign = App.request("campaign:entity:new");
        });

        describe("Campaign Model - Default values",function() {
                it("should have a default empty string name",
                    function() {
                        expect(this.campaign.get('CampaignName')).toBe("");
                    });

                it("should have a default empty string description",
                    function() {
                        expect(this.campaign.get('description')).toBe("");
                    });

                it("should have a default locations of null",
                    function() {
                        expect(this.campaign.get('Locations')).toBeNull();
                    });

                it("should have a default occupations of null",
                    function() {
                        expect(this.campaign.get('Occupations')).toBeNull();
                    });

                it("should have a default ppc of 0",
                    function() {
                        expect(this.campaign.get('PayPerClickAmount')).toBe(0);
                    });


                it("should have a default jobclicklimit of 250",
                    function() {
                        expect(this.campaign.get('JobClickLimit')).toBe(250);
                    });

                it("should have a default budget of 0",
                    function() {
                        expect(this.campaign.get('Budget')).toBe(0);
                    });
            });

        it("should not save when name is empty", function () {
            var eventSpy = sinon.spy();
            this.campaign.on("invalid", eventSpy);
            this.campaign.save({ "CampaignName": "" });
            expect(eventSpy).toHaveBeenCalledOnce();
            expect(eventSpy).toHaveBeenCalledWith(this.campaign);
            expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'Campaign name is required.' }));
        });

        it("should not save when Start Date is empty", function () {
            var eventSpy = sinon.spy();
            this.campaign.on("invalid", eventSpy);
            this.campaign.save({ "StartDate": "" });
            expect(eventSpy).toHaveBeenCalledOnce();
            expect(eventSpy).toHaveBeenCalledWith(this.campaign);
            expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'Campaign start date is required.' }));
        });


        it("should not save when jobclicklimit is undefined", function () {
            var eventSpy = sinon.spy();
            this.campaign.on("invalid", eventSpy);
            this.campaign.save({ "JobClickLimit": null });
            expect(eventSpy).toHaveBeenCalledOnce();
            expect(eventSpy).toHaveBeenCalledWith(this.campaign);
            expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'Clicks Per Job is required.' }));
        });

        /*Daily Cap */
        describe("Campaign Model - Daily Cap",function() {

                it("should not save when Daily cap is not null or empty",
                    function() {
                        var eventSpy = sinon.spy();
                        this.campaign.on("invalid", eventSpy);
                        this.campaign.save({ "CurrentDailyCap": " " });
                        expect(eventSpy).toHaveBeenCalledOnce();
                        expect(eventSpy).toHaveBeenCalledWith(this.campaign);
                        expect(eventSpy.args[0][1])
                            .toContain(jasmine
                                .objectContaining({ message: 'Daily Cap value needs to be greater than 0.' }));
                    });
                it("should not save when Daily cap is less than 0 ",
                    function() {
                        var eventSpy = sinon.spy();
                        this.campaign.on("invalid", eventSpy);
                        this.campaign.save({ "CurrentDailyCap": "-1" });
                        expect(eventSpy).toHaveBeenCalledOnce();
                        expect(eventSpy).toHaveBeenCalledWith(this.campaign);
                        expect(eventSpy.args[0][1])
                            .toContain(jasmine
                                .objectContaining({ message: 'Daily Cap value needs to be greater than 0.' }));
                    });
                it("should not save when Daily cap is greater than 100,000,000 ",
                    function() {
                        var eventSpy = sinon.spy();
                        this.campaign.on("invalid", eventSpy);
                        this.campaign.save({ "CurrentDailyCap": "100000001" });
                        expect(eventSpy).toHaveBeenCalledOnce();
                        expect(eventSpy).toHaveBeenCalledWith(this.campaign);
                        expect(eventSpy.args[0][1])
                            .toContain(jasmine
                                .objectContaining({ message: 'Daily Cap greater than $1,000,000.00 is not allowed' }));
                    });
        });

        /* Future Daily Cap */
        describe("Campaign Model - Future Daily Cap", function() {
            it("should not save when Future Cap has negative value", function() {
                var eventSpy = sinon.spy();
                this.campaign.on("invalid", eventSpy);
                this.campaign.save({ "FutureDailyCap": "-10" });
                expect(eventSpy).toHaveBeenCalledOnce();
                expect(eventSpy).toHaveBeenCalledWith(this.campaign);
                expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'Future Daily cap needs to be greater than 0' }));
            });
            it("should not save when Future Cap has sapce", function() {
                var eventSpy = sinon.spy();
                this.campaign.on("invalid", eventSpy);
                this.campaign.save({ "FutureDailyCap": " " });
                expect(eventSpy).toHaveBeenCalledOnce();
                expect(eventSpy).toHaveBeenCalledWith(this.campaign);
                expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'Future Daily cap needs to be greater than 0' }));
            });
            it("should not save when Future is greater than 100,000,000", function() {
                var eventSpy = sinon.spy();
                this.campaign.on("invalid", eventSpy);
                this.campaign.save({ "FutureDailyCap": "100000001" });
                expect(eventSpy).toHaveBeenCalledOnce();
                expect(eventSpy).toHaveBeenCalledWith(this.campaign);
                expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'Future Daily Cap greater than $1,000,000.00 is not allowed' }));
            });
        });

        describe("Campaign model - Budget", function () {
                it("should not save when budget is undefined",
                    function() {
                        var eventSpy = sinon.spy();
                        this.campaign.on("invalid", eventSpy);
                        this.campaign.save({ "Budget": null });
                        expect(eventSpy).toHaveBeenCalledOnce();
                        expect(eventSpy).toHaveBeenCalledWith(this.campaign);
                        expect(eventSpy.args[0][1])
                            .toContain(jasmine.objectContaining({ message: 'A budget is required.' }));
                    });

                it("should not save when budget is 0",
                    function() {
                        var eventSpy = sinon.spy();
                        this.campaign.on("invalid", eventSpy);
                        this.campaign.save({ "Budget": "0" });
                        expect(eventSpy).toHaveBeenCalledOnce();
                        expect(eventSpy).toHaveBeenCalledWith(this.campaign);
                        expect(eventSpy.args[0][1])
                            .toContain(jasmine.objectContaining({ message: 'Your budget must be greater than 0.' }));
                    });

                it("should not save when budget is a negative number",
                    function() {
                        var eventSpy = sinon.spy();
                        this.campaign.on("invalid", eventSpy);
                        this.campaign.save({ "Budget": "-1,000.00" });
                        expect(eventSpy).toHaveBeenCalledOnce();
                        expect(eventSpy).toHaveBeenCalledWith(this.campaign);
                        expect(eventSpy.args[0][1])
                            .toContain(jasmine.objectContaining({ message: 'Your budget must be greater than 0.' }));
                    });
        });


        it("should save a la carte campaign when location and occupation are not defined", function () {
            var eventSpy = sinon.spy();
            this.campaign.on("invalid", eventSpy);
            this.campaign.save({ "IsDynamic": false, "location": null, "occupation": null });
            expect(eventSpy).toHaveBeenCalledOnce();
            expect(eventSpy).toHaveBeenCalledWith(this.campaign);
            expect(eventSpy.args[0][1]).not.toContain(jasmine.objectContaining({ message: 'Either location or occupation is required.' }));
        });

        it("should not save when ppc is 0", function () {
            var eventSpy = sinon.spy();
            this.campaign.on("invalid", eventSpy);
            this.campaign.save({ "PayPerClickAmount": "0" });
            expect(eventSpy).toHaveBeenCalledOnce();
            expect(eventSpy).toHaveBeenCalledWith(this.campaign);
            expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'PayPerClickAmount is required and must be greater than $0.00.' }));
        });


        it("should not save when jobclicklimit is not a number", function () {
            var eventSpy = sinon.spy();
            this.campaign.on("invalid", eventSpy);
            this.campaign.save({ "JobClickLimit": "abcde" });
            expect(eventSpy).toHaveBeenCalledOnce();
            expect(eventSpy).toHaveBeenCalledWith(this.campaign);
            expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'Clicks Per Job is required.' }));
        });

        it("should not save when jobclicklimit is less than 0", function () {
            var eventSpy = sinon.spy();
            this.campaign.on("invalid", eventSpy);
            this.campaign.save({ "JobClickLimit": "-10" });
            expect(eventSpy).toHaveBeenCalledOnce();
            expect(eventSpy).toHaveBeenCalledWith(this.campaign);
            expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'Clicks Per Job must be greater than 0.' }));
        });
    });
});