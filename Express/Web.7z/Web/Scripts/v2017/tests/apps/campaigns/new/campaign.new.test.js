﻿define(['app', 'apps/campaigns/new/new_view', 'moment', 'lib/jasmine-sinon'], function (app, view, moment) {
    describe("Campaign Create View", function () {

        describe("View New Campaign", function () {
            beforeEach(function () {
                this.baseLayout = new view.NewCampaign();
            });

            describe("New Campaign View Instantiation", function () {
                it("should create a div element", function () {
                    expect(this.baseLayout.el.nodeName).toEqual("DIV");
                });

                it("should have a template defined", function () {
                    expect(this.baseLayout.template).toBeDefined();
                });

                it("should have a Regions defined", function () {
                    expect(this.baseLayout.regions).toBeDefined();
                });
                it("should have Eleven regions defined", function () {
                    expect(this.baseLayout.regions).toBeDefined();
                    expect(_.size(this.baseLayout.regions)).toEqual(11);
                });
            });
        });
       
    });
});
