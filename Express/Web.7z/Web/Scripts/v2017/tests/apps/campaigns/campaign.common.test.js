﻿//Use New_View to check Common UI element

define(['app', 'apps/campaigns/new/new_view', 'moment', 'lib/jasmine-sinon'], function(app, view, moment) {
    describe("Campaign Common View", function() {

        describe("Shared Header View", function() {
            beforeEach(function() {
                this.header = new view.Header();
            });

            describe("Header View", function() {
                it("should create a div element", function() {
                    expect(this.header.el.nodeName).toEqual("DIV");
                });

                it("should have a template defined", function() {
                    expect(this.header.template).toBeDefined();
                });

                it("should have a template helper defined", function() {
                    expect(this.header.templateHelpers).toBeDefined();
                });

                it("should have a class 'col-xs-12'", function() {
                    expect($(this.header.el).hasClass('col-xs-12')).toBeTruthy();
                });

                it("should not have a Regions defined", function() {
                    expect(this.header.regions).not.toBeDefined();
                });


                it("should have a Create Template Function defined", function() {
                    expect(this.header.createNewCampaign).toBeDefined();
                });

            });
        });

        describe("Shared BasicFieldList View", function() {
            beforeEach(function() {
                this.basicFieldList = new view.BasicFieldList();
            });

            describe("BasicFieldList View", function() {
                it("should create a div element", function() {
                    expect(this.basicFieldList.el.nodeName).toEqual("DIV");
                });

                it("should have a template defined", function() {
                    expect(this.basicFieldList.template).toBeDefined();
                });

                it("should have a template helper defined", function() {
                    expect(this.basicFieldList.templateHelpers).toBeDefined();
                });

                it("should have a attributes defined", function() {
                    expect(this.basicFieldList.attributes).toBeDefined();
                });

                it("should have a formReset defined", function() {
                    expect(this.basicFieldList.formReset).toBeDefined();
                });
                it("should have a setDatepickerElements defined", function() {
                    expect(this.basicFieldList.setDatepickerElements).toBeDefined();
                });
                it("should have a getPPCRecommendation defined", function() {
                    expect(this.basicFieldList.getPPCRecommendation).toBeDefined();
                });

                it("should not have a Regions defined", function() {
                    expect(this.basicFieldList.regions).not.toBeDefined();
                });


                it("should have a showUtcTime Function defined", function() {
                    expect(this.basicFieldList.showUtcTime).toBeDefined();
                });

            });
        });

        describe("Shared SelectedJob View", function() {
            beforeEach(function() {
                this.basicFieldList = new view.SelectedJob();
            });
        });

        describe("Shared SelectedJobList View", function() {
            beforeEach(function() {
                this.basicFieldList = new view.SelectedJobList();
            });
        });

        describe("Shared JobBasedOnCriteria View", function() {
            beforeEach(function() {
                this.basicFieldList = new view.JobBasedOnCriteria();
            });
        });

        describe("Shared JobListBasedOnCriteria View", function() {
            beforeEach(function() {
                this.basicFieldList = new view.JobListBasedOnCriteria();
            });
        });

        describe("Shared BooleanExpressionView View", function() {
            beforeEach(function() {
                this.booleanExpressionView = new view.BooleanExpressionView();
            });
            describe("Boolean Expression View", function() {
                it("should have a template defined", function() {
                    expect(this.booleanExpressionView.template).toBeDefined();
                });
                it("should have a templateHelper defined", function() {
                    expect(this.booleanExpressionView.templateHelpers).toBeDefined();
                })
            });
        });

        describe("Shared CreateWarningView View", function() {
            beforeEach(function() {
                this.createWarningView = new view.CreateWarningView();
            });

            describe("Warning View",
                function() {
                    it("should have a template defined",
                        function() {
                            expect(this.createWarningView.template).toBeDefined();
                        });
                    it("should have a Return button handled defined",
                        function() {
                            expect(this.createWarningView.btnReturnHandler).toBeDefined();
                        });
                    it("should fire a callback when 'return' button is triggered", function() {
                        var spy = sinon.spy();
                        this.createWarningView.bind("click #btnReturn", spy);

                        this.createWarningView.trigger("click #btnReturn");

                        expect(spy.called).toBeTruthy();
                    })
                });
        });



    });
});