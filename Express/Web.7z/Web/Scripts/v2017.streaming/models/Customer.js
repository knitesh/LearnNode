﻿define(['app',
    'lib/backbone.virtual-collection',
    'backbone.fetch-cache',
    'lib/backbone.associate',
    'models/Campaign',
    'models/Location',
    'models/Occupation',
    'models/TargettingCriteria'
],
    function (CommandCenter) {
        CommandCenter.module("Models", function (Models, CommandCenter, Backbone, Marionette, $, _) {
            Models.CustomerSpend = Backbone.Model.extend({
                defaults: {
                    active: null,
                    pending: null,
                    inactive: null
                }
            });

            Models.Customer = Backbone.Model.extend({
                defaults: {
                },
                initialize: function () {
                },
                urlRoot: "api/v2/customers",
                parse: function (response, options) {
                    response.spend = new Models.CustomerSpend();
                    return response;
                },
                feedEnabled: function () {
                    return this.get('campaignfeedenabled') || false;
                }
            });

            Models.CustomerCollection = Backbone.Collection.extend({
                url: "api/v2/customers",
                model: Models.Customer,
                comparator: function (item) {
                    return item.get("name").toLowerCase()
                },
                parse: function (response) {
                    return response.companies;
                },
                customFilter: function (filters) {
                    var results = this.where(filters);
                    return new Models.CustomerCollection(results);
                }
            });

            Backbone.associate(Models.Customer, {
                campaigns: { type: Models.CustomersCampaignCollection, url: '/campaigns' },
                locations: { type: Models.CustomersLocationCollection, url: '/locations' },
                occupations: { type: Models.CustomersOccupationsCollection, url: '/occupations' },
                dailyCapPerformance: { type: Models.CampaignPerformance, url: '/dailyCapPerformance' },
                targettingCriteriaKeys: { type: Models.CustomersTargetingCriteriaKeyCollection, url: '/targetingCriteriaKeys' },
                targettingCriteriaValues: { type: Models.CustomersTargetingCriteriaValueCollection, url: '/targetingCriteriaValues' }
            });

            var API = {
                getCustomerEntities: function () {
                    var customers = new Models.CustomerCollection();
                    var defer = $.Deferred();
                    customers.fetch({
                        cache: true,
                        prefill: true,
                        prefillSuccess: function (data) {
                            //console.log("CUSTOMER FETCH prefillSuccess");
                        },
                        success: function (data) {
                            defer.resolve(data);
                            //defer.resolveWith(data, [customers]);
                        }
                    });

                    return defer.promise();
                },

                getCustomerEntity: function (customerId) {
                    var customer = new Models.Customer({ id: customerId });
                    var defer = $.Deferred();
                    customer.fetch({
                        cache: false,
                        success: function (data) {
                            defer.resolve(data);
                        },
                        error: function (data) {
                            defer.resolve(undefined);
                            //defer.reject(undefined);
                        }
                    });
                    return defer.promise();
                }
            };

            CommandCenter.reqres.setHandler("customer:entities", function () {
                return API.getCustomerEntities();
            });

            CommandCenter.reqres.setHandler("customer:entity", function (id) {
                return API.getCustomerEntity(id);
            });
        });

        return;
    });