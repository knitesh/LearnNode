﻿define(['app'],
    function (CommandCenter) {
        CommandCenter.module("Models", function (Models, CommandCenter, Backbone, Marionette, $, _) {
            Models.Location = Backbone.Model.extend({
                urlRoot: "api/locations",

                defaults: {
                    name: "",
                    agg_jobs: 0,
                    ppc_jobs: 0,
                    all_jobs: 0,
                    "state-name": "",
                    "state-abbrev": "",
                    "city-name": "",
                    "type": "location",
                    selected: false
                }
            });

            Models.LocationCollection = Backbone.Collection.extend({
                url: "/api/locations",
                model: Models.Location,
                comparator: "name"
            });

            Models.CustomersLocationCollection = Backbone.Collection.extend({
                //url: function () { return '/locations'; },
                model: Models.Location
            });

            Models.LocationOccupationCollection = Backbone.Collection.extend({
                url: function () { return 'api/v2/customers/' + this.customerId + '/locations/' + this.locationId + '/occupations'; },
                //model: Models.Occupation,
                initialize: function (models, options) {
                    this.customerId = options.customerId;
                    this.locationId = options.locationId;
                }
            });

            var API = {
                getAllLocations: function () {
                    var defer = $.Deferred();
                    var locations = new Models.LocationCollection();
                    locations.fetch({
                        cache: true,
                        success: function (data) {
                            defer.resolve(data);
                        }
                    })
                    return defer.promise();
                },

                getLocationEntity: function (locationId) {
                    //console.log("getLocationEntity:: " + locationId);
                },

                getLocationOccupations: function (customerId, locationId) {
                    var occs = new Models.LocationOccupationCollection([], { customerId: customerId, locationId: locationId });
                    var defer = $.Deferred();
                    occs.fetch({
                        success: function (data) {
                            defer.resolve(data);
                            //defer.resolveWith(data, [customers]);
                        }
                    });

                    return defer.promise();
                }
            };

            CommandCenter.reqres.setHandler("location:entities", function () {
                return API.getAllLocations();
            });

            CommandCenter.reqres.setHandler("location:entity", function (id) {
                return API.getLocationEntity(id);
            });

            CommandCenter.reqres.setHandler("location:occupations", function (customerId, locId) {
                return API.getLocationOccupations(customerId, locId);
            });
        });

        return;
    });
