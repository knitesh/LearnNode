define(["app", "apps/campaigns/new/new_view", "apps/campaigns/common/utility", "moment", "toastr", "selectize"], function (commandCenter, view, $utility, moment, toastr) {
    commandCenter.module("CampaignsApp.New", function (New, CommandCenter, Backbone, Marionette, $, _) {
        New.Controller = {
            /* buildNewCampaign */
            buildNewCampaign: function (id) {
                require(['common/views', 'wookmark', 'models/Customer', 'backbone.fetch-cache', 'lib/backbone.virtual-collection', 'datepicker', 'chosen'], function (CommonViews, Wookmark) {

                    var fetchingCustomer = CommandCenter.request("customer:entity", id),
                        providerId = id,
                        newCampaign = CommandCenter.request("campaign:entity:new"),
                        thisController = New.Controller,
                        //Views
                        headerView = new view.Header(),
                        baseView = new view.NewCampaign({ customerId: id }),
                        basicCampaignFieldView = new view.BasicFieldList({ model: newCampaign }),
                        criteriaCollection = new Backbone.Collection(),
                        criteriaView = new view.CampaignCriteria({ model: newCampaign, collection: criteriaCollection }),
                        customer,
                        criteriaId;


                    toastr.options = {
                        "closeButton": true,
                        "newestOnTop": true,
                        "positionClass": "toast-bottom-left",
                        "preventDuplicates": true
                    };



                    var fetchingCustomerHandler = function (data) {
                        customer = data;
                        // setup the new campaign
                        newCampaign.set({ ProviderID: customer.get("id") });

                        // show base view
                        CommandCenter.contentRegion.show(baseView);
                        //show customer Budget Info
                        var customerBudgetInfo = new CommonViews.CustomerBudgetInfo({ model: customer });
                        baseView.customerBudgetInfo.show(customerBudgetInfo);

                        // show the customer sidebar menu
                        var customerSidebar = new CommonViews.CustomerSidebarMenu({ model: customer });
                        customerSidebar.render();
                        //show Customer Icon
                        var cI = new CommonViews.CustomerIndicator({ model: customer });
                        CommandCenter.customerIndicatorRegion.show(cI);
                    }

                    var addCriteriaRowHandler = function (childView, item) {

                        //Display or update Job Count
                        $utility.jobs.jobCountView(baseView, customer.get("id"), view);

                        //check if any row has empty key
                        if ($utility.criteria.isAnyFieldInCriteriaRowsEmpty()) {
                            return;
                        }

                        criteriaId = moment().unix();

                        criteriaCollection.add({ "id": criteriaId });

                        var onChangeCriteriaRelationHandler = function (value) {
                            $utility.jobs.jobCountView(baseView, providerId, view);
                        }

                        $('#' + criteriaId + ' .criterionRelations').selectize({
                            sortField: 'text',
                            onChange: onChangeCriteriaRelationHandler
                        }); //Criteria Relation Drop Down

                        var onChangeCriteriaConditionHandler = function (value) {
                            $utility.jobs.jobCountView(baseView, providerId, view);
                        }
                        var $criteriaConditionDropDown = $('#' + criteriaId + ' .booleanConditions').selectize({
                            sortField: 'text',
                            onChange: onChangeCriteriaConditionHandler
                        }); //Criteria Boolean Conditin Drop Down



                        var onChangeCriteriaValueHandler = function (value) {
                            var self = this;
                            thisController.onChangeCriteriaValueHandler(self, value, baseView, customer.get("id"));
                        }

                        var $selectValuesdropDown = $('#' + criteriaId + ' .targetValues')
                            .selectize({
                                plugins: ['remove_button'],
                                maxItems: null,
                                persist: true,
                                highlight: true,
                                hideSelected: true,
                                delimiter: ',',
                                onChange: onChangeCriteriaValueHandler,
                                sortField: 'value'
                            }); // Criteria Value Drop Down

                        var selectValuesdropDown = $selectValuesdropDown[0].selectize;
                        selectValuesdropDown.disable();
                        var conditionDropDown = $criteriaConditionDropDown[0].selectize;
                        conditionDropDown.disable();


                        var onChangeCriteriaKeyHandler = function (value) {
                            var self = this;
                            $utility.criteria.onChangeCriteriaKeyHandler(self, value, customer.get("id"), $selectValuesdropDown, $criteriaConditionDropDown, criteriaId);
                        }

                        var $selectKeydropDown = $('#' + criteriaId + ' .targetKeys').selectize({
                            maxItems: 1,
                            hideSelected: true,
                            onChange: onChangeCriteriaKeyHandler
                        }); // Criteria Key Drop Down

                        /*
                         *Intialize Criteria Key drop downs
                        */
                        //Get below data from ajax call and cache it
                        //On subsequent request check if any value is already selected and remove it while initializing next drop down

                        var fetchCustomerKeys = CommandCenter.request('TargetingCriteria:key', customer.get("id"));


                        $.when(fetchCustomerKeys)
                            .done(function (data) {
                                var dataForKeyDropDown = _.map(data.models, function (item) {
                                    return { text: item.get('Text'), value: item.get('Value') }
                                });
                                //Check if any of above value is already used

                                var selectedKey = $(".targetKeys > .full.has-items>div");

                                if (selectedKey.length > 0) {

                                    _.each(selectedKey, function (keys) {
                                        dataForKeyDropDown = _.filter(dataForKeyDropDown, function (keyItem) {
                                            return keyItem.text !== keys.textContent;
                                        });
                                    });
                                }

                                $selectKeydropDown[0].selectize.addOption(dataForKeyDropDown);
                                $selectKeydropDown[0].selectize.refreshOptions(false);
                            })
                            .fail(function (jqXHR, textStatus, errorThrown) {
                                console.log('Error while getting Targetting Keys: ' + JSON.stringify(jqXHR) + errorThrown);
                            });
                    };


                    baseView.on("show", function (e) {
                        baseView.header.show(headerView);
                        baseView.basicFieldList.show(basicCampaignFieldView);

                        baseView.criteria.show(criteriaView);

                        criteriaView.on("add:criteria:row", addCriteriaRowHandler);
                        criteriaView.on("btn:CreateCampaign:clicked", function () {
                            baseView.triggerMethod("CreateCampaignClicked");
                        });

                        criteriaView.on("show:Job:Count", $utility.jobs.jobCountView(baseView, customer.get("id"), view));

                        thisController.selectedJobsForCampaign({ customer: id, baseview: baseView });


                    });

                    /*Create Campaign Events */

                    headerView.on("btn:CreateCampaign:clicked", function () {
                        baseView.triggerMethod("CreateCampaignClicked");
                    });

                    //Criteria View Events

                    criteriaView.on("btn:ShowBooleanExpression:clicked", function () {

                        var getBooleanExpression = CommandCenter.request("TargetingCriteria:Get:BooleanExpress", $utility.criteria.createCriteriaExpression());

                        $.when(getBooleanExpression)
                            .done(function (data) {
                                baseView.booleanExpression.show(new view.BooleanExpressionView({ expression: JSON.stringify(data) }));
                                $('#boolean-expression-Modal').modal('show');
                            });


                    });

                    criteriaView.on("btn:showJobsBasedOnCritieria:clicked", function () {

                        thisController.staticCampaign({ customer: id, baseview: baseView });

                    });

                    criteriaView.on("add:criteria:keyToExistingRow", function (item) {
                        setTimeout($utility.jobs.jobCountView(baseView, customer.get("id"), view), 0);
                        New.Controller.refreshExistingCriteriaKey(customer.get("id"));
                    });
                    //--End Criteria View Events


                    basicCampaignFieldView.on("show:recommendations", function (options) {

                        var targetings = $utility.criteria.createCriteriaObject();
                        CommandCenter.CampaignsApp.New.Controller.getRecommendations(null, { targetings: targetings });
                    });

                    var resetCampaignFormView = function (cId) {
                        $('[class*="btn-save"]').attr('disabled', false);//enable save button
                        // clear the error region
                        baseView.errorRegion.reset();

                        //reset Selected Job List Area
                        $('.selectedJobList').hide(1000);
                        baseView.selectedJobList.reset();
                        thisController.selectedJobsForCampaign({ customer: id, baseview: baseView });

                        //Reset All Job List Area
                        baseView.jobListBasedOnCriteria.reset();

                        // clear the campaigns from cache
                        Backbone.fetchCache.clearItem("api/customers/" + cId);

                        //Clear Form
                        $("#campaignForm")[0].reset();

                        //Reset Criteria Collection
                        criteriaCollection.reset();
                        $(".criteria-dropdowns-area").hide();
                        $("#btnAddCampaignCriteria").show();
                        $("#lblAllJobCampaignInfo").show();

                        ////Reset DatePicker
                        $('#createEndDate').datepicker('clearDate');
                        $('#createStartDate').datepicker('setStartDate', '-0d');

                        $('#txtlblAllJobCampaignInfo').text(
                                "All jobs will be campaigned, if no campaign criteria (Locations, Occuapation or Custom key-values) is added.");

                        // make sure it is reset to a new campaign, this keeps bindings in tack
                        newCampaign.clear().set(newCampaign.defaults);
                    }


                    baseView.on("Campaign:create", function (data) {

                        if ($utility.criteria.isAnyFieldInCriteriaRowsEmpty()) {
                            $('[class*="btn-save"]').attr('disabled', false);
                            return;
                        }

                        var self = this;
                        //based on whether we have Selected Jobs create dynamic or statis campaign

                        //TODO: Weird first time Daily Cap On New Page is mapped to FutureDailyCap but on Edit Page it is map to DailyCap
                        // There is no way to create a generic template

                        data.FutureDailyCap = data.CurrentDailyCap;
                        data.CurrentDailyCap = null;

                        //TODO: find out a best way to decalre below variables

                        if (newCampaign.campaignedJobs().length > 0) {

                            data.IsDynamic = false;

                            baseView.warning.show(new view.CreateWarningView({
                                isDynamic: false,
                                btnText: 'Create Static Campaign'
                            })
                           );
                        } else {

                            data.IsDynamic = true;

                            baseView.warning.show(new view.CreateWarningView({
                                isDynamic: true,
                                btnText: 'Create Dynamic Campaign'
                            })
                           );
                        }

                        $('#campaign-create-warning-Modal').modal({ backdrop: 'static', keyboard: false });

                        $('#campaign-create-warning-Modal #btnContinue').click(function (e) {


                            _.each($(".btn-save-spinner"), function (item) {
                                $(item).show();
                            });

                            e.preventDefault();
                            $('#campaign-create-warning-Modal').modal('hide');

                            var cId = data.ProviderID;
                            data.Targetings = $utility.criteria.createCriteriaObject();
                            //Pluck Jobs
                            var jobs = newCampaign.campaignedJobs().models;
                            data.Jobs = [];
                            if (jobs.length > 0) {
                                _.each(jobs, function (job) {
                                    data.Jobs.push({ JobId: job.id });
                                });

                            }
                            //TODO : clean up certain aspect of Request Payload : Knitesh

                            // hide the form errors
                            $('.form-group, .input-group').removeClass('has-error');

                            // validate campaign data

                            var options = {
                                success: function (model, response, options) {

                                    _.each($(".btn-save-spinner"), function (item) {
                                        $(item).hide();
                                    });
                                    resetCampaignFormView(cId);

                                    baseView.errorRegion.show(new view.SubmitFormMessages({
                                        messages: [{ message: "Campaign created successfully." }]
                                    }));

                                    // set an interval to hide the success messages
                                    window.setTimeout(function () {
                                        if (baseView.getRegion("errorRegion") !== undefined) {
                                            baseView.errorRegion.reset();
                                        }
                                    }, 3000);
                                    toastr.success('Campaign created successfully.');
                                    // baseView.selectedJobList.reset();
                                },
                                error: function (model, response, options) {

                                    _.each($(".btn-save-spinner"), function (item) {
                                        $(item).hide();
                                    });

                                    // requires errors response from the server to get here
                                    $('[class*="btn-save"]').attr('disabled', false); //enable save button

                                    $('.form-errors').show();
                                    //TODO: Structure of error messages has been changed from Api, Confirm that they are passing correct Property Name in "name"
                                    var serverErrors = response.responseJSON;
                                    var errors = [];

                                    if (serverErrors) {
                                        _.each(serverErrors, function (item) {
                                            if (!item.message) {
                                                errors.push({
                                                    name: "",
                                                    message: "An Error has occured on the Server"
                                                });
                                            } else {
                                                errors.push({
                                                    name: item.name,
                                                    message: item.message
                                                });
                                            }
                                        });
                                    }

                                    baseView.errorRegion.show(new view.SubmitFormErrors({ errors: errors }));

                                    toastr.error('An error has occurred while creating a new campaign.');
                                }
                            };

                            // client-side validation
                            Backbone.listenTo(newCampaign, 'invalid', function (model, errors, options) {

                                _.each($(".btn-save-spinner"), function (item) {
                                    $(item).hide();
                                });

                                $('[class*="btn-save"]').attr('disabled', false); //enable save button

                                $('.has-error').removeClass('has-error');
                                _.each(errors,
                                    function (error) {
                                        //only on New screen only
                                        if (error.name === "FutureDailyCap") {
                                            error.name = "CurrentDailyCap";
                                            error.message = error.message.replace("Future", "");
                                        }

                                        var controlGroup = $('[name="' + error.name + '"]').parent();
                                        controlGroup.addClass('has-error');
                                    },
                                    this);

                                $('.btn-save').removeClass('disabled');
                                $('.form-errors').show();

                                toastr.error('A validation error has occurred.');

                                baseView.errorRegion.show(new view.SubmitFormErrors({ errors: errors }));
                            });

                            newCampaign.save(data, options);
                        });
                    }); // end on form:submit

                    /*END:Create Campaign Events */


                    $.when(fetchingCustomer).done(fetchingCustomerHandler);

                }); // end require
            },
            /* end buildNewCampaign */

            getRecommendations: function (layout, args) {

                var field = (layout == null) ? '#campaign-ppc' : $(layout.$el).find('#campaign-ppc');

                require(['models/Recommendation'], function () {
                    var fetchingRecommendations = CommandCenter.request("recommendation:entity", args.targetings);
                    $.when(fetchingRecommendations).done(function (recommendations) {
                        $(field).val(numeral(recommendations.ppc).format('0,0.00')).trigger("change");
                    }).fail(function () {
                        $(field).val("");
                    });
                });
            },

            selectedJobsForCampaign: function (args) {
                require(['models/Campaign', 'models/Job', 'backbone.fetch-cache'], function () {
                    var id = args.customer,
                        baseView = args.baseview,
                        newCampaign = baseView.basicFieldList.currentView.model;


                    var selectedjobListView = new view.SelectedJobList({
                        collection: newCampaign.campaignedJobs(),
                        isCampaignFeedEnabled: false
                    });

                    baseView.selectedJobList.show(selectedjobListView);

                    selectedjobListView.on("job:unselected", function (item) {
                        newCampaign.campaignedJobs().remove(item.job.model);
                    });
                    selectedjobListView.on("update:jobcount", function (collection) {
                        $(".selected-job-count").text(collection.length);
                        if (collection.length > 0) {
                            $('.selectedJobList').show(500);
                        } else {
                            $('.selectedJobList').hide(500);
                        }
                    });
                    baseView.on("job:selected", function (item) {
                        newCampaign.campaignedJobs().add(item.job.model);

                    });

                    baseView.on("job:selected:all", function (item) {
                        newCampaign.campaignedJobs().add(item);

                    });

                    baseView.on("job:unselected", function (item) {
                        newCampaign.campaignedJobs().remove(item.job.model);
                    });
                    baseView.on("job:unselected:all", function (item) {
                        newCampaign.campaignedJobs().remove(item);
                    });
                });
            },

            /* Static campaigning */
            staticCampaign: function (args) {
                require(['models/Campaign', 'models/Job', 'backbone.fetch-cache'], function () {
                    var id = args.customer,
                        baseView = args.baseview,
                        newCampaign = baseView.basicFieldList.currentView.model,
                        targeting = $utility.criteria.createCriteriaObject();

                    //All Jobs Returned From API -- Get Job Count 
                    $utility.jobs.count(id).done(function (jobcount) {
                        var jobListArgs = {
                            customer: id,
                            targeting: targeting,
                            selectedJobs: newCampaign.campaignedJobs(),
                            jobcount: jobcount
                        };
                        New.Controller.showJobs(baseView, jobListArgs);
                    });

                }); // end require
            },

            showJobs: function (baseView, args) {
                if (args.jobcount <= 1000 || args.showTheJobs) {
                    // show the jobs
                    require(['common/views', 'models/Job'], function (commonViews) {

                        // loading data view
                        var loadingView = new commonViews.Loading({
                            title: "Loading Job Data",
                            message: "Please wait while the job data is loading."
                        });

                        baseView.jobListBasedOnCriteria.show(loadingView);

                        //TODO: Knitesh- Send targeting Object
                        var fetchingJobs = CommandCenter.request("job:entities", args.customer, args.targeting);

                        $.when(fetchingJobs).done(function (jobs) {

                            // see if the user has already put the job in the campaign
                            if (args.selectedJobs && args.selectedJobs.length > 0) {
                                // user has selected jobs to be campaigned
                                var selected = _.pluck(args.selectedJobs.models, 'id');
                                var available = _.pluck(jobs.models, 'id');
                                var alreadySelected = _.intersection(selected, available);
                                _.each(alreadySelected, function (jId) {
                                    jobs.findWhere({ id: jId }).set("selectedForCampaign", true);
                                });
                            }

                            var jobListView = new view.JobListBasedOnCriteria({ collection: jobs, customerId: args.customer });

                            baseView.jobListBasedOnCriteria.show(jobListView);

                            baseView.on("childview:uncampaign:job", function (childview, args) {
                                if (jobs.get(args.job.model) !== undefined) {
                                    jobs.get(args.job.model).set("selectedForCampaign", false);
                                }
                            });

                            $("table").tablesorter({ debug: false });

                            jobListView.on("job:selected", function (data) {
                                baseView.trigger('job:selected', data);
                            });
                            jobListView.on("job:unselected", function (data) {
                                baseView.trigger('job:unselected', data);
                            });
                            jobListView.on("job:selected:all", function (data) {
                                // baseView.trigger('job:selected', data);
                                baseView.trigger('job:selected:all', data);
                            });
                            jobListView.on("job:unselected:all", function (data) {
                                // baseView.trigger('job:selected', data);
                                baseView.trigger('job:unselected:all', data);
                            });
                        })
                        .fail(function () {
                            baseView.jobListBasedOnCriteria.reset();
                            baseView.jobListBasedOnCriteria.show(new commonViews.Error404({ title: '...', message: "An error occurred while retreiving Jobs list. Please try later." }));
                        });

                    });
                    $('.selectedJobList')[0].scrollIntoView(true);
                } else {
                    // clear the jobs, if currently shown
                    baseView.jobListBasedOnCriteria.empty();

                    // show a button to confirm they want to load the volume of data
                    require(['common/views'], function (commonViews) {
                        var areYouSureView = new commonViews.AreYouSure({ customerId: args.customer, targeting: args.targeting, jobcount: args.jobcount, selectedJobs: args.selectedJobs });

                        baseView.jobListBasedOnCriteria.show(areYouSureView);

                        areYouSureView.on("show:jobs", function (args) {
                            args.showTheJobs = true;
                            CommandCenter.CampaignsApp.New.Controller.showJobs(baseView, args);
                        });
                    });
                }
                //Scroll to Job View
                $(".jobListBasedOnCriteria")[0].scrollIntoView(true);
            },
            /* end of Static campaigning */


            onChangeCriteriaValueHandler: function (self, value, baseView, providerId) {
                var key = _.find(value, function (key) {
                    return key === "-9999";
                });
                if (key != null && key === "-9999") {
                    if (self.items.length === Object.keys(self.options).length) {
                        //self.setValue('', true);
                        self.clear(true);
                        self.refreshOptions(true);
                    } else {
                        var keys = _.keys(self.options);
                        self.setValue(_.without(keys, "-9999"), true);
                        self.refreshOptions(false);
                    }

                }

                $utility.jobs.jobCountView(baseView, providerId, view);

            },

            refreshExistingCriteriaKey: function (customerId) {
                var criteriaKey = $('form').find('select[name="criteriaKey"]');

                _.map(criteriaKey, function (key) {

                    var fetchCustomerKeys = CommandCenter.request('TargetingCriteria:key', customerId);

                    $.when(fetchCustomerKeys).done(function (data) {
                        var dataForKeyDropDown = _.map(data.models,
                            function (item) {
                                return { text: item.get('Text'), value: item.get('Value') }
                            });
                        //Check if any of above value is already used

                        var selectedKey = $(".targetKeys > .full.has-items>div");
                        if (selectedKey.length > 0) {
                            _.each(selectedKey, function (keys) {
                                dataForKeyDropDown = _.filter(dataForKeyDropDown,
                                    function (keyItem) {
                                        return keyItem.text !== keys.textContent;
                                    });
                            });
                        }
                        if ($(key)[0].selectize) {
                            $(key)[0].selectize.addOption(dataForKeyDropDown);
                            $(key)[0].selectize.refreshOptions(false);
                        }
                    })
                        .fail(function (jqXHR, textStatus, errorThrown) {
                            console.log('Error while getting Targetting Keys: ' +
                                JSON.stringify(jqXHR) +
                                errorThrown);
                        });


                });

            },

            /* End -- Utility Functions */


        } // end New.Controller
    });

    return commandCenter.CampaignsApp.New.Controller;
});