﻿
define(["app", "apps/campaigns/show/show_view", "moment"], function (CommandCenter, View, moment) {
    CommandCenter.module("CampaignsApp.Show", function (Show, CommandCenter, Backbone, Marionette, $, _) {
        Show.Controller = {
            showCampaign: function (id) {
                require(['common/views', 'models/Campaign', 'models/Customer', 'lib/jquery.tablesorter', 'rickshaw'], function (CommonViews) {
                    var fetchingCampaign = CommandCenter.request("campaign:entity:withPerformance", id);
                    var campaignLayout = new View.Layout();

                    // loading data view
                    var loadingView = new CommonViews.Loading();
                    CommandCenter.contentRegion.show(loadingView);

                    // breadcrumb
                    //var breadcrumbView = new CommonViews.Breadcrumb({ collection: CommonViews.BreadcrumbCollection });
                    //CommandCenter.breadcrumbRegion.show(breadcrumbView);

                    $.when(fetchingCampaign)
                      .done(function (campaign) {
                            
                            var campaignView,
                            campaignStats,
                            campaignInfo,
                            campaignJobs,
                            graph,
                            fetchingCustomer = CommandCenter.request("customer:entity", campaign.get("ProviderID")); //Get Customer info

                            $.when(fetchingCustomer).done(function (customer) {
                                var cI = new CommonViews.CustomerIndicator({
                                    model: customer
                                });
                                CommandCenter.customerIndicatorRegion.show(cI);

                                // show the customer sidebar menu
                                var customerSidebar = new CommonViews.CustomerSidebarMenu({
                                    model: customer
                                });
                                customerSidebar.render();

                                if (campaign !== undefined) {
                                    campaignView = new View.Campaign({
                                        model: campaign
                                    });
                                    campaignInfo = new View.CampaignInfo({
                                        model: campaign,
                                        customer: customer
                                    });
                                    campaignStats = new View.CampaignStats({
                                        model: campaign,
                                        customer: customer
                                    });
                                    campaignStats.on("btn:ShowBooleanExpression:clicked", function() {
                                        var getBooleanExpression = CommandCenter.request("TargetingCriteria:Get:BooleanExpress",campaign.get("Targetings"));

                                        $.when(getBooleanExpression).done(function (data) {
                                                campaignLayout.booleanExpression.show(new View.BooleanExpressionView({ expression: JSON.stringify(data) }));
                                                $('#boolean-expression-Modal').modal('show');
                                            });

                                    });
                                    var args = {};
                                    args.CampaignId = id;
                                    args.customer = campaign.get("ProviderID");
                                    args.campaign = campaign;
                                    args.jobcount = campaign.get("CampaignPerformance").TotalJobCount;

                                    campaignLayout.on("show", function () {
                                        campaignLayout.campaignInfo.show(campaignInfo);
                                        campaignLayout.campaignStats.show(campaignStats);
                                        campaignLayout.campaign.show(campaignView);

                                        var fetchCampaignPerf = CommandCenter.request("campaign:daily:chart", id);
                                       
                                        $.when(fetchCampaignPerf).done(function (data) {
                                            renderCampaignPerformanceChart(data);
                                        });

                                        CommandCenter.CampaignsApp.Show.Controller.showJobs(campaignLayout, args);
                                    });
                                }
                                //reloadChartData
                                campaignView.on("reloadChartData", function (args) {
                                    $("#campaign-chart-spinner").show();
                                    var reloadChartData = CommandCenter.request("campaign:daily:chart", id, args);
                                    //var reloadChartData = campaign.get('dailyCapPerformance').fetch({
                                    //    cache: false,
                                    //    data: {
                                    //        numberOfDays: args
                                    //    }
                                    //});
                                    $.when(reloadChartData).done(function (data) {
                                        renderCampaignPerformanceChart(data);
                                        $("#campaign-chart-spinner").hide();
                                    });
                                });

                                CommandCenter.contentRegion.show(campaignLayout);
                                smartresize();
                            });

                            campaignLayout.campaignJobs.on("show", function () {
                                // if not loading view
                                if (campaignLayout.campaignJobs.currentView.collection !== undefined) {
                                    // enable search bar
                                    $("#search-box").val('');
                                    $("#search-box").prop("disabled", false);

                                    // have they typed anything in search bar
                                    $("#search-box").on("keyup.jobs", function (e) {
                                        var term = $(e.target).val();
                                        if (term.length >= 2) {
                                            term = term.toLowerCase();
                                            campaignLayout.campaignJobs.currentView.filter = function (child, index, collection) {
                                                var loc = (child.get('physicallocation') || "").toLowerCase();
                                                var refCode = (child.get('refcode') || "").toLowerCase();

                                                return _.str.include(loc, term) || _.str.include(refCode, term);
                                            }
                                        } else {
                                            campaignLayout.campaignJobs.currentView.filter = null;

                                        }

                                        campaignLayout.campaignJobs.currentView.render();
                                    });
                                } else {
                                    $("#search-box").prop("disabled", true);
                                }
                            });

                            // custom parser for click counts represented as XX/XXX
                            $.tablesorter.addParser({
                                // set a unique id
                                id: 'clicks',
                                is: function (s) {
                                    // return false so this parser is not auto detected
                                    return false;
                                },
                                format: function (s) {
                                    // format your data for normalization
                                    return Number(s.split("/")[0]);
                                },
                                // set type, either numeric or text
                                type: 'numeric'
                            });

                            $("table").tablesorter({
                                debug: false,
                                headers: {
                                    2: {
                                        sorter: 'clicks'
                                    }
                                }
                            });

                            // register the deboucing functions
                            var resize = function () {
                                smartresize();

                                //get the graphs parent
                                var parent = $("#chart_container");
                                if (graph !== undefined) {
                                    graph.configure({
                                        width: parent.innerWidth(),
                                        height: parent.innerHeight() - 20
                                    });
                                    graph.render();
                                }
                            };

                            var lazyLayout = _.debounce(resize, 200);
                            $(window).resize(lazyLayout);
                    })
                     .fail(function () {
                         CommandCenter.contentRegion.show(new CommonViews.Error404());
                     });
                });
            }, // end showCampaign

            showJobs: function (layout, args) {
                var campaign = args.campaign;
                if (args.jobcount <= 500 || args.showTheJobs) {
                    // show the jobs
                    require(['common/views', 'models/Job'], function (CommonViews) {
                        // loading data view
                        var loadingView = new CommonViews.Loading({
                            title: "Loading Job Data",
                            message: "Please wait while the job data is loading."
                        });
                        layout.campaignJobs.show(loadingView);

                        var fetchingJobs = CommandCenter.request("campaign:campaigned:jobs", args.CampaignId);
                       
                        $.when(fetchingJobs).done(function (jobs) {
                            var campaignJobs = new View.CampaignJobs({
                                collection: jobs,
                                originalCollection: jobs,
                                campaignId: args.CampaignId,
                                jobclicklimit: campaign.get('JobClickLimit')
                            });
                            layout.campaignJobs.show(campaignJobs);

                            $("table").tablesorter({
                                debug: false
                            });
                        });
                    });
                } else {
                    // clear the jobs, if currently shown
                    layout.campaignJobs.empty();

                    // show a button to confirm they want to load the volume of data
                    require(['common/views'], function (CommonViews) {
                        var areYouSureView = new CommonViews.AreYouSure({
                            customerId: args.customer,
                            jobcount: args.jobcount,
                            campaignId: args.CampaignId
                        });
                        layout.campaignJobs.show(areYouSureView);

                        areYouSureView.on("show:jobs", function (args) {
                            args.showTheJobs = true;
                            args.campaign = campaign;
                            CommandCenter.CampaignsApp.Show.Controller.showJobs(layout, args);
                        });
                    });
                }
            } // end ShowJobs
        }
    });

    function smartresize() {
        // do stuff as soon as the user stops resizing his browser for longer than 200ms

        // make campaign panels the same height
        $(".cc-campaign-panel").attr("style", "").setAllToMaxHeight();
    }

    function clearCampaignPerformanceGraph() {
        $('#legend').empty();
        $('#chart_container').html(
            '<div id="campaignChart"></div><div id="timeline"></div>'
        );
    }

    function renderCampaignPerformanceChart(data) {

        //start rendering on a fresh chart area
        clearCampaignPerformanceGraph();

        var campaignChartData = data.get("DailyCaps");
        var annotations = data.get("Annotations");
        var dailyCapHistory = data.get("DailyCapHistory") || [];

        var maxDailyCapValue = _.max(dailyCapHistory, function (cData) { return cData.DailyCap; }).Cap;
        var maxDailySpendValue = _.max(campaignChartData, function (cData) { return cData.DailySpend; }).DailySpend;
        var maxYValue = maxDailyCapValue > maxDailySpendValue ? maxDailyCapValue : maxDailySpendValue;

        var startDate = _.min(campaignChartData, function (cData) { return cData.Date; }).Date;
        //  console.log(maxYValue,startDate,moment.unix(startDate).utc().format("MMM DD, YYYY hh:mma"));

        // performance chart
        var campaignGraph = new Rickshaw.Graph({
            element: document.querySelector("#campaignChart"),
            series: [
            {
                name: 'Cap by Day',
                data: dailyCapHistory.map(function (d, index, array) {
                    var utcDte = moment.unix(d.Date).utc();
                    var dt = utcDte.unix();
                    return { x: dt, y: d.Cap };
                }),
                color: '#3e885d',
                renderer: 'bar'
            },
            {
                name: 'Total PPC',
                data: campaignChartData.map(function (d, index, array) {
                    var utcDte = moment.unix(d.Date).utc();
                    var dt = utcDte.unix();
                    return { x: dt, y: d.DailySpend, clicks: d.DailyClicks };
                }),
                color: '#0075C2',
                renderer: 'area'
            }
            ],
            renderer: 'multi',

            stroke: true,
            strokeWidth: 2,
            max: Number(maxYValue) + 10,
            interpolation: 'monotone'
        });

        // render the campaign performance chart
        campaignGraph.render();

        var time = new Rickshaw.Fixtures.Time();
        // vary the number of ticks depending on the number of days displaying
        if (campaignChartData.length < 30) {
            time.units.push({
                name: 'campaingChartX-AxisData',
                seconds: 86400, // 1 day
                formatter: function (d) {
                    return d3.time.format.utc('%b %e')(d);
                }
            });
        } else if (campaignChartData.length >= 30 && campaignChartData.length < 60) {
            time.units.push({
                name: 'campaingChartX-AxisData',
                seconds: 172800, // 2 days
                formatter: function (d) {
                    return d3.time.format.utc('%b %e')(d);
                }
            });
        } else if (campaignChartData.length >= 60 && campaignChartData.length < 90) {
            time.units.push({
                name: 'campaingChartX-AxisData',
                seconds: 432000, // 5 days
                formatter: function (d) {
                    return d3.time.format.utc('%b %e')(d);
                }
            });
        } else {
            time.units.push({
                name: 'campaingChartX-AxisData',
                seconds: 864000, // 10 days
                formatter: function (d) {
                    return d3.time.format.utc('%b %e')(d);
                }
            });
        }
        var seconds = time.unit('campaingChartX-AxisData');

        var x_axis = new Rickshaw.Graph.Axis.Time({
            graph: campaignGraph,
            ticksTreatment: 'glow',
            timeUnit: seconds
        });

        x_axis.render();

        var y_axis = new Rickshaw.Graph.Axis.Y({
            graph: campaignGraph,
            //orientation: 'left',
            tickFormat: Rickshaw.Fixtures.Number.formatKMBT,
            element: document.getElementById('y_axis'),
            ticksTreatment: 'glow'
        });

        y_axis.render();

        var hover = new Rickshaw.Graph.HoverDetail({
            graph: campaignGraph,
            formatter: function (series, x, y) {

                var dt = moment.unix(x).utc().format("ddd, MMM DD, YYYY");
                var dateObj = '<span>' + dt + '</span>';
                var valObj = '';

                switch (series.name) {
                    case "Cap by Day":
                        valObj = '<span>' + series.name + ': $' + Number(y).toFixed(2) + '</span>' + '<br />' + dateObj;
                        break;
                    case "Total PPC":
                        var point = _.find(campaignChartData, function (obj) {
                            return obj.Date === x;
                        });

                        var dailyCapReachedDateobj = point.DailyCapReachedDateTime > 0 ? moment.unix(point.DailyCapReachedDateTime).utc().format("ddd, MMM DD, YYYY, h:mm:ss a") : 'N/A';

                        valObj = '<span> Daily Spend: $' + Number(y).toFixed(2) +
                                   ' <br /> Daily Clicks: ' + point.DailyClicks +
                                   '<br /> Daily Cap reached :' + dailyCapReachedDateobj +
                                   '</span>';
                        break;
                }

                return valObj;
            },
            xFormatter: function (x) { return null; },
            yFormatter: function (y) { return null; }
        });

        var annotator = new Rickshaw.Graph.Annotate({
            graph: campaignGraph,
            element: document.getElementById('timeline')
        });

        //annotator.data = {};
        //annotator.update();

        var ca = _.sortBy(annotations, 'Timestamp');
        _.each(ca, function (element, index, list) {
            var utcDte = moment.unix(element.Timestamp).utc();
            var msg = element.Message;

            // see if the annotation is outside the 30 day window, if so, put as startDate so it shows
            if (element.Timestamp < startDate) {
                utcDte = moment.unix(startDate).utc();
                msg = msg.replace("set to", "started at") + " on ";

            }
            // figure out the date of this annotation, convert from second to milliseconds, chop off time
            //var utcDte = moment.unix(element.timestamp);
            //var dt = utcDte.startOf('day').local().unix();
            var dt = utcDte.unix();

            // see if we already have an item in the array with this date
            var data = annotator.data;
            if (annotator.data[dt]) {
                //annotator.data[dt].boxes[0].content += "<br /><span>" + (element.message + " at " + moment.unix(element.timestamp).utc().local().format("hh:mma")) + "</span>";
                annotator.data[dt].boxes[0].content += "<br /><span>" + (msg + " at " + moment.unix(element.Timestamp).utc().format("MMM DD, YYYY hh:mma")) + "</span>";
            } else {
                //annotator.add(dt, "<span>" + (element.message + " at " + moment.unix(element.timestamp).utc().local().format("hh:mma")) + "</span>");
                annotator.add(dt, "<span>" + (msg + " at " + moment.unix(element.Timestamp).utc().format("MMM DD, YYYY hh:mma")) + "</span>");
            }
        });
        annotator.update();

        var legend = new Rickshaw.Graph.Legend({
            graph: campaignGraph,
            element: document.querySelector('#legend')
        });

        var highlighter = new Rickshaw.Graph.Behavior.Series.Highlight({
            graph: campaignGraph,
            legend: legend,
            disabledColor: function () {
                return 'rgba(0, 0, 0, 0.2)'
            }
        });

        var highlighter = new Rickshaw.Graph.Behavior.Series.Toggle({
            graph: campaignGraph,
            legend: legend
        });


        var campaingGraphResize = function () {
            campaignGraph.configure({
                width: window.innerWidth * 0.78
            });
            campaignGraph.render();
        }

        $(window).resize(function () {
            campaingGraphResize();
        });

    }

    return CommandCenter.CampaignsApp.Show.Controller;
});
