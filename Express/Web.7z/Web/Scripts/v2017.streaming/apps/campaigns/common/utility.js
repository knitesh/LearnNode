﻿define(["app", "moment", "toastr", "selectize"], function (commandCenter, moment, toastr) {
    commandCenter.module("CampaignsApp.Utility", function ($utility, CommandCenter, Backbone, Marionette, $, _) {
        $utility.fn = {
            /* Utility Functions */
            /*
             * For Targeting Criteria Box
             */
            criteria: (function () {
                var isAnyFieldInCriteriaRowsEmpty = function () {

                    //check for Key
                    var isRowEmpty = false;

                    var keyNotSelected = $(".targetKeys > .not-full");

                    if (keyNotSelected.length > 0) {
                        keyNotSelected.addClass("error");
                        toastr.error('You must specify a criteria key');
                        isRowEmpty = true;
                    }

                    //check for Condtions
                    var conditionNotSelected = $(".booleanConditions  > .not-full");

                    if (conditionNotSelected.length > 0) {
                        conditionNotSelected.addClass("error");
                        toastr.error('You must select a condition.');
                        isRowEmpty = true;
                    }

                    //check for relations
                    var relationNotSelected = $(".criterionRelations  > .not-full");
                    if (relationNotSelected.length > 0) {
                        relationNotSelected.addClass("error");
                        toastr.error('You must select a relation operator between two criteria');
                        isRowEmpty = true;
                    }
                    //TODO: confirm whether we have to check for emptyness of the value field and how it impact UI flow : Knitesh

                    var valuesNotSelected = $(".targetValues.multi > .selectize-input").not('.has-items');
                    if (valuesNotSelected.length > 0) {
                        valuesNotSelected.addClass("error");
                        toastr.error('You must select values for Targeting criteria');
                        isRowEmpty = true;
                    }
                    //remove error class added to any item previously
                    var conditionSelected = $(".booleanConditions  > .full");
                    if ($(".booleanConditions  > .full").length > 0) {
                        _.each(conditionSelected, function (item) { $(item).removeClass("error"); });
                    }
                    var relationSelected = $(".criterionRelations  > .not-full");
                    if (relationSelected.length > 0) {
                        _.each(relationSelected, function (item) { $(item).removeClass("error"); });
                    }
                    var valuesSelected = $(".targetValues.multi > .selectize-input.has-items ");
                    if (valuesSelected.length > 0) {
                        _.each(valuesSelected, function (item) { $(item).removeClass("error"); });
                    }

                    //Return Result
                    return isRowEmpty;
                }

                var getUiPointerForCriteriaVariables = function () {
                    return {
                        loop: $('form').find('select[name="criteriaCondition"]').length,
                        conditions: $('form').find('select[name="criteriaCondition"]'),
                        values: $('form').find('select[name="criteriaValues"]'),
                        keys: $('form').find('select[name="criteriaKey"]'),
                        relations: $('form').find('select[name="criteriaRelation"]')
                    };
                }

                var createCriteriaObject = function () {
                    /* TODO: think a good way to serailize below items */
                    var Targetings = [];
                    var ui = getUiPointerForCriteriaVariables();

                    for (var i = 0; i < ui.loop; i++) {
                        if (ui.keys[i].value !== "") {
                            Targetings.push({
                                ScreenOrder: i,
                                Criteria: ui.keys[i].value,
                                Values: _.map($(ui.values[i])[0].options,
                                    function (item) { return item.value }),
                                Condition: ui.conditions[i].value,
                                Function: i === 0 ? "First" : ui.relations[i].value
                            });
                        }
                    }

                    return Targetings;
                    /*-----------------------*/
                }

                var createCriteriaExpression = function () {
                    /* TODO: think a good way to serailize below items */
                    var Targetings = [];
                    var ui = getUiPointerForCriteriaVariables();

                    for (var i = 0; i < ui.loop; i++) {
                        if (ui.keys[i].value !== "") {
                            Targetings.push({
                                ScreenOrder: i,
                                Criteria: ui.keys[i].value,
                                Values: _.map($(ui.values[i])[0].options, function (option) {
                                    return option.text;
                                }),
                                Condition: ui.conditions[i].value,
                                Function: i === 0 ? "First" : ui.relations[i].value
                            });
                        }
                    }

                    return Targetings;
                    /*-----------------------*/
                }

                var getConditionDropDownValues = function (value) {


                    var dataForConditionValueDropDown = [];

                    if (value !== "Locations" && value !== "Occupations") {

                        dataForConditionValueDropDown = [
                            {
                                text: 'Equals',
                                value: '1'
                            },
                            {
                                text: 'Contains',
                                value: '0'
                            },
                            {
                                text: 'Does Not Contains',
                                value: '2'
                            },
                            {
                                text: 'Does not equals',
                                value: '3'
                            }
                        ];
                    } else {
                        dataForConditionValueDropDown = [
                            {
                                text: 'Equals',
                                value: '1'
                            },
                            {
                                text: 'Does not equals',
                                value: '3'
                            }
                        ];
                    }

                    return dataForConditionValueDropDown;
                }

                /*On Change Event*/
                var onChangeCriteriaKeyHandler = function (self, value, providerId, $selectValuesdropDown, $criteriaConditionDropDown, criteriaId) {
                    if (!value.length) return;

                    //TODO: check if this key is already selected in any other Drop Down, if yes, add error class and skip below

                    $(".targetKeys > .full").removeClass("error");//remove error class if any present

                    var allExistingKeys = $(".targetKeys > option");

                    if (_.countBy(allExistingKeys, function (key) { return key.value === value ? 'Count' : ''; }).Count > 1) {

                        self.removeOption(value);
                        self.refreshOptions(true);

                        toastr.error('Duplicate Key. Please select a key that has not been used');

                        return false;
                    };


                    var selectValuesdropDown = $selectValuesdropDown[0].selectize;
                    var conditionDropDown = $criteriaConditionDropDown[0].selectize;

                    var dataForValueDropDown = getConditionDropDownValues(value);

                    if (value !== "Locations" && value !== "Occupations") {
                        selectValuesdropDown.settings.create = true;
                    } else {
                        selectValuesdropDown.settings.create = false;
                    }

                    /* Condition Drop Down */
                    conditionDropDown.disable();
                    conditionDropDown.clearOptions();
                    conditionDropDown.load(function (callback) {
                        conditionDropDown.enable();
                        callback(dataForValueDropDown);
                    });

                    /* Values Drop Down */
                    selectValuesdropDown.disable();
                    selectValuesdropDown.clearOptions();

                    selectValuesdropDown.load(function (callback) {
                        //get below result based on the value passed :value

                        var fetchCustomerTargetKeyValues = CommandCenter.request("TargetingCriteria:Key:Values", providerId, value);

                        $.when(fetchCustomerTargetKeyValues).done(function (data) {

                            var dataForValueDropDown = _.map(data.models, function (item) {
                                return { text: item.get('Text'), value: item.get('Value') }
                            });

                            dataForValueDropDown.push({ text: "Select All/Clear All", value: '-9999' });

                            var results = dataForValueDropDown;

                            selectValuesdropDown.enable();

                            callback(results);
                        })
                            .fail(function (jqXHR, textStatus, errorThrown) {
                                console.log('Error while getting Targetting Values:: ' + JSON.stringify(jqXHR) + errorThrown);
                            });

                    });
                }
                return {
                    isAnyFieldInCriteriaRowsEmpty: isAnyFieldInCriteriaRowsEmpty,
                    getUiPointerForCriteriaVariables: getUiPointerForCriteriaVariables,
                    createCriteriaObject: createCriteriaObject,
                    createCriteriaExpression: createCriteriaExpression,
                    getConditionDropDownValues: getConditionDropDownValues,
                    onChangeCriteriaKeyHandler: onChangeCriteriaKeyHandler
                }
            })(),
            /*
            * For Jobs
            */
            jobs: (function () {

                var getJobCount = function (providerId) {

                    var targeting = $utility.fn.criteria.createCriteriaObject();

                    var getCount = CommandCenter.request("job:count", providerId, targeting);

                    var defer = $.Deferred();

                    $.when(getCount).done(function (val) {
                        defer.resolve(val);
                    });

                    return defer.promise();
                }

                var showJobCount = function (baseView, providerId, view) {

                    var baseview = baseView;
                    //reset job list view
                    baseView.jobListBasedOnCriteria.reset();

                    getJobCount(providerId).done(function (jobCount) {

                        var jobCountView = new view.JobCount({ count: jobCount });
                        baseview.jobCount.show(jobCountView);

                    });

                }

                return {
                    count: getJobCount,
                    jobCountView: showJobCount
                }

            })()

            /* End -- Utility Functions */
        }
    });

    return commandCenter.CampaignsApp.Utility.fn;
});