﻿require.config({
    config: {
        moment: {
            noGlobal: true
        }
    },
    paths: {
        underscore: 'lib/underscore.min',
        'underscore-string': 'lib/underscore.string.min',
        backbone: 'lib/backbone.min',
        localstorage: "lib/backbone.localStorage.min",
        'backbone.syphon': 'lib/backbone.syphon.min',
        marionette: 'lib/backbone.marionette.min',
        jquery: 'lib/jquery-1.11.1.min',
        text: 'lib/text',
        tpl: 'lib/underscore-tpl',
        json2: 'lib/json2',
        numeral: 'lib/numeral.min',
        'moment': 'lib/moment.min',
        bootstrap: 'lib/bootstrap.min',
        selectize: 'lib/selectize.min',
        spin: 'lib/spin',
        'spin.jquery': 'lib/spin.jquery',
        'backbone.fetch-cache': 'lib/backbone.fetch-cache.min',
        d3: 'lib/d3.min',
        rickshaw: 'lib/rickshaw.kncustom.min',
        chartjs: 'lib/chart.min',
        datepicker: 'lib/bootstrap-datepicker3.min',
        chosen: 'lib/chosen.jquery.min',
        toastr: 'lib/toastr'
    },
    shim: {
        'lib/backbone.virtual-collection': ['backbone'],
        'lib/backbone.associate': ['backbone'],
        'lib/jquery.tablesorter': ['jquery'],
        'lib/jquery.resize': ['jquery'],
        underscore: {
            exports: '_'
        },
        'underscore-string': {
            deps: ['underscore']
        },
        backbone: {
            exports: 'Backbone',
            deps: ['jquery', 'underscore', 'json2']
        },
        localstorage: ['backbone'],
        'backbone.syphon': ['backbone'],
        marionette: {
            exports: 'Marionette',
            deps: ['backbone']
        },
        tpl: ['text'],
        bootstrap: ['jquery'],
        selectize: ['jquery'],
        'spin.jquery': ['spin', 'jquery'],
        'backbone.fetch-cache': ['backbone', 'underscore'],
        d3: { exports: 'd3' },
        rickshaw: {
            deps: ['d3'],
            exports: 'Rickshaw'
        },
        'chartjs': {
            exports: 'Chart'
        },
        "datepicker": {
            deps: ["bootstrap", "jquery"],
            exports: "$.fn.datetimepicker"
        },
        'chosen': {
            deps: ['jquery'],
            exports: "$.fn.chosen"
          
        },
        toastr: {
            deps: ['jquery'],
            exports: 'toastr'
        },
       
    }
});