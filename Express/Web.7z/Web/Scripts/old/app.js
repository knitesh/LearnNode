﻿define(['marionette'], function (marionette) {
    var commandCenter = new marionette.Application();

    commandCenter.addRegions({
        searchBarRegion: "#search-bar",
        customerInfoRegion: ".customer-info",
        customerIndicatorRegion: "#customerIndicator",
        breadcrumbRegion: ".customer-breadcrumb",
        mainContentRegion: ".main",
        contentRegion: "#content",
        loginControlRegion: "#login-control"
    });

    commandCenter.navigate = function (route, options) {
        options || (options = {});
        Backbone.history.navigate(route, options);
    };

    commandCenter.getCurrentRoute = function () {
        return Backbone.history.fragment;
    };

    commandCenter.isAuthenticated = function () {
        var authContext = new AuthenticationContext(config);
        var token = authContext.getCachedToken(authContext.config.loginResource);

        return (token !== null && token.length > 0);
    };

    commandCenter.activityPermissionsMap = {
        "edit active campaign": {
            roles: ['3ddf5a27-7f09-4d5c-b594-db94b96c142e']
        },
        "edit disabled campaign": {
            roles: ['3ddf5a27-7f09-4d5c-b594-db94b96c142e']
        },
        "activate campaign": {
            roles: ['3ddf5a27-7f09-4d5c-b594-db94b96c142e']
        },
        "edit contract": {
            roles: ['3ddf5a27-7f09-4d5c-b594-db94b96c142e']
        },
        "create contract": {
            roles: ['3ddf5a27-7f09-4d5c-b594-db94b96c142e']
        },
        "edit customer": {
            roles: ['3ddf5a27-7f09-4d5c-b594-db94b96c142e']
        }
    };

    commandCenter.roleForActivity = function (activity) {
        var retVal = true;
        if ((typeof window.CommandCenter.Server.adalconfig != 'undefined') && (window.CommandCenter.Server.adalconfig.active == "true")) {
            if (_.has(commandCenter.activityPermissionsMap, activity)) {
                // check to see if they have the appropriate role
                var roles = commandCenter.activityPermissionsMap[activity].roles;
                if (_.intersection(roles, commandCenter.loggedInUser.get("roles")).length === 0) {
                    retVal = false;
                }
            }
        }

        return retVal;
    };

    commandCenter.startSubApp = function (appName, args) {
        if ((typeof window.CommandCenter.Server.adalconfig != 'undefined') && (window.CommandCenter.Server.adalconfig.active === "true")) {
            var authContext = new AuthenticationContext(config);

            // check their login information
            if (!commandCenter.isAuthenticated()) {
                // force relogin
                authContext.config.extraQueryParameter = 'prompt=login';
                authContext.login();
                return;
            } else {
                commandCenter.switchSubApp(appName, args);
            }
        } else {
            commandCenter.switchSubApp(appName, args);
        }
    };

    commandCenter.setUserRoles = function (callback, args) {
        require(['common/views', 'models/User', 'backbone.fetch-cache'], function (CommonViews) {
            if ((typeof window.CommandCenter.Server.adalconfig != 'undefined') && (window.CommandCenter.Server.adalconfig.active == "true")) {
                // get the users role
                if (commandCenter.loggedInUser.get("roles").length == 0) {
                    var fetchingUser = commandCenter.request("user:roles");
                    $.when(fetchingUser).done(function (user) {
                        callback.apply(this, args);
                    });
                } else {
                    callback.apply(this, args);
                }
            }
        });
    };

    commandCenter.buildUserMenu = function () {

        require(['common/views', 'models/User'], function (commonViews) {

            if (typeof commandCenter.loggedInUser === 'undefined') {
                commandCenter.loggedInUser = new commandCenter.Models.User();
            }

            if ((typeof window.CommandCenter.Server.adalconfig !== 'undefined') && (window.CommandCenter.Server.adalconfig.active === "true")) {
                var authContext = new AuthenticationContext(config);
                var user = authContext.getCachedUser();

                commandCenter.loggedInUser.set({
                    "userName": user.userName,
                    "given_name": user.profile.given_name,
                    "family_name": user.profile.family_name,
                    "expires": user.profile.exp
                });
            };

            var searchBarView = new commonViews.SearchBar({ model: commandCenter.loggedInUser });
            
            commandCenter.searchBarRegion.show(searchBarView);
        });
    };

    commandCenter.switchSubApp = function (appName, args) {
        var currentApp = appName ? commandCenter.module(appName) : null;
        if (commandCenter.currentApp === currentApp) { return; }

        if (commandCenter.currentApp) {
            commandCenter.currentApp.stop();
        }

        commandCenter.currentApp = currentApp;
        if (currentApp) {
            currentApp.start(args);
        }
    };

    // common function, find a place for these
    $.fn.setAllToMaxHeight = function () {
        return this.height(Math.max.apply(this, $.map(this, function (e) {
            //return $(e).outerHeight();
            //return $(e).innerHeight();
            //return $(e).height();
            //var h = $(e).children(".card-container").outerHeight() + $(e).children(".preview").outerHeight();
            var h = $(e).outerHeight();
            return h;
        })));
    };

    // append token to all ajax requests
    $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if ((typeof window.CommandCenter.Server.adalconfig != 'undefined') && (window.CommandCenter.Server.adalconfig.active == "true")) {
            var authContext = new AuthenticationContext(config);
            if (!commandCenter.isAuthenticated()) {
                jqXHR.abort();
                // force relogin
                authContext.config.extraQueryParameter = 'prompt=login';
                authContext.login();
                return;
            }
            authContext.config.extraQueryParameter = '';
            authContext.acquireToken(authContext.config.clientId, function (error, token) {
                if (error || !token) {
                    //console.log('ACQUIRE TOKEN ERROR!! ' + error);
                    authContext.logOut();
                    return;
                }
                jqXHR.setRequestHeader('Authorization', ("Bearer ".concat(token)));
            });
          
            options.url = window.CommandCenter.Server.BaseUrl + options.url;
        }
    });

    commandCenter.on("start", function () {
        var startHandler =  function() {
            /* off-canvas sidebar toggle */
            $(document)
                .on("click",
                    "div[data-toggle='offcanvas']",
                    function() {
                        $('.row-offcanvas').toggleClass('active');

                        $('.sidebar-offcanvas .sidebar-nav')
                            .toggleClass('hidden-xs')
                            .toggleClass('visible-xs');
                        $(this)
                            .find('i:first-of-type')
                            .toggleClass('fa-angle-right')
                            .toggleClass('fa-angle-left');
                    });

            // set the two main columns to equal height
            $('#main')
                .resize(function() {
                    if ($('.sidebar-nav').css('display') != 'none') {
                        var lH = $("#sidebar").outerHeight();
                        var rH = $("#main").outerHeight();
                        $("#sidebar").height(rH);
                    }
                });

            // setup the User Menu normally displayed on top right hand
            commandCenter.buildUserMenu();

            Backbone.history.start();

            if (commandCenter.getCurrentRoute() === "") {
                commandCenter.trigger("customers:list");
            };
        };

        if (Backbone.history) {
                require([
                       'apps/customers/customers_app',
                       'apps/campaigns/campaigns_app',
                       'apps/contracts/contracts_app',
                       'apps/reports/reports_app',
                       'lib/jquery.resize'
                ],startHandler)
            };

    });

    return commandCenter;
});