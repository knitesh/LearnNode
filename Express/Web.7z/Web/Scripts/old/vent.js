﻿define(['backbone', 'marionette'], function (Backbone, Marionette) {
    "use strict";
    console.log("vent.js::");

    return new Backbone.Wreqr.EventAggregator();
});