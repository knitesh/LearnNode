﻿require.config({
    config: {
        moment: {
            noGlobal: true
        }
    },
    paths: {
        underscore: 'lib/underscore.min',
        'underscore-string': 'lib/underscore.string.min',
        backbone: 'lib/backbone.min',
        localstorage: "lib/backbone.localStorage.min",
        'backbone.syphon': 'lib/backbone.syphon.min',
        marionette: 'lib/backbone.marionette.min',
        jquery: 'lib/jquery-1.11.1.min',
        text: 'lib/text',
        tpl: 'lib/underscore-tpl',
        json2: 'lib/json2',
        numeral: 'lib/numeral.min',
        'moment': 'lib/moment.min',
        bootstrap: 'lib/bootstrap.min',
        selectize: 'lib/selectize.min',
        spin: 'lib/spin',
        'spin.jquery': 'lib/spin.jquery',
        'backbone.fetch-cache': 'lib/backbone.fetch-cache.min',
        d3: 'lib/d3.min',
        rickshaw: 'lib/rickshaw.kncustom',
        chartjs: 'lib/chart.min',
        adal: 'lib/adal',
        routefilter: 'lib/backbone.routefilter.min',
        wookmark: 'lib/wookmark.min',
        datepicker: 'lib/bootstrap-datepicker.min',
        chosen: 'lib/chosen.jquery.min',
        toastr: 'lib/toastr'
    },
    shim: {
        'lib/backbone.virtual-collection': ['backbone'],
        'lib/backbone.associate': ['backbone', 'underscore'],
        'lib/jquery.tablesorter': ['jquery'],
        'lib/jquery.resize': ['jquery'],
        routefilter: ['backbone'],
        adal: {
            exports: 'AuthenticationContext'
        },
        underscore: {
            exports: '_'
        },
        'underscore-string': {
            deps: ['underscore']
        },
        backbone: {
            exports: 'Backbone',
            deps: ['jquery', 'underscore', 'json2']
        },
        localstorage: ['backbone'],
        'backbone.syphon': ['backbone'],
        marionette: {
            exports: 'Marionette',
            deps: ['backbone']
        },
        tpl: ['text'],
        bootstrap: ['jquery'],
        selectize: ['jquery'],
        'spin.jquery': ['spin', 'jquery'],
        'backbone.fetch-cache': ['backbone', 'underscore'],
        d3: { exports: 'd3' },
        rickshaw: {
            deps: ['d3'],
            exports: 'Rickshaw'
        },
        'chartjs': {
            exports: 'Chart'
        },
        "datepicker": {
        deps: ["bootstrap", "jquery"],
        exports: "$.fn.datetimepicker",
        
        },
        'chosen': {
            deps: ['jquery'],
            exports: "$.fn.chosen"

        },
        toastr: {
            deps: ['jquery'],
            exports: 'toastr'
        },
        
    }
});

// Define the window and document modules so they are available for the Wookmark plugin
define('window', function () {
    return window;
});

define('document', function () {
    return document;
});

require(['app', 'bootstrap', 'lib/adal'], function (CommandCenter) {
    "use strict";

    if (!window.location.origin) {
        window.location.origin = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port : '');
    }

    if (window.CommandCenter.Server.adalconfig.active == "true") {
        // Enter Global Config Values & Instantiate ADAL AuthenticationContext
        window.config = {
            tenant: window.CommandCenter.Server.adalconfig.tenant,
            clientId: window.CommandCenter.Server.adalconfig.clientId,
            postLogoutRedirectUri: window.location.origin,
            cacheLocation: 'localStorage', // enable this for IE, as sessionStorage does not work for localhost.
            extraQueryParameter: 'prompt=login'
        };
        var authContext = new AuthenticationContext(config);

        // Check For & Handle Redirect From AAD After Login
        var isCallback = authContext.isCallback(window.location.hash);
        authContext.handleWindowCallback();
        //$errorMessage.html(authContext.getLoginError());

        if (isCallback && !authContext.getLoginError()) {
            window.location = authContext._getItem(authContext.CONSTANTS.STORAGE.LOGIN_REQUEST);
        }

        $(document).on('click', '.logout-link', function (e) {
            e.preventDefault();
            authContext.logOut();
        });

        $(document).on('click', ' .login-link', function (e) {
            e.preventDefault();
            authContext.login();
        });

        // Check Login Status, Update UI
        var user = authContext.getCachedUser();

        if (user) {
            CommandCenter.start();
        } else {
            authContext.login();
        }
    } else {
        CommandCenter.start();
    }
});