﻿//Need to complete all below 

define(['app', 'moment', 'fixtures', 'lib/jasmine-sinon'],
    function (App, moment) {
        var objCampaign = {
            "customerId": 679,
            "id": 17864,
            "name": "Darin  AppCast Test  7/8",
            "refcode": "679_Darin  AppCast Test  7/8_d91a9221-f24c-412b-ba1f-3cabfd014bee",
            "description": null,
            "status": "Active",
            "hasbeenactivated": "Active",
            "ppc": 1,
            "jobclicklimit": 100,
            "startdate": "2016-10-04T16:34:36",
            "enddate": null,
            "budget": {
                "realized": 231,
                "total": 300,
                "budgetrealizeddate": "2016-07-10T05:31:09"
            },
            "performance": {
                "total": 3,
                "noClicks": 1,
                "active": 0,
                "clicks": 231,
                "applies": 0
            },
            "criteria": [],
            "locations": null,
            "occupations": null,
            "isdynamic": false,
            "iscampaignfeedenabled": false
        };
        var objCustomer = {};
        describe("Campaign Clone Creation suite",
            function () {
                beforeEach(function () {
                    spyOn(App, "request").and.returnValue(objCampaign);
                    this.campaign = App.request("campaign:entity", 17864);
                });
                it("shoule have default campaign name",
                    function() {
                        expect(this.campaign.name).not.toBeNull();
                    });
                it("shoule have PPC populated",
                   function () {
                       expect(this.campaign.ppc).not.toBeNull();
                   });
                it("shoule have maximum clicks per job populated",
                  function () {
                      expect(this.campaign.jobclicklimit).not.toBeNull();
                  });
                it("shoule have Budget populated",
                 function () {
                     expect(this.campaign.budget).not.toBeNull();
                 });
            });
    });