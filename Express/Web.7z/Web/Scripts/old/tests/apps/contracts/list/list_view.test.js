﻿define(['app', 'apps/contracts/list/list_view', 'moment', 'lib/jasmine-sinon'], function (App, View, moment) {
    describe("Contract List View", function () {
        describe("Layout", function () {
            beforeEach(function () {
                this.layout = new View.Layout();
            });

            describe("Instantiation", function () {
                it("should create a div element", function () {
                    expect(this.layout.el.nodeName).toEqual("DIV");
                });

                it("should have a class of 'row'", function () {
                    expect($(this.layout.el).hasClass('row')).toBeTruthy();
                });

                it("should have a template defined", function () {
                    expect(this.layout.template).toBeDefined();
                });

                it("should have Six regions defined", function () {
                    expect(this.layout.regions).toBeDefined();
                    expect(_.size(this.layout.regions)).toEqual(6);
                });
            });
        });

        describe("Empty", function () {
            beforeEach(function () {
                this.empty = new View.Empty();
            });

            describe("Instantiation", function () {
                it("should create a div element", function () {
                    expect(this.empty.el.nodeName).toEqual("DIV");
                });

                it("should have a template defined", function () {
                    expect(this.empty.template).toBeDefined();
                });
            });
        });

        describe("List", function () {
            beforeEach(function () {
                this.list = new View.List();
                CommandCenter = {
                    Server: {
                        BaseUrl: "/",
                        adalconfig: {
                        
                        }
                    }
                };
            });

            describe("Instantiation", function () {
                it("should create a div element", function () {
                    expect(this.list.el.nodeName).toEqual("DIV");
                });

                it("should have a template defined", function () {
                    expect(this.list.template).toBeDefined();
                });

                it("should have a empty template defined", function () {
                    expect(this.list.emptyView).toBeDefined();
                });

                it("should have a childView template defined", function () {
                    expect(this.list.childView).toBeDefined();
                });

                it("should have a childViewContainer of 'list-group'", function () {
                    expect(this.list.childViewContainer).toEqual('.list-group');
                });

                // TODO: test triggers
            });
        });

        describe("ListItem", function () {
            beforeEach(function () {
                this.model = App.request("contract:entity:new");
                this.listItem = new View.ListItem({ model: this.model });
                CommandCenter = {
                    Server: {
                        BaseUrl: "/",
                        adalconfig: {

                        }
                    }
                };
            });

            describe("Instantiation", function () {
                it("should create a anchor element", function () {
                    expect(this.listItem.el.nodeName).toEqual("A");
                });

                it("should have a class of 'list-group-item clearfix'", function () {
                    expect($(this.listItem.el).hasClass('list-group-item clearfix')).toBeTruthy();
                });

                it("should have a template defined", function () {
                    expect(this.listItem.template).toBeDefined();
                });

                it("should have an href attribute defined", function () {
                    expect(this.listItem.attributes).toBeDefined();
                    expect(this.listItem.attributes).toEqual(jasmine.objectContaining({ "href": "#" }));
                });

                // TODO: test triggers
            });

            // TODO: test rendering
        });
    });
});
