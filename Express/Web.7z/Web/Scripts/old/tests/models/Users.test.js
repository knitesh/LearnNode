﻿define(['app'], function (App) {
    describe("User Model", function () {
        beforeEach(function () {
            this.user = new App.Models.User();
        });

        it("should have a default userName of empty string", function () {
            expect(this.user.get('userName')).toBe("");
        });

        it("should have a default given_name of empty string", function () {
            expect(this.user.get('given_name')).toBe("");
        });

        it("should have a default family_name of empty string", function () {
            expect(this.user.get('family_name')).toBe("");
        });

        it("should have a default expires of empty string", function () {
            expect(this.user.get('expires')).toBe("");
        });

        it("should have a default roles of empty array", function () {
            expect(this.user.get('roles').length).toEqual(0);
        });
    });
});