﻿define(['app', 'numeral'], function (App) {
    describe("Campaign Model", function () {
        beforeEach(function () {
            this.campaign = App.request("campaign:entity:new");
        });

        it("should have a default empty string name", function () {
            expect(this.campaign.get('name')).toBe("");
        });

        it("should have a default empty string description", function () {
            expect(this.campaign.get('description')).toBe("");
        });

        it("should have a default locations of null", function () {
            expect(this.campaign.get('locations')).toBeNull();
        });

        it("should have a default occupations of null", function () {
            expect(this.campaign.get('occupations')).toBeNull();
        });

        it("should have a default ppc of 0", function () {
            expect(this.campaign.get('ppc')).toBe(0);
        });

       
        /*
        it("should have a default jobcount of null", function () {
            expect(this.campaign.get('jobcount')).toBeNull();
        });
        */

        it("should have a default jobclicklimit of 250", function () {
            expect(this.campaign.get('jobclicklimit')).toBe(250);
        });

        it("should have a default budget of 0", function () {
            expect(this.campaign.get('budget')).toBe(0);
        });

        it("should have a default jobids of null", function () {
            expect(this.campaign.get('jobids')).toBeNull();
        });

        it("should not save when name is empty", function () {
            var eventSpy = sinon.spy();
            this.campaign.on("invalid", eventSpy);
            this.campaign.save({ "name": "" });
            expect(eventSpy).toHaveBeenCalledOnce();
            expect(eventSpy).toHaveBeenCalledWith(this.campaign);
            expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'Campaign name is required.' }));
        });

        it("should not save when Start Date is empty", function () {
            var eventSpy = sinon.spy();
            this.campaign.on("invalid", eventSpy);
            this.campaign.save({ "startdate": "" });
            expect(eventSpy).toHaveBeenCalledOnce();
            expect(eventSpy).toHaveBeenCalledWith(this.campaign);
            expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'Campaign start date is required.' }));
        });
        //it("should not save when Start Date is not greater than todays date", function () {
        //    var eventSpy = sinon.spy();
        //    var currentDate = new Date();
        //    currentDate.setDate(-1);
        //    this.campaign.on("invalid", eventSpy);
        //    this.campaign.save({ "startdate": currentDate });
        //    expect(eventSpy).toHaveBeenCalledOnce();
        //    expect(eventSpy).toHaveBeenCalledWith(this.campaign);
        //    expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'Campaign Start Date needs to be greater or equal to todays date.' }));
        //});

        /*
        it("should not save when if location or occupation is not defined", function () {
            var eventSpy = sinon.spy();
            this.campaign.on("invalid", eventSpy);
            this.campaign.save({ "location": null, "occupation": null });
            expect(eventSpy).toHaveBeenCalledOnce();
            expect(eventSpy).toHaveBeenCalledWith(this.campaign);
            expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'Either location or occupation is required.' }));
        });
        */

        it("should save a la carte campaign when location and occupation are not defined", function () {
            var eventSpy = sinon.spy();
            this.campaign.on("invalid", eventSpy);
            this.campaign.save({ "isdynamic": false, "location": null, "occupation": null });
            expect(eventSpy).toHaveBeenCalledOnce();
            expect(eventSpy).toHaveBeenCalledWith(this.campaign);
            expect(eventSpy.args[0][1]).not.toContain(jasmine.objectContaining({ message: 'Either location or occupation is required.' }));
        });

        it("should not save when ppc is 0", function () {
            var eventSpy = sinon.spy();
            this.campaign.on("invalid", eventSpy);
            this.campaign.save({ "ppc": "0" });
            expect(eventSpy).toHaveBeenCalledOnce();
            expect(eventSpy).toHaveBeenCalledWith(this.campaign);
            expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'PPC is required and must be greater than $0.00.' }));
        });

        /*
        it("should not save when jobcount is not a number", function () {
            var eventSpy = sinon.spy();
            this.campaign.on("invalid", eventSpy);
            this.campaign.save({ "jobcount": "something" });
            expect(eventSpy).toHaveBeenCalledOnce();
            expect(eventSpy).toHaveBeenCalledWith(this.campaign);
            expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'Job Count is required.' }));
        });

        it("should not save when jobcount is 0 or less", function () {
            var eventSpy = sinon.spy();
            this.campaign.on("invalid", eventSpy);
            this.campaign.save({ "jobcount": "-10" });
            expect(eventSpy).toHaveBeenCalledOnce();
            expect(eventSpy).toHaveBeenCalledWith(this.campaign);
            expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'Job Count must be a number greater than 0.' }));
        });
        */

        it("should not save when budget is undefined", function () {
            var eventSpy = sinon.spy();
            this.campaign.on("invalid", eventSpy);
            this.campaign.save({ "budget": null });
            expect(eventSpy).toHaveBeenCalledOnce();
            expect(eventSpy).toHaveBeenCalledWith(this.campaign);
            expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'A budget is required.' }));
        });

        it("should not save when budget is 0", function () {
            var eventSpy = sinon.spy();
            this.campaign.on("invalid", eventSpy);
            this.campaign.save({ "budget": "0" });
            expect(eventSpy).toHaveBeenCalledOnce();
            expect(eventSpy).toHaveBeenCalledWith(this.campaign);
            expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'Your budget must be greater than 0.' }));
        });

        it("should not save when budget is a negative number", function () {
            var eventSpy = sinon.spy();
            this.campaign.on("invalid", eventSpy);
            this.campaign.save({ "budget": "-1,000.00" });
            expect(eventSpy).toHaveBeenCalledOnce();
            expect(eventSpy).toHaveBeenCalledWith(this.campaign);
            expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'Your budget must be greater than 0.' }));
        });

        it("should not save when jobclicklimit is undefined", function () {
            var eventSpy = sinon.spy();
            this.campaign.on("invalid", eventSpy);
            this.campaign.save({ "jobclicklimit": null });
            expect(eventSpy).toHaveBeenCalledOnce();
            expect(eventSpy).toHaveBeenCalledWith(this.campaign);
            expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'Clicks Per Job is required.' }));
        });

        it("should not save when jobclicklimit is not a number", function () {
            var eventSpy = sinon.spy();
            this.campaign.on("invalid", eventSpy);
            this.campaign.save({ "jobclicklimit": "abcde" });
            expect(eventSpy).toHaveBeenCalledOnce();
            expect(eventSpy).toHaveBeenCalledWith(this.campaign);
            expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'Clicks Per Job is required.' }));
        });

        it("should not save when jobclicklimit is less than 0", function () {
            var eventSpy = sinon.spy();
            this.campaign.on("invalid", eventSpy);
            this.campaign.save({ "jobclicklimit": "-10" });
            expect(eventSpy).toHaveBeenCalledOnce();
            expect(eventSpy).toHaveBeenCalledWith(this.campaign);
            expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'Clicks Per Job must be greater than 0.' }));
        });
    });
});