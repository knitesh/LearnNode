﻿define(['app', 'moment', 'fixtures', 'lib/jasmine-sinon'], function (App, moment) {
    describe("Contract Model", function () {
        beforeEach(function () {
            this.server = sinon.fakeServer.create();
            this.contract = App.request("contract:entity:new");
        });

        afterEach(function () {
            this.server.restore();
        });

        it("should have a default empty string CompanyID (mid)", function () {
            expect(this.contract.get('mid')).toBe("");
        });

        it("should have a default currencyID of 1", function () {
            expect(this.contract.get('currencyID')).toBe(1);
        });

        it("should have a default empty string contractTypeID", function () {
            expect(this.contract.get('contractTypeID')).toBe("");
        });

        it("should have a default empty string karmaID", function () {
            expect(this.contract.get('karmaID')).toBe("");
        });

        it("should have a default empty string budgetAmount", function () {
            expect(this.contract.get('budgetAmount')).toBe("");
        });

        it("should have a empty activeDate of today", function () {
            var today = new Date();
            expect(this.contract.get('activeDate')).toBe("");
        });

        it("should have a empty expirationDate", function () {
            //var today = new Date();
            //var lastDayOfYear = new Date(today.getFullYear(), 11, 31);
            //expect(this.contract.get('expirationDate')).toBe(moment(lastDayOfYear).format('YYYY-MM-DD'));
            expect(this.contract.get('expirationDate')).toBe("");
        });

        it("should have a default availableBudget of 0", function () {
            expect(this.contract.get('availableBudget')).toBe(0);
        });
        it("should have a default budgetSpent of 0", function () {
            expect(this.contract.get('budgetSpent')).toBe(0);
        });

        it("should have a default isExpired of false", function () {
            expect(this.contract.get('isExpired')).toBe(false);
        });

        /*
        describe("when no id is set", function () {
            it("should set the URL to the default URL", function () {
                expect(this.contract.url()).toEqual("api/contracts");
            });
        });

        describe("when id is set", function () {
            it("should return the URL to the model and id", function () {
                this.contract.campaignID = 1;
                console.log(JSON.stringify(this.campaign));
                expect(this.contract.url()).toEqual("api/contracts/1");
            });
        });
        */

        it("should not save when karmaID is empty", function () {
            var eventSpy = sinon.spy();
            this.contract.on("invalid", eventSpy);
            this.contract.save({ "karmaID": "" });
            expect(eventSpy).toHaveBeenCalledOnce();
            expect(eventSpy).toHaveBeenCalledWith(this.contract);
            expect(eventSpy.args[0][1]).toContain(jasmine.objectContaining({ message: 'A Karma ID is required.' }));
        });
    });

    describe("Contract Collection", function () {
        beforeEach(function () {
            this.fixture = this.fixtures.Contracts.valid;
            
            this.server = sinon.fakeServer.create();
            this.server.respondWith(
                "GET",
                "api/contracts/customers/1",
                [
                    200,
                    { "Content-Type": "application/json" },
                    JSON.stringify(this.fixture)
                ]
            );
            CommandCenter = {
                Server: {
                    BaseUrl: "/",
                adalconfig: {
                }
            }
        }
        });

        afterEach(function () {
            this.server.restore();
        });

        //it("should make the correct request", function () {
        //    this.contracts = App.request("contract:entities", 1);
        //    expect(this.server.requests.length).toEqual(1);
        //    expect(this.server.requests[0].method).toEqual("GET");
        //    expect(this.server.requests[0].url).toEqual("api/contracts/customers/1");
        //});

        it("should parse contracts from the response", function () {
            this.contracts = new App.Models.ContractCollection([], { customerId: 1 });
            this.contracts.fetch();
            this.server.respond();
            
            expect(this.contracts.length).toEqual(this.fixture.length);
            expect(this.contracts.get(9).get('karmaID')).toEqual(this.fixture[0].karmaID);
        });
    });
});