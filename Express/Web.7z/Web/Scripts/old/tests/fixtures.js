﻿beforeEach(function () {

    this.fixtures = {

        Contracts: {
            valid: [
                        {
                            "contractID": 9,
                            "karmaID": "x345JS534",
                            "contractTypeID": 2,
                            "currencyID": 1,
                            "activeDate": "2015-02-27T00:00:00",
                            "expirationDate": "2015-03-02T00:00:00",
                            "budgetAmount": 10000,
                            "budgetBilled": 500,
                            "mid": 10751
                        },
                        {
                            "contractID": 10,
                            "karmaID": "x123456",
                            "contractTypeID": 3,
                            "currencyID": 1,
                            "activeDate": "2015-03-17T00:00:00",
                            "expirationDate": "2015-03-20T00:00:00",
                            "budgetAmount": 20000,
                            "budgetBilled": 0,
                            "mid": 10751
                        },
                        {
                            "contractID": 19,
                            "karmaID": "x96574397",
                            "contractTypeID": 1,
                            "currencyID": 1,
                            "activeDate": "2015-03-02T00:00:00",
                            "expirationDate": "2015-04-02T00:00:00",
                            "budgetAmount": 200,
                            "budgetBilled": 175,
                            "mid": 10751
                        }
                    ]
                
            
        }

    };

});