﻿define(['app', 'numeral', 'underscore-string', 'routefilter'], function (CommandCenter) {
    CommandCenter.module("ReportsApp", function (ReportsApp, CommandCenter, Backbone, Marionette, $, _) {
        ReportsApp.startWithParent = false;

        ReportsApp.onStart = function () {
            // disbale the search box for now
            $("#search-box").prop("disabled", true);
        };

        ReportsApp.onStop = function () { }

        ReportsApp.routePermissionsMap = {
            "reports/:id/edit": {
                roles: ['3ddf5a27-7f09-4d5c-b594-db94b96c142e']
            }
        };

        ReportsApp.canAccess = function (route) {
            var retVal = true;

            if ((typeof window.CommandCenter.Server.adalconfig != 'undefined') && (window.CommandCenter.Server.adalconfig.active == "true")) {
                // ensure we have the users roles
                if ((typeof CommandCenter.loggedInUser === 'undefined') || (CommandCenter.loggedInUser.get("roles").length == 0)) {
                    CommandCenter.setUserRoles(CommandCenter.ReportsApp.canAccess, [route]);
                    return;
                }

                // ensure they have permission to the url
                if (_.has(CommandCenter.ReportsApp.routePermissionsMap, route)) {
                    var roles = CommandCenter.ReportsApp.routePermissionsMap[route].roles;

                    // check user roles
                    if (_.intersection(roles, CommandCenter.loggedInUser.get("roles")).length === 0) {
                        // no access, don't let them continue
                        retVal = false;
                    }
                }
            }

            return retVal;
        };
    });

    CommandCenter.module("Routers.ReportsApp", function (ReportAppRouter, CommandCenter, Backbone, Marionette, $, _) {
        ReportAppRouter.Router = Marionette.AppRouter.extend({
            appRoutes: {
                "customers/:id/reports": "viewReports"
            },
            before: function (route, params) {
                // return false to stop execution

             
                return CommandCenter.ReportsApp.canAccess(route);
            }
        });

        var executeAction = function (action, arg) {
            CommandCenter.startSubApp("ReportsApp");
            action(arg);
        };

        var API = {
            viewReports: function (id) {
                require(["apps/reports/list/list_controller"], function (ListController) {
                    executeAction(ListController.viewReports,id);
                });
            }
        };

        CommandCenter.on("reports:list", function (id) {
            CommandCenter.navigate("customers/" + id + "/reports");
            API.viewReports(id);
        });

       CommandCenter.addInitializer(function () {
            new ReportAppRouter.Router({
                controller: API
            });
        });
    }); 

    return CommandCenter.ReportAppRouter;
});