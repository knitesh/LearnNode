﻿define(['app',
        'tpl!apps/reports/list/templates/layout.html',
        'tpl!apps/reports/list/templates/typeMenu.html',
        'tpl!apps/reports/list/templates/reportForm.html',
         'moment',
         "backbone.syphon"
        ],
       function (CommandCenter, layoutTemplate, typeMenuTpl, reportFormTpl, moment) {
           CommandCenter.module("ReportsApp.List.View", function (View, CommandCenter, Backbone, Marionette, $, _) {
               View.Layout = Marionette.LayoutView.extend({
                   template: layoutTemplate,
                   tagName: "div",
                   className: "row",
                   regions: {
                       customerHeader: "#customerHeader",
                       reportRegion: "#reportsMain",
                       reportList: "#reportList",
                       reportForm: "#reportForm",
                       loadingRegion: "#loadingView .row > div"
                   },
                   onShow: function() {
                   }
               });

               View.TypeMenu = Marionette.ItemView.extend({
                   template: typeMenuTpl,
                   tagName: "ul",
                   className: "nav nav-justified customer-type-nav",
                   events: {
                       "click li": "filterCustomerList"
                   },
                   filterCustomerList: function (e) {
                       // set the active class on the nav item
                       $(".customer-type-nav li").removeClass("active");
                       $(e.target).addClass("active");

                       this.trigger("filter:customers", e);
                   }
               });

              
               View.ReportForm = Marionette.ItemView.extend({
                   template: reportFormTpl,
                   initialize: function () {
                       $(document).ready(function () {
                          
                           //$("#DataPointsRequested").chosen();
                           
                           
                           datapoints();


                       });

                      
                   },
                   templateHelpers: function (options) {
                       var that = this;
                       return {
                           providerid: (this.model.get('provider') !== '') ? this.model.get('provider') : this.options.customer
                       }

                   },
                   events: {
                       "mouseover .dateRange": "datepicker_datetimepicker",
                       "change .ReportType": "callDatapoints",
                       "submit form": "submitClicked"
                   },
                  
                   submitClicked: function(e) {
                     
                       e.preventDefault();
                       clearFormErrors();

                       var data = Backbone.Syphon.serialize(this);
                       this.trigger("form:submit", data);
                   },
                   datepicker_datetimepicker: function (ev) {
                    
                      
                       $('#datetimepicker6').datepicker({ autoclose: true, endDate: '-0d', clearBtn: true }).on("changeDate", function () {
                           if ($("#datetimepicker6").datepicker('getFormattedDate').length > 0) {
                               $('#datetimepicker7').datepicker('setStartDate', $('#datetimepicker6').datepicker('getFormattedDate'));
                           } else {
                               $('#datetimepicker7').datepicker('setStartDate',null);
                           }
                       });
                       $('#datetimepicker7').datepicker({ autoclose: true, endDate: '-0d', clearBtn: true }).on("changeDate", function () {
                           if ($("#datetimepicker7").datepicker('getFormattedDate').length > 0) {

                               $('#datetimepicker6').datepicker('setEndDate', $('#datetimepicker7').datepicker('getFormattedDate'));
                           } else {
                               $('#datetimepicker6').datepicker('setEndDate', '-0d');
                           }

                       });



                   },
                   callDatapoints: function (ev) {

                       //Could/Should be database driven

                       datapoints();


                       
                       


                   },

                   onFormDataInvalid: function (errors) {

                       var $view = this.$el;

                       if (errors && errors.ExceptionMessage) {
                           var errorStrUnhandled = 'Error: ' + errors.ExceptionMessage;
                           $(errorTxt).append(errorStrUnhandled).addClass("help-inline text-danger");
                           return;
                       }
                      
                       var markErrors = function (value, key) {
                           var $item = $view.find('input, select').filter(function () {
                               return $(this).attr('id').toLowerCase().indexOf(value.name.toLowerCase()) > -1;
                           });


                           var $formGroup = $item.parents('.form-group');

                           //var $formGroup = $view.find("#" + value.name).parents('.form-group');
                           var $errorEl = $("<span>", { class: "help-inline text-danger", text: value.message });
                           

                           $formGroup.append($errorEl).addClass("has-error");
                       }

                       var markSystemErrors = function (key, value) {
                           var errorStr = 'Error: ' + key.errormessage;

                           if (key.errormessage == 'Reached Threshold.') {
                               errorStr = ' Reached Threshold please adjust the selected date range';
                           }

                           if (key.errorcode == 'No Results') {
                               errorStr = key.errormessage;
                           }

                           
                            
                           $(errorTxt).append(errorStr).addClass("help-inline text-danger");
                       }

                       
                     
                       if (typeof errors[0].message != 'undefined') {
                           _.each(errors, markErrors);
                       }
                       else {
                           _.each(errors, markSystemErrors);
                       }                      
                   }
               });
            

               var clearFormErrors = function () {
                   //var $form = $view;
                   var $form = $("body");
                
                   $form.find(".help-inline.text-danger").each(function () {
                      
                       if ($(this).attr('id') == 'errorTxt') {
                           $(this).removeClass(".help-inline.text-danger").html('');
                       }
                       else {
                           $(this).remove();
                          
                       }



                   });
                   $form.find(".has-error").each(function () {
                      
                       $(this).removeClass("has-error");
                   });

                
                  
               }

               var datapoints = function () {

                   var theDataList = [];

                   $('#DataPointsRequested').html('');
                  

                   if ($("input[name='ReportType']:checked").val() == 1 || (!$("input[name='ReportType']:checked").val())) {



                       theDataList = [
                                        { optionId: '2', optionName: 'Job Title' },
                                        { optionId: '3', optionName: 'Job Ad Ref Code' },
                                        //{ optionId: '4', optionName: 'JobID' },
                                        { optionId: '5', optionName: 'Active Date' },
                                        { optionId: '6', optionName: 'Days Active' },
                                        //{ optionId: '8', optionName: 'Clicks' },
                                        { optionId: '8', optionName: 'Recommended CPC' },
                                        { optionId: '9', optionName: 'CPC, Spend' },
                                        { optionId: '10', optionName: 'Company' },
                                        { optionId: '11', optionName: 'Campaign (Campaign Name, Campaign ID, Campaign Budget, Days In Campaign)' },
                                        { optionId: '12', optionName: 'Location (City, State, LocationID)' },
                                        { optionId: '13', optionName: 'Occupation (soc3)' }];
                   }

                   else {
                       theDataList = [
                                       //{ optionId: '4', optionName: 'Job Pricing Type Name' },
                                       //{ optionId: '8', optionName: 'Clicks' },
                                       { optionId: '8', optionName: 'Recommended CPC' },
                                       { optionId: '9', optionName: 'CPC, Spend' },
                                       { optionId: '10', optionName: 'Company' },
                                       { optionId: '11', optionName: 'Campaign (Campaign Name, Campaign ID, Campaign Budget)' },
                                       { optionId: '12', optionName: 'Location (City, State, LocationID)' },
                                       { optionId: '13', optionName: ' Occupation (soc3)' }];
                   }


                   var options = $("#DataPointsRequested");



                   $.each(theDataList, function () {
                       options.append($("<option />").val(this.optionId).text(this.optionName));
                   });

                   //Adjust select box to match number of elements
                   $("#DataPointsRequested").attr("size", parseInt(theDataList.length));

               }



               View.Customers = Marionette.CollectionView.extend({
                   tagName: "div",
                   className: "col-xs-12",
                   childView: View.Customer,
                   emptyView: View.NoCustomers,
                   initialize: function () {
                       this.beginAlphabet = 0;
                   },
                   childViewOptions: function (model, index) {
                       // do some calculations based on the model
                       var writeOutAnchor = false;
                       if (this.beginAlphabet !== model.get('name').charAt(0)) {
                           writeOutAnchor = true;
                           this.beginAlphabet = model.get('name').charAt(0);
                       }

                       return {
                           writeOutAnchor: writeOutAnchor
                       }
                   },
                   emptyViewOptions: function (model, index) {
                       return {
                           writeOutAnchor: null
                       }
                   }
               });
           });

           return CommandCenter.ReportsApp.List.View;
       });