﻿define(['app', 'apps/customers/list/list_view'], function (CommandCenter, View) {
    CommandCenter.module("CustomersApp.List", function (List, CommandCenter, Backbone, Marionette, $, _) {
        List.Controller = {
            listCustomers: function (criterion) {
                
                require(['common/views', 'models/Customer'], function (CommonViews) {
                    // loading view goes here, when available
                    var loadingView = new CommonViews.Loading();
                    CommandCenter.contentRegion.show(loadingView);

                    var fetchingCustomers = CommandCenter.request("customer:entities");
                    var customersListLayout = new View.Layout();

                    if (CommandCenter.customerIndicatorRegion.hasView()) {
                        CommandCenter.customerIndicatorRegion.empty();
                    }

                    $.when(fetchingCustomers).done(function (customers) {                         
                        var alphabetMenuView = new View.AlphabetMenu({ collection: customers }),
                            customerTypeMenu = new View.TypeMenu(),
                            virtualCollection = new Backbone.VirtualCollection(customers),
                            customerListView = new View.Customers({ collection: virtualCollection });

                        customerTypeMenu.on("filter:customers", function (e) {
                            var hasCampaignAttr = $(e.target).attr("data-has-campaigns"),
                               isFeedEnabled = $(e.target).attr("data-feed-enabled"),
                               filterVal = (hasCampaignAttr === "true");

                            if (hasCampaignAttr !== "" && hasCampaignAttr !== undefined) {
                                // change the filter
                                customerListView.filter = function (child, index, collection) {
                                    return child.get('hasCampaigns') === filterVal && child.feedEnabled() === false;
                                };
                            } else if (isFeedEnabled !== "" && isFeedEnabled !== undefined) {
                                // change the filter
                                customerListView.filter = function (child, index, collection) {
                                    return child.feedEnabled() === (isFeedEnabled === "true");
                                };
                            } else {
                                // remove the filter
                                // note that using `delete cv.filter` will cause the prototype's filter to be used
                                // which may be undesirable
                                customerListView.filter = null;
                            }

                            customerListView.render();
                        });

                        customersListLayout.on("show", function () {
                            customersListLayout.typeMenu.show(customerTypeMenu);
                            customersListLayout.alphabet.show(alphabetMenuView);
                            customersListLayout.customers.show(customerListView);
                        });

                        $("#search-box").val('');
                        $("#search-box").on("keyup.customers", function (e) {
                            var term = $(e.target).val();
                            if (term.length >= 1) {
                                var regex = new RegExp(term, "i");
                                var ret = _.filter(customers.models, function (customer) {
                                    return regex.test(customer.get("name"));
                                });

                                virtualCollection.updateFilter(function (m) { return regex.test(m.get("name")); });
                            } else {
                                virtualCollection.updateFilter(function (m) { return m; });
                            }
                        });

                        $(document).on("click", ".search-items li a", function (e) {
                            e.preventDefault();
                            $(".search-items").addClass("hidden");
                            $("#search-box").val("");

                            var obj = $(this);
                            if (e.target !== this) {
                                obj = $(e.target).parent();
                            }

                            CommandCenter.trigger("campaigns:list", obj.attr("data-id"));
                        });

                        CommandCenter.contentRegion.show(customersListLayout);
                    });
 
                });
            }
        };
    });

    return CommandCenter.CustomersApp.List.Controller;
});