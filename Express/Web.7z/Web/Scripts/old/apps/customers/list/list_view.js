﻿define(['app',
        'tpl!apps/customers/list/templates/layout.html',
        'tpl!apps/customers/list/templates/list_item.html',
        'tpl!apps/customers/list/templates/typeMenu.html',
        'tpl!apps/customers/list/templates/noCustomers.html'],
       function (CommandCenter, layoutTemplate, listItemTemplate, typeMenuTpl, noCustomersTpl) {
    CommandCenter.module("CustomersApp.List.View", function (View, CommandCenter, backbone, Marionette, $, _) {
        View.Layout = Marionette.LayoutView.extend({
            template: layoutTemplate,
            tagName: "div",
            className: "row",

            regions: {
                customers: "#customers",
                alphabet: "#alphabetmenu",
                typeMenu: "#customerTypeMenu"
            }
        });

        View.TypeMenu = Marionette.ItemView.extend({
            template: typeMenuTpl,
            tagName: "ul",
            className: "nav nav-justified customer-type-nav",
            events: {
                "click li": "filterCustomerList"
            },
            filterCustomerList: function (e) {
                // set the active class on the nav item
                $(".customer-type-nav li").removeClass("active");
                $(e.target).addClass("active");

                this.trigger("filter:customers", e);
            }
        });

        View.AlphabetMenu = Marionette.ItemView.extend({
            template: false,
            tagName: "ul",
            className: "list-inline list-unstyled text-center",
            initialize: function () {
                // alphabet menu
                if (this.alphabetMenu === undefined) {
                    var alphabet = "0123456789abcdefghijklmnopqrstuvwxyz".split("");
                    var html = "";
                    var customers = this.collection;

                    _.each(alphabet, function (letter) {
                        var retVal = _.find(customers.models, function (customer) {
                            return customer.get('name').charAt(0).toLowerCase() === letter;
                        });

                        if (retVal !== undefined) {
                            html += '<li><a href="#' + letter + '">' + letter.toUpperCase() + '</a></li>';
                        } else {
                            html += '<li><span>' + letter.toUpperCase() + '</span></li>';
                        }
                    });
                    this.alphabetMenu = html;
                }
                this.$el.append(this.alphabetMenu);
                // end alphbet menu
            },
            events: {
                "click a": "anchorLinkClicked"
            },
            anchorLinkClicked: function (e) {
                e.preventDefault();
                var linkTo = $(e.target).attr('href').replace("#", "");
                var aTag = $("a[name='" + linkTo + "']");
                if (aTag.length > 0) {
                    $('html,body').animate({ scrollTop: aTag.offset().top }, 'fast');
                }
            }
        });

        View.Customer = Marionette.ItemView.extend({
            template: listItemTemplate,
            tagName: "div",
            className: "row",
            attributes: function() {
                return {
                    //"href": "#customers/"+this.model.get("id")+"/campaigns"
                };
            },
            initialize: function (options) {
                this.writeOutAnchor = options.writeOutAnchor;
            },
            templateHelpers: function () {
                return {
                    writeOutAnchor: this.writeOutAnchor
                };
            }
        });

        View.NoCustomers = Marionette.ItemView.extend({
            template: noCustomersTpl
        });

        View.Customers = Marionette.CollectionView.extend({
            tagName: "div",
            className: "col-xs-12",
            childView: View.Customer,
            emptyView: View.NoCustomers,
            initialize: function() {
                this.beginAlphabet = 0;
            },
            childViewOptions: function(model, index) {
                // do some calculations based on the model
                var writeOutAnchor = false;
                if(this.beginAlphabet !== model.get('name').charAt(0)) {
                    writeOutAnchor = true;
                    this.beginAlphabet = model.get('name').charAt(0);
                }

                return {
                    writeOutAnchor: writeOutAnchor
                }
            },
            emptyViewOptions: function (model, index) {
                return {
                    writeOutAnchor: null
                }
            }
        });
    });

    return CommandCenter.CustomersApp.List.View;
});