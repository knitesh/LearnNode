﻿define(['app',
        'tpl!apps/customers/edit/templates/layout.html',
        'tpl!apps/customers/edit/templates/form.html',
        "moment",
        'backbone.syphon'],
  function (CommandCenter, layoutTpl, formTpl,moment) {
    CommandCenter.module("CustomersApp.Edit.View", function (View, CommandCenter, backbone, Marionette, $, _) {
        View.Layout = Marionette.LayoutView.extend({
            template: layoutTpl,
            tagName: "div",
            className: "row",
            regions: {
                editCustomerRegion: "#editCustomer"
            },
            onShow: function () {
            
        }
        });

        View.FormView = Marionette.ItemView.extend({
            template: formTpl,
            templateHelpers: function () {
                return {
                    customerId: this.model.get("id")
                }
            },

            events: {
                "submit form": "submitClicked",
                "keyup #ProviderFutureCap": "checkForMaxLimit"
            },

            submitClicked: function (e) {
                e.preventDefault();
                var data = Backbone.Syphon.serialize(this);
                data.Replay = this.model.directclickenabled === data.DirectClickEnabled ? false : true;
                data.FutureCapChanged = this.model.toJSON().ProviderFutureCap === data.ProviderFutureCap ? false : true;
                this.trigger("form:submit", data);
            },
            checkForMaxLimit: function (e) {
                e.preventDefault();
                if (numeral($("#ProviderFutureCap").val()) > 1000000) {
                    $("#ProviderFutureCapLimit").show();
                } else {
                    $("#ProviderFutureCapLimit").hide();
                }

            }
        });
    });

    return CommandCenter.CustomersApp.Edit.View;
});