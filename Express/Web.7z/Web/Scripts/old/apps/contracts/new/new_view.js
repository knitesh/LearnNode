﻿define(["app", "apps/contracts/common/views"], function (CommandCenter, CommonViews) {
    CommandCenter.module("ContractsApp.New.View", function (View, CommandCenter, Backbone, Marionette, $, _) {
        View.Contract = CommonViews.Form.extend({
            title: "New Contract",

            onRender: function () {
                this.$el.find("button[type='submit']").text("Create Contract");
                this.$el.find("#deleteContract").text("Cancel");
                this.$el.find("#btnDeleteContract").text("Continue");
                this.$el.find(".modal-body > p").text(" You are about to cancel this contract.");
                this.$el.find(".network-credit").hide();
            }
        });
    });

    return CommandCenter.ContractsApp.New.View;
});