﻿define(['app',
        'numeral',
        'underscore-string',
        'routefilter'],
        function (CommandCenter) {
        CommandCenter.module("ContractsApp", function (ContractsApp, CommandCenter, Backbone, Marionette, $, _) {
            ContractsApp.startWithParent = false;

            ContractsApp.onStart = function () {
                // disbale the search box for now
                $("#search-box").prop("disabled", true);
            };

            ContractsApp.onStop = function () { }

            ContractsApp.routePermissionsMap = {
                "campaigns/:id/edit": {
                    roles: ['3ddf5a27-7f09-4d5c-b594-db94b96c142e']
                }
            };

            ContractsApp.canAccess = function (route) {
                var retVal = true;

                if ((typeof window.CommandCenter.Server.adalconfig != 'undefined') && (window.CommandCenter.Server.adalconfig.active == "true")) {
                    // ensure we have the users roles
                    if ((typeof CommandCenter.loggedInUser === 'undefined') || (CommandCenter.loggedInUser.get("roles").length == 0)) {
                        CommandCenter.setUserRoles(CommandCenter.ContractsApp.canAccess, [route]);
                        return;
                    }

                    // ensure they have permission to the url
                    if (_.has(CommandCenter.ContractsApp.routePermissionsMap, route)) {
                        var roles = CommandCenter.ContractsApp.routePermissionsMap[route].roles;

                        // check user roles
                        if (_.intersection(roles, CommandCenter.loggedInUser.get("roles")).length === 0) {
                            // no access, don't let them continue
                            retVal = false;
                        }
                    }
                }
                return retVal;
            };
        });

        CommandCenter.module("Routers.ContractsApp", function (ContractAppRouter, CommandCenter, Backbone, Marionette, $, _) {
            ContractAppRouter.Router = Marionette.AppRouter.extend({
                appRoutes: {
                    "customers/:id/contracts": "listContracts"
                },
                before: function (route, params) {
                    // return false to stop execution
                    return CommandCenter.ContractsApp.canAccess(route);
                }
            });

            var executeAction = function (action, arg) {
                CommandCenter.startSubApp("ContractsApp");
                action(arg);
            };

            var API = {
                listContracts: function (id) {
                    require(["apps/contracts/list/list_controller"], function (ListController) {
                        executeAction(ListController.listContracts, id);
                    });
                }
            };

            CommandCenter.on("contracts:list", function (id) {
                CommandCenter.navigate("customers/" + id + "/contracts");
                API.listContracts(id);
            });

            CommandCenter.addInitializer(function () {
                new ContractAppRouter.Router({
                    controller: API
                });
            });
        });

        return CommandCenter.ContractAppRouter;
    });