﻿define(["app", "moment", "tpl!apps/contracts/common/templates/form.html", "backbone.syphon"],
    function(CommandCenter, moment, formTpl) {
        CommandCenter.module("ContractsApp.Common.Views", function(Views, CommandCenter, Backbone, Marionette, $, _) {
            Views.Form = Marionette.ItemView.extend({
                template: formTpl,

                templateHelpers: function() {
                    var that = this;
                    return {
                        mid: (this.model.get('mid') !== '') ? this.model.get('mid') : this.options.customer,
                        providerid: (this.model.get('providerid') !== '') ? this.model.get('providerid') : this.options.customer,
                        activeDate: moment(this.model.get('activeDate')).format("MM/DD/YYYY") !== "Invalid date" ? moment(this.model.get('activeDate')).format("MM/DD/YYYY") : "",
                        expirationDate: moment(this.model.get('expirationDate')).format("MM/DD/YYYY") !== "Invalid date" ? moment(this.model.get('expirationDate')).format("MM/DD/YYYY") : "",
                        canDelete: (this.model.get('budgetSpent') <= 0),
                        selectedContractType: function(val) {
                            if (that.model.get('contractTypeID') == val) {
                                return 'selected';
                            } else {
                                return "";
                            }
                        },
                        budgetAmt: numeral(this.model.get('budgetAmount')).format('0,0.00'),
                        nwtworkCreditStartDate: moment(this.model.get('activeDate')) > moment.utc()
                                                ? moment(this.model.get('activeDate')).format("MM/DD/YYYY")
                                                : moment({}).format("MM/DD/YYYY"),
                        listOfNetworkCredit: _.sortBy(this.model.get("networkCredit"), 'ActiveDate').reverse(),
                        parseDate: function (date) { return moment(date).format("MM/DD/YYYY") }
                    }
                },

                events: {
                    //"click button.js-submit": "submitClicked"
                    "submit form": "submitClicked",
                    "click #deleteContract": "deleteContract",
                    "mouseover .contractDate > .dateRange ": "contractStartEndDateHandler",
                    "mouseover .addNetworkCreditDate > .dateRange ": "networkCreditStartEndDateHandler",
                    "click #btnAddNewNetWorkCredit": "displayNetworkCreditAddForm",
                    "click #showNetworkCredit" : "displayListOfNetWorkCredit"
                },

                submitClicked: function(e) {
                    e.preventDefault();
                    var data = Backbone.Syphon.serialize(this);
                    //Make Network Credit Object and Attached it to Data if any
                    if (data.credit) {
                        data.newNetworkCredit=[{
                            credit: data.credit,
                            ActiveDate: data.creditStartDate,
                            ExpirationDate: data.creditEndDate,
                            Reason: data.creditReason
                        }];
                    }
                    this.trigger("form:submit", data);
                },
                displayNetworkCreditAddForm: function(e) {
                    e.preventDefault();
                    $('#btnAddNewNetWorkCredit > i').toggleClass("fa-plus fa-minus");
                    $('#addNewNetWorkCreditForm').toggle();
                },
                displayListOfNetWorkCredit: function (e) {
                    e.preventDefault();
                    $('#showNetworkCredit > i').toggleClass("fa-caret-right fa-caret-down");
                    $('#panelNetworkCredit').toggle();
                },
                deleteContract: function(e) {
                    e.preventDefault();
                    var data = Backbone.Syphon.serialize(this);
                    var self = this;
                    $('#btnDeleteContract').on('click', function() {
                        $('#deleteContractModal').modal('toggle');
                        self.remove();
                        self.trigger("Contract:delete", data);
                    });

                    $('#deleteContractModal').modal('toggle');
                },
                contractStartEndDateHandler: function (e) {
                    e.preventDefault();
                    $('#activeDatePicker').datepicker({ autoclose: true, clearBtn: true })
                        .on("changeDate", function () {
                            if ($("#activeDatePicker").datepicker('getFormattedDate').length > 0 && moment($("#activeDatePicker").datepicker('getFormattedDate'))>moment() ) {
                                $('#expirationDatePicker')
                                    .datepicker('setStartDate', $('#activeDatePicker').datepicker('getFormattedDate'));
                                $("#ncStartDate").val($('#activeDate').val());
                            } else {
                                $('#expirationDatePicker').datepicker('setStartDate', '-0d');
                                $("#ncStartDate").val(moment({}).format("MM/DD/YYYY"));
                            }
                        });
                    $('#expirationDatePicker').datepicker({ autoclose: true, startDate: moment.utc().toString(), clearBtn: true })
                        .on("changeDate", function() {
                            $('#activeDatePicker').datepicker('setEndDate', $('#expirationDatePicker').datepicker('getFormattedDate'));
                            $("#ncEndDate").val($('#expirationDate').val());
                            $('#creditEndDatePicker')
                                    .datepicker('setStartDate', $('#expirationDatePicker').datepicker('getFormattedDate'));
                        });

                },
                networkCreditStartEndDateHandler: function (e) {
                    e.preventDefault();
                    $('#creditEndDatePicker').datepicker({ autoclose: true, clearBtn: true, startDate: moment(this.model.get('expirationDate')).format("MM/DD/YYYY") });

                },
                onFormDataInvalid: function (errors) {
                    
                    var $view = this.$el;

                    var clearFormErrors = function() {
                        var $form = $view.find("form");
                        $form.find(".help-inline.text-danger").each(function() {
                            $(this).remove();
                        });
                        $form.find(".form-group.has-error").each(function() {
                            $(this).removeClass("has-error");
                        });
                    }

                    var markErrors = function (value, key) {
                        var $formGroup, $errorEl, $item;
                        if (value.name !== undefined) {
                            $item = $view.find('input, select')
                                .filter(function() {
                                    return $(this).attr('id').toLowerCase().indexOf(value.name.toLowerCase()) > -1;
                                });
                            $formGroup = $item.parents('.form-group');
                            //var $formGroup = $view.find("#" + value.name).parents('.form-group');
                            $errorEl = $("<span>", { class: "help-inline text-danger", text: value.message });
                            $formGroup.append($errorEl).addClass("has-error");
                        } else {
                            if (key === "ExceptionMessage" || key === "Message") {
                                if (value.indexOf("External Contract Ref") > 0) {
                                    $item = $view.find('input, select')
                                        .filter(function() {
                                            return $(this).attr('id').toLowerCase().indexOf("karmaid") > -1;
                                        });
                                    $formGroup = $item.parents('.form-group');
                                    $errorEl = $("<span>", {
                                        class: "help-inline text-danger",
                                        text: "Contract with similar Karma Id already exists"
                                    });
                                    $formGroup.append($errorEl).addClass("has-error");
                                } else {
                                    $item = $view.find('.server-error');
                                    $formGroup = $item.parents('form');
                                    $errorEl = $("<span>", { class: "help-inline text-danger", text: value });
                                    $formGroup.append($errorEl);
                                }

                            }
                        }
                    }

                    clearFormErrors();
                    _.each(errors, markErrors);

                }
            });
        });

        return CommandCenter.ContractsApp.Common.Views;
    });
