﻿define(["app", "apps/contracts/common/views"], function (CommandCenter, CommonViews) {
    CommandCenter.module("ContractsApp.Edit.View", function (View, CommandCenter, Backbone, Marionette, $, _) {
        View.Contract = CommonViews.Form.extend({
            initialize: function () {
                //this.title = "Edit " + this.model.get("firstName") + " " + this.model.get("lastName");
                this.title = "Edit";
            },

            onRender: function () {
                if (this.options.generateTitle) {
                    var $title = $("<h1>", { text: this.title });
                    this.$el.prepend($title);
                }

                if (this.model.get("isExpired") && (this.model.get("availableBudget") <=0)) {
                    this.$el.find("#karmaID, #contractTypeID,#budgetAmount,#expirationDate,#activeDate").prop('disabled', true);
                } else {
                    this.$el.find("#karmaID").prop('readonly', true);
                    this.$el.find("#contractTypeID").prop('disabled', true);
                }

                this.$el.find("#btnCreateContract").text("Update Contract");
                this.$el.find(".network-credit").show();
            }
        });
        });

    return CommandCenter.ContractsApp.Edit.View;
});