﻿define(["app", "apps/contracts/list/list_view", "moment", "toastr"], function (CommandCenter, View, moment, toastr) {
    CommandCenter.module("ContractsApp.List", function (List, CommandCenter, Backbone, Marionette, $, _) {
        List.Controller = {
            listContracts: function (id) {

                require(['common/views', 'models/Customer', 'models/Contract', 'backbone.fetch-cache', 'datepicker'], function (CommonViews, customerModel) {
                    var fetchingCustomer = CommandCenter.request("customer:entity", id);
                    var fetchingContracts = CommandCenter.request("contract:entities", id);

                    toastr.options = {
                        "closeButton": true,
                        "newestOnTop": true,
                        "positionClass": "toast-bottom-left",
                        "preventDuplicates": true
                    }

                    // loading data view
                    var loadingView = new CommonViews.Loading();
                    var contractLayout = new View.Layout();
                    var campaignView,customerBudgetInfo,customerInfo;

                    CommandCenter.contentRegion.show(contractLayout);
                    contractLayout.loadingRegion.show(loadingView);

                    // customer information
                    $.when(fetchingCustomer).done(function (customer) {
                        if (customer !== undefined) {
                            var cI = new CommonViews.CustomerIndicator({ model: customer });
                            CommandCenter.customerIndicatorRegion.show(cI);

                            customerInfo = new CommonViews.CustomerInfo({ model: customer, headerText: "Contracts" });
                            contractLayout.customerHeader.show(customerInfo);

                            //show customer Budget Info
                            customerBudgetInfo = new CommonViews.CustomerBudgetInfo({ model: customer });
                            contractLayout.customerBudgetInfo.show(customerBudgetInfo);

                            // show the customer sidebar menu
                            var customerSidebar = new CommonViews.CustomerSidebarMenu({ model: customer });
                            customerSidebar.render();

                            
                            $.when(fetchingContracts).done(function (contracts) {
                               
                                // remove the loading view
                                contractLayout.loadingRegion.empty();

                                var contractListView = new View.List({ collection: contracts });
                                contractLayout.contractsListRegion.show(contractListView);

                                // new contract
                                contractListView.on("contract:new", function () {
                                    require(["apps/contracts/new/new_view"], function (NewView) {

                                        $(".contracts .contract-selected").removeClass("contract-selected");
                                        var newContract = CommandCenter.request("contract:entity:new");

                                        var view = new NewView.Contract({
                                            model: newContract,
                                            customer: id
                                        });

                                        contractLayout.contractsDetailRegion.show(view);

                                        var options = {
                                            success: function (model, response, options) {
                                                toastr.success('New contract created successfully');
                                                $("#btnCreateContract-spinner").hide();
                                                var today = new Date();
                                                newContract.set("isExpired", (moment(newContract.get("expirationDate")).unix() < moment(today).unix()) ? true : false);

                                                contracts.add(newContract);
                                                contractLayout.contractsDetailRegion.reset();
                                                customer.fetch();
                                                // need to clear the backbone cache
                                                Backbone.fetchCache.clearItem("api/customers/" + id + "/contracts");
                                                
                                            },
                                            error: function (model, response, options) {
                                                toastr.warning('An error occurred while creating new Contract.');
                                                $("#btnCreateContract-spinner").hide();
                                                // requires errors response from the server to get here
                                                view.triggerMethod("form:data:invalid", response.responseJSON);
                                                
                                            }
                                        };

                                        view.on("form:submit", function (data) {
                                            $("#btnCreateContract-spinner").show();
                                            if (!newContract.save(data, options)) {
                                                toastr.warning('A data validation error occurred while creating new Contract.');
                                                $("#btnCreateContract-spinner").hide();
                                                view.triggerMethod("form:data:invalid", newContract.validationError);
                                            }
                                        });
                                    });
                                });
                                // edit/Delete contract
                                contractListView.on("childview:contract:edit", function (childview, args) {
                                    require(["apps/contracts/edit/edit_view"], function (EditView) {

                                        childview.trigger("Highlight");
                                        var model = args.model;
                                        var view = new EditView.Contract({
                                            model: model
                                        });

                                        var submitHandlerOptions = {
                                            success: function (model, response, options) {
                                                toastr.success('Contract updated successfully.');
                                                model.fetch();
                                                var today = new Date();
                                                model.set("isExpired", (moment(model.get("expirationDate")).unix() < moment(today).unix()) ? true : false);

                                                // close up the view
                                                contractLayout.contractsDetailRegion.empty();

                                                //remove selected class
                                                $(".contracts .contract-selected").removeClass("contract-selected");

                                                customer.fetch();
                                                // need to clear the backbone cache
                                                Backbone.fetchCache.clearItem("api/customers/" + id + "/contracts");
                                                $("#btnCreateContract-spinner").hide();

                                            },
                                            error: function (model, response, options) {
                                                // requires errors response from the server to get here
                                                toastr.warning('An error occured while updating Contract.');
                                                model.fetch();
                                                view.triggerMethod("form:data:invalid", response.responseJSON);
                                                $("#btnCreateContract-spinner").hide();
                                            }
                                        };

                                        view.on("form:submit", function (data) {
                                            $("#btnCreateContract-spinner").show();
                                            if (!model.save(data, submitHandlerOptions)) {
                                                toastr.warning('Validation error occurred while updating Contract.');
                                                $("#btnCreateContract-spinner").hide();
                                                view.triggerMethod("form:data:invalid", model.validationError);
                                            } 
                                        });
                                        view.on("Contract:delete", function (data) {
                                            this.model.destroy({
                                                dataType: "text",
                                                success: function (model, response) {
                                                    // close up the view
                                                    contractLayout.contractsDetailRegion.empty();
                                                    customer.fetch();
                                                },
                                                error: function (errdata, response) {
                                                    console.log(response);
                                                }
                                            });
                                        });

                                        contractLayout.contractsDetailRegion.show(view);
                                    });
                                });
                            });


                        }
                    });
                });
            }
        }
    });

    return CommandCenter.ContractsApp.List.Controller;
});