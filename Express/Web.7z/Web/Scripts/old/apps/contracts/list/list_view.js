﻿define(["app",
        "tpl!apps/contracts/list/templates/layout.html",
        "tpl!apps/contracts/list/templates/list.html",
        "tpl!apps/contracts/list/templates/listItem.html",
        "tpl!apps/contracts/list/templates/empty.html",
        "moment"],
  function (CommandCenter, layoutTemplate, listTpl, listItemTpl, emptyTpl, moment) {
    CommandCenter.module("ContractsApp.List.View", function (View, CommandCenter, Backbone, Marionette, $, _) {
        View.Layout = Marionette.LayoutView.extend({
            template: layoutTemplate,
            tagName: "div",
            className: "row",
            regions: {
                customerHeader: "#customerHeader",
                contractRegion: "#contractsMain",
                contractsListRegion: "#contractsList",
                contractsDetailRegion: "#contractDetails",
                loadingRegion: "#loadingView .row > div",
                customerBudgetInfo: "#customerBudgetInfo"
            }
        });

        View.Empty = Marionette.ItemView.extend({
            template: emptyTpl
        });

        View.ListItem = Marionette.ItemView.extend({
            template: listItemTpl,
            tagName: "a",
            className: "list-group-item clearfix",
            attributes: {
                "href": "#"
            },
            initialize: function() {
                this.listenTo(this.model, "change", this.render);
                this.on('Highlight', this.fnHighlightItem, this);
            },
            templateHelpers: function () {
                return {
                    contractType: function () {
                        if (this.contractTypeID === 2) {
                            return "<span class=\"label label-warning\">Converted</span>";
                        } else if (this.contractTypeID === 3) {
                            return "<span class=\"label label-danger\">Beta</span>";
                        }
                    },
                    isExpired: function () {
                        return (moment(this.actualExpirationDate).isBefore(moment(), 'day')) ? true : false;
                    },
                    formattedStartDate: moment(this.model.get('activeDate')).format('MM/DD/YYYY'),
                    formattedExpirationDate: moment(this.model.get('expirationDate')).format('MM/DD/YYYY'),
                    budgetAmtPerContract: numeral(this.model.get('budgetAmount')).format('$0,0.00'),
                    budgetRemainingPerContract: function () {
                        if (this.availableBudget === undefined) {
                            return numeral(this.budgetAmount).format('$0,0.00');
                        } else {
                            return numeral(this.availableBudget).format('$0,0.00');
                        }
                    },
                    totalNetworkCreditPerContract: function() {
                        var totalCredit = 0.00;
                        _.each(this.networkCredit,
                            function(item) {
                                totalCredit += item.credit;
                            });
                        return numeral(totalCredit).format('$0,0.00');
                    }
                }
            },
            triggers: function () {
                var actions = { "click": "doNothing" };

                if(CommandCenter.roleForActivity("edit contract")) {
                    actions = {
                        "click": "contract:edit"
                    };
                }
                return actions;
            },
            fnHighlightItem: function (e) {
                this.$el.parent().children().removeClass("contract-selected");
                this.$el.addClass("contract-selected");
            },
            doNothing: function (e) {
                e.preventDefault();
            }
        });

        View.List = Marionette.CompositeView.extend({
            template: listTpl,

            childView: View.ListItem,
            childViewContainer: ".list-group",

            emptyView: View.Empty,

            triggers: function () {
                var actions = { "click": "doNothing" };

                if(CommandCenter.roleForActivity("create contract")) {
                    actions = {
                        "click button.js-new": "contract:new",
                        "click a.new-contract": "contract:new" 
                    };
                }

                return actions;
            },

            doNothing: function (e) {
                e.preventDefault();
            }
        });
    });

    return CommandCenter.ContractsApp.List.View;
});