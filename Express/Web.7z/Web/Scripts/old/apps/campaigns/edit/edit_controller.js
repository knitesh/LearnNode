define(["app", "apps/campaigns/edit/edit_view", "selectize", "moment"], function (CommandCenter, View, selectize, moment) {
    CommandCenter.module("CampaignsApp.Edit", function (Edit, CommandCenter, Backbone, Marionette, $, _) {
        Edit.Controller = {
            editCampaign: function (id) {
                require(['common/views', 'models/Campaign', 'models/Customer', 'datepicker', 'chosen'], function (CommonViews) {
                    var fetchingCampaign = CommandCenter.request("campaign:entity", id);

                    // loading data view
                    var customerCampaign,
                        loadingView = new CommonViews.Loading(),
                        campaignLayout = new View.Layout(),
                        formView,
                        locView,
                        socView,
                        moreJobsLayout = new View.ALaCarteMoreJobsLayout();

                    CommandCenter.contentRegion.show(campaignLayout);
                    campaignLayout.formRegion.show(loadingView);

                    $.when(fetchingCampaign).done(function (campaign) {
                        customerCampaign = campaign;
                        formView = new View.Form({ model: campaign });
                        campaignLayout.header.show(new View.Header({ model: campaign }));

                        // show the edit campaign form here
                        campaignLayout.formRegion.show(formView);

                        // if a la carte campaign, show job currently in campaign
                        if (!campaign.get("isdynamic")) {
                            //campaignLayout.alacarteRegion.show(moreJobsLayout);
                            // get the jobs
                            var fetchingJobs = campaign.get('jobs').fetch({ cache: false });
                            $.when(fetchingJobs).done(function (jobs) {
                                var jobView = new View.CampaignedJobs({ collection: campaign.jobs(), isCampaignFeedEnabled: campaign.get('iscampaignfeedenabled') });
                                campaignLayout.campaignedJobsRegion.show(jobView);
                            });
                        }

                        formView.on("select:job", function (args) {
                            // is job already in campaign? if so, just update it
                            var m = campaign.jobs().get(args.model);
                            if (m === undefined) {
                                campaign.jobs().add(args.model);
                            } else {
                                m.set("selectedForCampaign", true);
                            }
                        });

                        formView.on("unselect:job", function (args) {
                            campaign.jobs().remove(args.model);
                        });
                        
                        formView.on("form:submit", function (data) {

                            var noweditCampaign = new Date()
                            var startDateToday = new Date(noweditCampaign.getTime() + noweditCampaign.getTimezoneOffset() * 60000),
                                startDateInCamp = new Date(data.startdate);
                            startDateToday = new Date(startDateToday.getFullYear(), startDateToday.getMonth(), startDateToday.getDate());
                            if (startDateInCamp) {
                                var startDateInCampaign = new Date(startDateInCamp.getFullYear(), startDateInCamp.getMonth(), startDateInCamp.getDate());
                            }
                            var campaignStatus = campaign.get('status');
                            var isActivateCampaign = (data && data.campaignstatusid === "1");
                            var isValidationError = false;
                            var cId = data.customer;
                            // compile the list of jobids
                            var jobs = _.filter(campaign.jobs().models, function (item) { return (item.get('isactiveincampaign') || item.get('selectedForCampaign')); });
                            if (jobs.length > 0) {
                                data.jobids = _.pluck(jobs, "id");
                            }

                            // hide the form errors
                            this.$('.form-group').removeClass('has-error');
                            var me = this;
                            var options = {
                                success: function (model, response, options) {
                                    // clear the campaigns from cache
                                    //Backbone.fetchCache.clearItem("api/customers/" + cId + "/campaigns/1");
                                    //Backbone.fetchCache.clearItem("api/customers/" + cId + "/campaigns/2");
                                    //Backbone.fetchCache.clearItem("api/customers/" + cId + "/campaigns/3");
                                    Backbone.fetchCache.clearItem("api/customers/" + cId);
                                    CommandCenter.trigger("campaigns:list", cId);
                                },
                                error: function (model, response, options) {
                                    // requires errors response from the server to get here
                                    $('.btn-save').removeClass('disabled');
                                    $('.form-errors').show();
                                    var serverErrors = response.responseJSON;
                                    var errorMessages = serverErrors.ExceptionMessage;
                                    if (!errorMessages) {
                                        errorMessages = (!serverErrors.Message) ? "An Error has occured on the Server" : serverErrors.Message;
                                    }
                                    campaignLayout.errorRegion.show(new CommonViews.FormErrors({ errors: [{ name: "", message: errorMessages }] }));
                                }
                            };

                            // client-side validation
                            Backbone.listenTo(campaign, 'invalid', function (model, errors, options) {
                                _.each(errors, function (error) {
                                    isValidationError = true;
                                    var controlGroup = $('[name="' + error.name + '"]').parent();
                                    controlGroup.addClass('has-error');
                                }, this);

                                $('.btn-save').removeClass('disabled');
                                isValidationError = true;
                                campaignLayout.errorRegion.show(new CommonViews.FormErrors({ errors: errors }));
                            });

                            if (isValidationError === false && startDateToday && startDateInCampaign && (campaignStatus && campaignStatus.toLowerCase() === 'pending') && isActivateCampaign) {
                                if ((startDateToday.getTime() !== startDateInCampaign.getTime()) && (!data.startDtOverride)) {
                                    data.isEdit = true;
                                    var campaignJobs = campaign.get('jobs');
                                    data.jobs = campaignJobs;
                                    var validationErrors = campaign.validate(data, options);
                                    if (!validationErrors) {
                                        $('#startDateModal').modal('show');
                                        return;
                                    }
                                }
                            }
                            if (data.startDtOverride) {
                                data.startdate = moment().utc().format('MM/DD/YYYY');
                            }
                            data.isEdit = true;
                            campaign.save(data, options);
                        });

                        // get the customer information
                        var customerId = campaign.get('customerId');
                        var fetchingCustomer = CommandCenter.request("customer:entity", customerId);
                        $.when(fetchingCustomer).done(function (customer) {

                            //show customer Budget Info
                           var customerBudgetInfo = new CommonViews.CustomerBudgetInfo({ model: customer });
                           campaignLayout.customerBudgetInfo.show(customerBudgetInfo);
                            // show the customer sidebar menu
                            var customerSidebar = new CommonViews.CustomerSidebarMenu({ model: customer });
                            customerSidebar.render();
                            
                            // is the campaign an A La Carte Campaign?
                            if (!customerCampaign.get("isdynamic")) {
                                var locView,
                                    socView,
                                    fetchingLocations = customer.get('locations').fetch({ cache: true }),
                                    fetchingOccupations;

                                campaignLayout.alacarteRegion.show(moreJobsLayout);

                                var chained = $.when(fetchingLocations).then(function (locs) {
                                    locView = new CommonViews.Locations({ collection: locs, customerId: customer.id, isCampaignFeedEnabled: campaign.get('iscampaignfeedenabled') });

                                    locView.on("show:jobs", function (args) {
                                        args.campaignId = customerCampaign.id;
                                        args.selectedJobs = campaign.jobs();
                                        CommandCenter.CampaignsApp.Edit.Controller.showJobs(moreJobsLayout, args);
                                    });

                                    moreJobsLayout.locs.show(locView);
                                    return customer.get('occupations').fetch({ cache: true });
                                });

                                chained.done(function (socs) {
                                    socView = new CommonViews.Occupations({ collection: socs, customerId: customer.id, isCampaignFeedEnabled: campaign.get('iscampaignfeedenabled') });

                                    socView.on("show:jobs", function (args) {
                                        args.campaignId = customerCampaign.id;
                                        args.selectedJobs = campaign.jobs();
                                        CommandCenter.CampaignsApp.Edit.Controller.showJobs(moreJobsLayout, args);
                                    });

                                    moreJobsLayout.socs.show(socView);

                                    $('select').selectize({
                                        create: false,
                                        valueField: 'id',
                                        labelField: 'name',
                                        sortField: {
                                            field: 'name',
                                            direction: 'asc'
                                        },
                                        dropdownParent: 'body',
                                        searchField: 'name'
                                    });
                                });

                            }
                        });
                    });

                });
            },

            showJobs: function (layout, args) {
                require(['common/views', 'models/Job'], function (CommonViews) {
                    // loading data view
                    var loadingView = new CommonViews.Loading({
                        title: "Loading Job Data",
                        message: "Please wait while the job data is loading."
                    });
                    layout.jobsRegion.show(loadingView);

                    var fetchingJobs = CommandCenter.request("job:entities", args.customer, args.location, args.occupation);
                    $.when(fetchingJobs).done(function (jobs) {
                        // see if the user has already put the job in the campaign
                        if (args.selectedJobs.length > 0) {
                            // user has selected jobs to be campaigned
                            var jArr = _.filter(args.selectedJobs.models, function (j) {
                                return (j.get("selectedForCampaign") || j.get("isactiveincampaign"));
                            });
                            var selected = _.pluck(jArr, 'id');
                            var available = _.pluck(jobs.models, 'id');
                            var alreadySelected = _.intersection(selected, available);
                            _.each(alreadySelected, function (jId) {
                                jobs.findWhere({ id: jId }).set("selectedForCampaign", true);
                            });
                        }

                        var jobsView = new View.Jobs({ collection: jobs, customerId: args.customer, campaignId: args.campaignId });
                        layout.jobsRegion.show(jobsView);

                        layout.on("uncampaign:job", function (args) {
                            jobs.get(args.model).set("selectedForCampaign", false);
                            //campaign.jobs().remove(args.model);
                        });

                        $("table").tablesorter({ debug: false });
                    });
                });
            }

        };
    });

    return CommandCenter.CampaignsApp.Edit.Controller;
});