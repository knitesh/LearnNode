define(["app",
        "tpl!apps/campaigns/edit/templates/layout.html",
        "tpl!apps/campaigns/edit/templates/header.html",
        "tpl!apps/campaigns/edit/templates/form.html",
        "tpl!apps/campaigns/edit/templates/campaignedJob.html",
        "tpl!apps/campaigns/edit/templates/campaignedJobs.html",
        "tpl!apps/campaigns/edit/templates/job.html",
        "tpl!apps/campaigns/edit/templates/jobs.html",
        "tpl!apps/campaigns/edit/templates/alacarte.html",
        "tpl!apps/campaigns/edit/templates/promptMessage.html",
        "moment",
        "lib/jquery.tablesorter",
        "backbone.syphon",
        "underscore-string"],
  function (CommandCenter, layoutTemplate, headerTemplate, formTemplate, campaignedJobTmpl, campaignedJobsTmpl, jobTmpl, jobsTmpl, alacarteTmpl, promptMessageTpl, moment) {
    CommandCenter.module("CampaignsApp.Edit.View", function (View, CommandCenter, Backbone, Marionette, $, _) {
        View.Layout = Marionette.LayoutView.extend({
            template: layoutTemplate,
            tagName: "div",
            className: "row",
            regions: {
                //contentArea: "#edit_campaign",
                header: "#edit_header",
                formRegion: ".form-region",
                errorRegion: ".form-errors",
                campaignedJobsRegion: "#campaignedJobs > div",
                alacarteRegion: "#additionalJobs",
                customerBudgetInfo: "#customerBudgetInfo"
            },
            childEvents: {
                'selected:job': function (childView, job) {
                    this.getRegion('formRegion').currentView.trigger('select:job', job);
                },
                'unselected:job': function (childView, job) {
                    this.getRegion('formRegion').currentView.trigger('unselect:job', job);
                    this.getRegion('alacarteRegion').currentView.trigger('uncampaign:job', job);
                }
            }
        });

        View.ALaCarteMoreJobsLayout = Marionette.LayoutView.extend({
            template: alacarteTmpl,
            tagName: "div",
            className: "row",
            regions: {
                locs: "#cLocations",
                socs: "#cOccupations",
                jobsRegion: ".job-list"
            },
            childEvents: {
                'selected:job': function (childView, job) {
                    this.triggerMethod('selected:job', job);
                },
                'unselected:job': function (childView, job) {
                    this.triggerMethod('unselected:job', job);
                }
            }
        });

        View.Header = Marionette.ItemView.extend({
            template: headerTemplate,
            tagName: "div",
            className: "col-xs-12",
            events: {
                "click .btn-cancel": "goBackToCampaign",
                "click .btn-save": "saveCampaignEdits"
            },
            goBackToCampaign: function (e) {
                e.preventDefault();
                CommandCenter.trigger("campaigns:show", this.model.get("id"));
            },
            saveCampaignEdits: function (e) {
                e.preventDefault();
                $('form').submit();
            }
        });

        View.Form = Marionette.LayoutView.extend({
            template: formTemplate,
            regions: {
                locs: "#cLocations",
                socs: "#cOccupations"
            },
            events: {
                "submit form": "editCampaign",
                "mouseover .dateRange": "datepicker_datetimepicker",
                "click #btnStartDateOverride": "startDateOverride",
                "click #btnModalClose": "closeStartDateModal",
                "click #btnClosePopUp": "CloseStartDatePopUp"
            },
            datepicker_datetimepicker: function (ev) {
                //TODO: Need Refactoring and documentation for all logical path
                var status = this.model.get("status");

                var initialEndDate = '-0d';
               
                var isCampaignFeedEnabled = this.model.get('iscampaignfeedenabled');
                if (isCampaignFeedEnabled) {
                    return;
                }
              

               
                if (status && (status.toLowerCase() !== "active" && status.toLowerCase() !== "disabled")) {
                    $("#editStartDatePicker").datepicker({ autoclose: true, startDate: '-0d', clearBtn: true })
                        .on("changeDate", function () {
                            if ($('#editStartDatePicker').datepicker('getFormattedDate').length > 0) {

                                $('#editEndDatePicker').datepicker('setStartDate', $('#editStartDatePicker').datepicker('getFormattedDate'));

                                if ($('#editEndDatePicker').datepicker('getFormattedDate') === "") {
                                    $('#campaign-end-date').val('');
                                }
                            } else {
                                $('#editEndDatePicker').datepicker('setStartDate', '-0d');
                            }
                        });
                    //Check if Start date is present
                    if ($("#editStartDatePicker").datepicker('getFormattedDate').length > 0) {
                        initialEndDate = $('#editStartDatePicker').datepicker('getDate');
                        var todayDate = new Date();
                        var utceditDate = new Date(todayDate.getTime() + todayDate.getTimezoneOffset() * 60000);
                        utceditDate = new Date(utceditDate.getFullYear(), utceditDate.getMonth(), utceditDate.getDate());
                        if (initialEndDate < utceditDate) {
                            initialEndDate = '-0d';
                        }
                    }
                    $("#editEndDatePicker").datepicker({ autoclose: true, startDate: initialEndDate, clearBtn: true })
                        .on("changeDate", function () {
                            $('#editStartDatePicker').datepicker('setEndDate', $('#editEndDatePicker').datepicker('getFormattedDate'));
                        });
                }
                else {
                    if ($("#editStartDatePicker").datepicker('getFormattedDate').length > 0) {

                        initialEndDate = $('#editStartDatePicker').datepicker('getDate');
                        var todayDateNew = new Date();
                        var utceditDateNew = new Date(todayDateNew.getTime() + todayDateNew.getTimezoneOffset() * 60000);
                        utceditDateNew = new Date(utceditDateNew.getFullYear(), utceditDateNew.getMonth(), utceditDateNew.getDate());
                        if (initialEndDate < utceditDateNew) {
                            initialEndDate = '-0d';
                        }
                    }
                    $("#editEndDatePicker").datepicker({ autoclose: true, startDate: initialEndDate, clearBtn: true })
                       .on("changeDate", function () {
                           $('#editStartDatePicker').datepicker('setEndDate', $('#editEndDatePicker').datepicker('getFormattedDate'));
                       });
                }
            },
            templateHelpers: function () {
                return {
                    isEdit: true,
                    customer: this.options.customerId,
                    canActivate: CommandCenter.roleForActivity("activate campaign"),
                    campaignStatus: function () {
                        var statusID;
                        switch (this.status.toLowerCase()) {
                            case 'active':
                                statusID = 1;
                                break;
                            case 'pending':
                                statusID = 2;
                                break;
                            case 'disabled':
                                statusID = 3;
                                break;
                            case 'completed':
                                statusID = 4;
                                break;
                        }

                        return statusID;
                    },
                    hasLocations: function() { return (this.locations || []).length },
                    locationString: _.chain(this.model.get('locations')).sortBy('Name').pluck('Name').map(function(val, key) {
                            return '<span class="label label-cc-default">' + val + '</span>';
                        }).value().join(" "),
                    hasOccupations: function () { return (this.occupations || []).length },
                    occupationString: _.chain(this.model.get('occupations')).sortBy('Name').pluck('Name').map(function (val, key) {
                        return '<span class="label label-cc-default">' + val + '</span>';
                    }).value().join(" "),
                    isCampaignFeedEnabled: this.model.get('iscampaignfeedenabled'),
                    startDate : this.model.get('startdate') ? moment(this.model.get('startdate')).format('MM/DD/YYYY') : '',
                    endDate: this.model.get('enddate') ? moment(this.model.get('enddate')).format('MM/DD/YYYY') : ''
                }
            },
            editCampaign: function (e) {
                e.preventDefault();
                $('.btn-save').addClass('disabled');
                var data = Backbone.Syphon.serialize(this);
                data.startDtOverride = false;
                this.trigger("form:submit", data);
            },
            startDateOverride: function (e) {
                e.preventDefault();
                var data = Backbone.Syphon.serialize(this);
                data.startDtOverride = true;
                this.trigger("form:submit", data);
            },
            closeStartDateModal: function (e) {
                e.preventDefault();
                $('.btn-save').removeClass('disabled');
            },
            CloseStartDatePopUp: function (e) {
                e.preventDefault();
                $('.btn-save').removeClass('disabled');
            }
        });

        View.CampaignedJob = Marionette.ItemView.extend({
            template: campaignedJobTmpl,
            tagName: "tr",
            className: "",
            initialize: function(options){
                this.isCampaignFeedEnabled = options.isCampaignFeedEnabled;
            },
            templateHelpers: function() {
                return {
                    location: _.str.join(", ", this.model.get("city"), this.model.get("stateAbbreviation")),
                    isCampaignFeedEnabled: this.isCampaignFeedEnabled
                };
            },
            events: {
                "click .campaign-toggle": "campaignToggle"
            },
            campaignToggle: function (e) {
                e.preventDefault();

                // job clicked, show selected job area
                //$("#selectedJobs, .collapse-button").removeClass("hidden");

                // remove the selected job from the collection
                //this.model.set("selectedForCampaign", false);
                this.triggerMethod('unselected:job', this);
            }
        });

        View.CampaignedJobs = Marionette.CompositeView.extend({
            template: campaignedJobsTmpl,
            tagName: "div",
            initialize: function (options) {
                this.isCampaignFeedEnabled = options.isCampaignFeedEnabled;
                this.listenTo(this.collection, "change", this.render);
            },
            className: "campaigned-jobs-section",
            childView: View.CampaignedJob,
            childViewContainer: "tbody",
            childViewOptions: function (model, index) {
                return {
                    isCampaignFeedEnabled: this.isCampaignFeedEnabled,
                }
            },
            // Only show jobs that are active in the campaign, or are selected to be in the campaign
            filter: function (child, index, collection) {
                return ((child.get('isactiveincampaign') === true) || (child.get('selectedForCampaign') === true));
            }
        });

        View.Job = Marionette.ItemView.extend({
            template: jobTmpl,
            tagName: "tr",
            initialize: function (options) {
                this.customerId = options.customerId;
                this.campaignId = options.campaignId;

                this.listenTo(this.model, "change", this.modelChanged);
                if((this.campaignId === this.model.get("activecampaignid")) && this.model.get("isactiveincampaign")) {
                    this.model.set("selectedForCampaign", true);
                }
            },
            templateHelpers: function () {
                var cId = this.customerId;
                return {
                    //showOccupation: function () {
                    //    return ($("#select-occupation")[0].selectize.getValue() == '') ? true : false;
                    //},
                    showLocation: function () {
                        return ($("#select-location")[0].selectize.getValue() == '') ? true : false;
                    },
                    //getOccupation: function () {
                    //    var occ = $("#select-occupation")[0].selectize.getValue();
                    //    return (occ == '') ? this.occupation : "";
                    //},
                    getLocation: function () {
                        var loc = $("#select-location")[0].selectize.getValue();
                        return (loc == '') ? (this.city + ', ' + this.stateAbbreviation) : "";
                    },
                    inAnotherCampaign: function () {
                        return _.isNull(this.activecampaignid) ? false : true;
                    }
                };
            },
            modelChanged: function () {
                // toggle the selected indicator
                $(this.$el).find("a.campaign-toggle i").toggleClass("fa-minus fa-plus");
                $(this.$el).find("a.campaign-toggle").toggleClass("selected");
            },
            events: {
                "click .campaign-toggle": "campaignToggle"
            },
            campaignToggle: function (e) {
                e.preventDefault();

                // add the selected job to the collection
                if (this.model.get("selectedForCampaign")) {
                    this.model.set({ "selectedForCampaign": false, "isactiveincampaign": false });
                    this.triggerMethod('unselected:job', this);
                } else {
                    this.model.set({ "selectedForCampaign": true, "isactiveincampaign": true });
                    this.triggerMethod('selected:job', this);
                }
            }
        });

        View.Jobs = Marionette.CompositeView.extend({
            template: jobsTmpl,
            initialize: function (options) {
                this.customerId = options.customerId;
                this.campaignId = options.campaignId;
            },
            childView: View.Job,
            childViewContainer: "tbody",
            childViewOptions: function (model, index) {
                return {
                    customerId: this.customerId,
                    campaignId: this.campaignId
                }
            },
            templateHelpers: function () {
                return {
                    //showOccupation: function () {
                    //    return ($("#select-occupation")[0].selectize.getValue() == '') ? true : false;
                    //},
                    showLocation: function () {
                        return ($("#select-location")[0].selectize.getValue() == '') ? true : false;
                    }
                };
            }
        });
    });

    return CommandCenter.CampaignsApp.Edit.View;
});