﻿define(['app', 'numeral', 'underscore-string', 'routefilter'], function (CommandCenter) {
    CommandCenter.module("CampaignsApp", function (CampaignsApp, CommandCenter, Backbone, Marionette, $, _) {
        CampaignsApp.startWithParent = false;

        CampaignsApp.onStart = function () {
            // disable the search box for now
            $("#search-box").prop("disabled", true);
        };

        CampaignsApp.onStop = function () {
            // remove search box events
            $("#search-box").off("keyup.jobs");
        }

        CampaignsApp.routePermissionsMap = {
            "campaigns/:id/edit": {
                roles: ['3ddf5a27-7f09-4d5c-b594-db94b96c142e', '7acb5358-2896-4923-a59b-5575dd0a7693']
            }
        };

        CampaignsApp.canAccess = function (route) {
            var retVal = true;

            if ((typeof window.CommandCenter.Server.adalconfig != 'undefined') && (window.CommandCenter.Server.adalconfig.active == "true")) {
                // ensure we have the users roles
                if ((typeof CommandCenter.loggedInUser === 'undefined') || (CommandCenter.loggedInUser.get("roles").length == 0)) {
                    CommandCenter.setUserRoles(CommandCenter.CampaignsApp.canAccess, [route]);
                    return;
                }

                // ensure they have permission to the url
                if (_.has(CommandCenter.CampaignsApp.routePermissionsMap, route)) {
                    var roles = CommandCenter.CampaignsApp.routePermissionsMap[route].roles;

                    // check user roles
                    if (_.intersection(roles, CommandCenter.loggedInUser.get("roles")).length === 0) {
                        // no access, don't let them continue
                        retVal = false;
                    }
                }
            }

            return retVal;
        };
    });

    CommandCenter.module("Routers.CampaignsApp", function (CampaignAppRouter, CommandCenter, Backbone, Marionette, $, _) {
        CampaignAppRouter.Router = Marionette.AppRouter.extend({
            appRoutes: {
                "customers/:id/campaigns": "listCampaigns",
                "campaigns/:id": "showCampaign",
                "campaigns/:id/edit": "editCampaign",
                //"campaigns/:id/delete": "deleteCampaign",
                "customers/:id/campaigns/new": "newCampaign",
                "customers/:id/campaigns/:campaignId/clone": "cloneCampaign"
            },
            before: function (route, params) {
                // return false to stop execution
                return CommandCenter.CampaignsApp.canAccess(route);
            }
        });

        var executeAction = function (action, arg, arg2) {
            CommandCenter.startSubApp("CampaignsApp");
            if (arg2 !== undefined)
                action(arg, arg2);
            else
                action(arg);

        };

        var API = {
            listCampaigns: function (id) {
                require(["apps/campaigns/list/list_controller"], function (ListController) {
                    executeAction(ListController.listCampaigns, id);
                });
            },
            showCampaign: function (id) {
                require(["apps/campaigns/show/show_controller"], function (ShowController) {
                    executeAction(ShowController.showCampaign, id);
                });
            },
            newCampaign: function (id) {
                require(["apps/campaigns/new/new_controller"], function (NewController) {
                    executeAction(NewController.buildNewCampaign, id);
                });
            },
            editCampaign: function (id) {
                require(["apps/campaigns/edit/edit_controller"], function (EditController) {
                    executeAction(EditController.editCampaign, id);
                });
            },
            cloneCampaign: function (providerId, campaignId) {
                require(["apps/campaigns/clone/clone_controller"], function (cloneController) {
                    executeAction(cloneController.cloneCampaign, providerId, campaignId);
                });
            }
        };

        CommandCenter.on("campaigns:list", function (id) {
            CommandCenter.navigate("customers/" + id + "/campaigns");
            API.listCampaigns(id);
        });

        CommandCenter.on("campaigns:show", function (id) {
            CommandCenter.navigate("campaigns/" + id);
            API.showCampaign(id);
        });

        CommandCenter.on("campaigns:new", function (id) {
            CommandCenter.navigate("customers/" + id + "/campaigns/new");
            API.newCampaign(id);
        });

        CommandCenter.on("campaigns:edit", function (id) {
            CommandCenter.navigate("campaigns/" + id + "/edit");
            API.editCampaign(id);
        });
        CommandCenter.on("campaigns:clone", function (pid, campaignId) {
            CommandCenter.navigate("customers/" + pid + "/campaigns/" + campaignId + "/clone");
            API.cloneCampaign(pid, campaignId);
        });

        CommandCenter.addInitializer(function () {
            new CampaignAppRouter.Router({
                controller: API
            });
        });
    });

    return CommandCenter.CampaignAppRouter;
});