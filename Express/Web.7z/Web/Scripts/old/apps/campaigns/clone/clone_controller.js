﻿define(["app", "apps/campaigns/clone/clone_view","moment", "selectize" ], function (CommandCenter, View,moment) {
    CommandCenter.module("CampaignsApp.Clone", function (Clone, CommandCenter, Backbone, Marionette, $, _) {
        Clone.Controller = {
            cloneCampaign: function (providerId, campaignId) {
                require(['common/views', 'wookmark', 'models/Campaign', 'models/Customer', 'datepicker'], function (CommonViews) {
                    var fetchingCampaign = CommandCenter.request("campaign:entity", campaignId),
                        fetchingCustomer = CommandCenter.request("customer:entity", providerId),
                        customer;
                    // loading data view
                    var customerCampaign,
                        loadingView = new CommonViews.Loading(),
                        campaignLayout = new View.Layout(),
                        formView = new View.Form(),
                        locView,
                        socView,
                        moreStaticJobsLayout = new View.ALaCarteMoreJobsLayout(),
                        newCollection = new Backbone.Collection(null),
                        vCollection = new Backbone.VirtualCollection(newCollection
                        , {
                            filter: function (model) {
                                return model.get('all_jobs') !== 0;
                            }
                        }
                        ),
                        fCollection = new Backbone.VirtualCollection(newCollection, {
                            filter: function (model) {
                                return model.get('selected') === true;
                            }
                        }),
                        filterView = new View.Filters({ collection: fCollection }),
                        locationOptions = {
                            baseview: campaignLayout,
                            contentview: 'locations',
                            list: 'locations',
                            modeltype: 'Location',
                            cards: 'location:occupations',
                            cardtype: 'Location',
                            container: 'ul.cards',
                            form: formView
                        },
                        occupationOptions = {
                            baseview: campaignLayout,
                            contentview: 'occupations',
                            list: 'occupations',
                            modeltype: 'Occupation',
                            cards: 'occupation:locations',
                            cardtype: 'Occupation',
                            container: 'ul.cards',
                            form: formView
                        };

                    CommandCenter.contentRegion.show(campaignLayout);
                    campaignLayout.formRegion.show(loadingView);

                    campaignLayout.filters.on("show", function () {
                        var callback;

                        $('#filters').on('show.bs.collapse', function (e) {
                            vCollection.updateFilter(function (model) {
                                return model.get('all_jobs') !== 0;
                            });

                            switch (e.target.id) {
                                case "collapseLocation":
                                    callback = Clone.Controller.getData(customer, locationOptions);
                                    break;
                                case "collapseOccupation":
                                    callback = Clone.Controller.getData(customer, occupationOptions);
                                    break;
                            }

                            $.when(callback).then(function (c) {

                                newCollection.add(c.objects);
                                //only for clone page
                               var v2Collection = new Backbone.VirtualCollection(newCollection);
                               var cardView = new View.Cards({ collection: vCollection,vCollection:v2Collection, modelType: ((c.objects.length === 1) ? c.options.cardtype : _.str.join('', c.options.cardtype, 's')), customer: customer, form: c.options.form, campaign: customerCampaign });
                                cardView.on("show", function () {
                                  var  wookmark = new Wookmark(c.options.container, {
                                        offset: 10, // Optional, the distance between grid items
                                        //flexibleWidth: '100%', // Optional, the maximum width of a grid item
                                        //itemWidth: '25%',
                                        autoResize: true, // This will auto-update the layout when the browser window is resized.
                                        //container: $('.content-cards ul'), // Optional, used for some extra CSS styling
                                        fillEmptySpace: false
                                    });

                                  cardView.on("filter:cards", function (args) {
                                        if (args.length === 0) {
                                            vCollection.updateFilter(function (model) {
                                                return model.get('all_jobs') !== 0;
                                            });
                                        } else {
                                            vCollection.updateFilter(function (model) {
                                                return model.get('name').toLowerCase().indexOf(args) !== -1;
                                            });
                                        }

                                        wookmark.initItems();
                                        wookmark.layout(true);
                                  });
                                    
                                });

                                campaignLayout.content.show(cardView);
                            });
                        });

                        $('#filters').on('hide.bs.collapse', function (e) {
                            //baseView.content.empty();
                            campaignLayout.content.reset();
                        });
                      
                    });
                
                    campaignLayout.on("childview:update:form", function (childview, options) {
                        // find the right panel to put the criteria (loc, occ, job)
                        if (options.model.get("selected")) {
                            var arr = customerCampaign.attributes[options.model.get("type") + "s"];
                            arr = (arr === null) ? [] : arr;
                            arr.push({ ID: options.model.get("id"), Name:  options.model.get("name") });
                            customerCampaign.attributes[options.model.get("type") + "s"] = arr ;
                            customerCampaign.trigger("change:" + options.model.get("type") + "s");
                        } else {
                           
                            // ensure the card model get updated
                            var cardModel = campaignLayout.content.currentView.collection.findWhere({ id: options.model.get("id") });
                            if (cardModel !== undefined) {
                                cardModel.set("selected", false);
                            }

                            // ensure the filter model gets updated
                            var filtersModel = campaignLayout.filters.currentView.collection.findWhere({ id: options.model.get("id") });
                            if (filtersModel !== undefined) {
                                filtersModel.set("selected", false);
                            }

                            // remove from the form
                            var obj = customerCampaign.attributes[options.model.get("type") + "s"];
                            //Remove the UnSelected Item
                            _.map(obj, function (param) {

                                if (param !== undefined && param.ID === options.model.get("id")) {
                                    var item = obj.indexOf(param);
                                    if (item > -1)
                                        obj.splice(item, 1);
                                }
                            });
                            customerCampaign.attributes[options.model.get("type") + "s"] = obj;
                            customerCampaign.trigger("change:" + options.model.get("type") + "s");
                        }
                       
                    });

                    $.when(fetchingCustomer).done(function (data) {
                        customer = data;

                    });

                    $.when(fetchingCampaign).done(function (campaign) {
                        
                        if (campaign.attributes["iscampaignfeedenabled"]) {
                            var customerId;
                            customerId = campaign.get("customerId");
                            Backbone.fetchCache.clearItem("api/customers/" + customerId);
                            CommandCenter.trigger("campaigns:list", customerId);
                        } else {
                            //Remove unused attributes
                            delete campaign.attributes["performance"];
                            delete campaign.attributes["refcode"];
                            delete campaign.attributes["status"];
                            delete campaign.attributes["hasbeenactivated"];
                            delete campaign.attributes["iscampaignfeedenabled"];

                            //Set Default values for Start and End Dates
                            campaign.attributes["startdate"] = null;
                            campaign.attributes["enddate"] = null;

                            customerCampaign = campaign;

                            if (customerCampaign.attributes.locations != null) {
                                customerCampaign.locations = _.pluck(customerCampaign.attributes.locations, "ID");
                            }
                            if (customerCampaign.attributes.occupations != null) {
                                customerCampaign.occupations = _.pluck(customerCampaign.attributes.occupations, "ID");
                            }

                            formView = new View.Form({ model: customerCampaign });
                            campaignLayout.header.show(new View.Header({ model: customerCampaign }));

                            // show the edit campaign form here
                            campaignLayout.formRegion.show(formView);

                            // if a la carte campaign, show job currently in campaign
                            if (!customerCampaign.get("isdynamic")) {
                                // get the jobs
                                var fetchingJobs = customerCampaign.get('jobs').fetch({ cache: false });
                                $.when(fetchingJobs)
                                    .done(function (jobs) {
                                        //show Static Campaign
                                        var jobView = new View
                                            .CampaignedJobs({
                                                collection: campaign.jobs(),
                                                isCampaignFeedEnabled: campaign.get('iscampaignfeedenabled')
                                            });
                                        campaignLayout.campaignedJobsRegion.show(jobView);
                                    });
                            } else {
                                //show dynamic Campaign
                                campaignLayout.filters.show(new View.Filters({ collection: fCollection }));
                            }

                            formView.on("select:job", function (args) {
                                // is job already in campaign? if so, just update it
                                var m = customerCampaign.jobs().get(args.model);
                                if (m === undefined) {
                                    customerCampaign.jobs().add(args.model);
                                } else {
                                    m.set("selectedForCampaign", true);
                                }
                            });

                            formView.on("unselect:job", function (args) {
                                customerCampaign.jobs().remove(args.model);
                            });
                            //Form Submit COde
                            formView.on("form:submit", function (data) {
                                var customerId = data.customer;
                                // compile the list of jobids
                                var jobs = _.filter(customerCampaign.jobs().models, function (item) {
                                    return (item.get('isactiveincampaign') || item.get('selectedForCampaign'));
                                });

                                if (jobs.length > 0) {
                                    data.jobids = _.pluck(jobs, "id");
                                }

                                // hide the form errors
                                $('.form-group, .input-group').removeClass('has-error');

                                //Validate the Data Submitted to backEnd

                                // validate campaign data
                                var options = {
                                    success: function (model, response, options) {
                                        // clear the campaigns from cache
                                        Backbone.fetchCache.clearItem("api/customers/" + customerId);
                                        CommandCenter.trigger("campaigns:list", customerId);
                                    },
                                    error: function (model, response, options) {
                                        // requires errors response from the server to get here
                                        $('.btn-save').removeClass('disabled');
                                        $('.form-errors').show();

                                        var serverErrors = response.responseJSON;
                                        var errorMessages = serverErrors.ExceptionMessage;
                                        if (!errorMessages) {
                                            errorMessages = (!serverErrors.Message) ? "An Error has occured on the Server" : serverErrors.Message;
                                        }

                                        campaignLayout.errorRegion.show(new CommonViews.FormErrors({ errors: [{ name: "", message: errorMessages }] }));
                                    }
                                };

                                var tempLoc = customerCampaign.attributes.locations;
                                var tempOcc = customerCampaign.attributes.occupations;
                                // client-side validation
                                Backbone.listenTo(customerCampaign, 'invalid', function (model, errors, options) {
                                    _.each(errors, function (error) {
                                        var controlGroup = $('[name="' + error.name + '"]').parent();
                                        controlGroup.addClass('has-error');
                                        tempLoc = customerCampaign.attributes.locations = tempLoc;
                                        tempOcc = customerCampaign.attributes.occupations = tempOcc;
                                    }, this);

                                    $('.btn-save').removeClass('disabled');
                                    campaignLayout.errorRegion.show(new CommonViews.FormErrors({ errors: errors }));
                                });

                                //Delete Id so that It should call Post to Save new Campaign Instead of Put
                                delete customerCampaign.attributes["id"];
                                //store for failure


                                if (customerCampaign.attributes.locations != null && customerCampaign.attributes.locations.length > 0) {
                                    customerCampaign.attributes.locations = _.pluck(customerCampaign.attributes.locations, "ID");
                                }
                                if (customerCampaign.attributes.occupations != null && customerCampaign.attributes.occupations.length > 0) {
                                    customerCampaign.attributes.occupations = _.pluck(customerCampaign.attributes.occupations, "ID");
                                }

                                customerCampaign.save(data, options);  // Commented 
                            });//Form Submission completed

                            // get the customer information
                            customerId = customerCampaign.get('customerId');
                            var fetchingCustomer = CommandCenter.request("customer:entity", customerId);
                            $.when(fetchingCustomer).done(function (customer) {
                                // show the customer sidebar menu
                                var customerSidebar = new CommonViews.CustomerSidebarMenu({ model: customer });
                                customerSidebar.render();

                                //show customer Budget Info
                                var customerBudgetInfo = new CommonViews.CustomerBudgetInfo({ model: customer });
                                campaignLayout.customerBudgetInfo.show(customerBudgetInfo);
                                // is the campaign an A La Carte Campaign?
                                if (!customerCampaign.get("isdynamic")) {
                                    var locView,
                                        socView,
                                        fetchingLocations = customer.get('locations').fetch({ cache: true }),
                                        fetchingOccupations;

                                    campaignLayout.alacarteRegion.show(moreStaticJobsLayout);

                                    var chained = $.when(fetchingLocations).then(function (locs) {
                                        locView = new CommonViews.Locations({ collection: locs, customerId: customer.id });

                                        locView.on("show:jobs", function (args) {
                                            args.selectedJobs = campaign.jobs();
                                            CommandCenter.CampaignsApp.Clone.Controller.showJobs(moreStaticJobsLayout, args);
                                        });

                                        moreStaticJobsLayout.locs.show(locView);
                                        return customer.get('occupations').fetch({ cache: true });
                                    });

                                    chained.done(function (socs) {
                                        socView = new CommonViews.Occupations({ collection: socs, customerId: customer.id });

                                        socView.on("show:jobs", function (args) {
                                            args.selectedJobs = campaign.jobs();
                                            CommandCenter.CampaignsApp.Clone.Controller.showJobs(moreStaticJobsLayout, args);
                                        });

                                        moreStaticJobsLayout.socs.show(socView);

                                        $('select').selectize({
                                            create: false,
                                            valueField: 'id',
                                            labelField: 'name',
                                            sortField: {
                                                field: 'name',
                                                direction: 'asc'
                                            },
                                            dropdownParent: 'body',
                                            searchField: 'name'
                                        });
                                    });

                                }
                            });
                        }
                    });
                });
            },

            showJobs: function (layout, args) {
                require(['common/views', 'models/Job'], function (CommonViews) {
                    // loading data view
                    var loadingView = new CommonViews.Loading({
                        title: "Loading Job Data",
                        message: "Please wait while the job data is loading."
                    });
                    layout.jobsRegion.show(loadingView);

                    var fetchingJobs = CommandCenter.request("job:entities", args.customer, args.location, args.occupation);
                    $.when(fetchingJobs).done(function (jobs) {
                        // see if the user has already put the job in the campaign
                        if (args.selectedJobs.length > 0) {
                            // user has selected jobs to be campaigned
                            var jArr = _.filter(args.selectedJobs.models, function (j) {
                                return (j.get("selectedForCampaign") || j.get("isactiveincampaign"));
                            });
                            var selected = _.pluck(jArr, 'id');
                            var available = _.pluck(jobs.models, 'id');
                            var alreadySelected = _.intersection(selected, available);
                            _.each(alreadySelected, function (jId) {
                                jobs.findWhere({ id: jId }).set("selectedForCampaign", true);
                            });
                        }

                        var jobsView = new View.Jobs({ collection: jobs, customerId: args.customer, campaignId: args.campaignId });
                        layout.jobsRegion.show(jobsView);

                        layout.on("uncampaign:job", function (args) {
                            jobs.get(args.model).set("selectedForCampaign", false);
                            //campaign.jobs().remove(args.model);
                        });

                        $("table").tablesorter({ debug: false });
                    });
                });
            },
            /* getData:: get a customers job locations */
            getData: function (customer, options) {
                var fetchingList,
                    chained,
                    listView,
                    id = customer,
                    wookmark,
                    container = options.container,
                    $container = $(container),
                    cardView;

                var dfd = $.Deferred();
                var getAllListItems = CommandCenter.request(options.cardtype.toLowerCase() + ":entities");
                chained = $.when(getAllListItems).then(function (items) {
                    options.allItems = items;

                    return customer.get(options.list).fetch({ cache: true });
                });

                $.when(chained).done(function (datalist) {
                    // merge all and customer locations into a virtual collection
                    var newArray;

                    newArray = _.map(options.allItems.models, function (val, key) {
                        var itemFound = _.findWhere(datalist.models, { id: val.get("id") });
                        if (itemFound !== undefined) {
                            return itemFound;
                        } else {
                            return val;
                        }
                    });

                    dfd.resolve({ objects: newArray, options: options });
                }); // end fetching datalist

                return dfd.promise();
            },
            /* end getData */

        };
    });

    return CommandCenter.CampaignsApp.Clone.Controller;
});