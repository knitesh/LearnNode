﻿define(["app",
        "tpl!apps/campaigns/clone/templates/layout.html",
        "tpl!apps/campaigns/clone/templates/header.html",
        "tpl!apps/campaigns/clone/templates/clone.html",
        "tpl!apps/campaigns/clone/templates/campaignedJob.html",
        "tpl!apps/campaigns/clone/templates/campaignedJobs.html",
        "tpl!apps/campaigns/clone/templates/job.html",
        "tpl!apps/campaigns/clone/templates/jobs.html",
        "tpl!apps/campaigns/clone/templates/alacarte.html",
        "tpl!apps/campaigns/clone/templates/badge.html",
        "tpl!apps/campaigns/clone/templates/filter.html",
        "tpl!apps/campaigns/clone/templates/filters.html",
        "tpl!apps/campaigns/clone/templates/cards.html",
        "tpl!apps/campaigns/clone/templates/card.html",
        'moment',
        "lib/jquery.tablesorter",
        "backbone.syphon",
        "underscore-string"],
  function (CommandCenter, layoutTemplate, headerTemplate, cloneTemplate, campaignedJobTmpl, campaignedJobsTmpl, jobTmpl, jobsTmpl, alacarteTmpl, badgeTpl, filterTemplate, filtersTpl, cardsTpl, cardTpl, moment) {
    CommandCenter.module("CampaignsApp.Clone.View", function (cloneView, CommandCenter, Backbone, Marionette, $, _) {
        cloneView.Layout = Marionette.LayoutView.extend({
            template: layoutTemplate,
            tagName: "div",
            className: "row",
            regions: {
                header: "#edit_header",
                formRegion: ".form-region",
                errorRegion: "#cloneformErrors",
                campaignedJobsRegion: "#campaignedJobs > div",
                alacarteRegion: "#additionalJobs",
                customerBudgetInfo: "#customerBudgetInfo",
                filters: ".filters",
                content: ".filterContent"
            },
            childEvents: {
                'selected:job': function (childView, job) {
                    this.getRegion('formRegion').currentView.trigger('select:job', job);
                },
                'unselected:job': function (childView, job) {
                    this.getRegion('formRegion').currentView.trigger('unselect:job', job);
                    this.getRegion('alacarteRegion').currentView.trigger('uncampaign:job', job);
                }
            }
        });

        cloneView.ALaCarteMoreJobsLayout = Marionette.LayoutView.extend({
            template: alacarteTmpl,
            tagName: "div",
            className: "row",
            regions: {
                locs: "#cLocations",
                socs: "#cOccupations",
                jobsRegion: ".job-list",
                filters: ".filters"
            },
            childEvents: {
                'selected:job': function (childView, job) {
                    this.triggerMethod('selected:job', job);
                },
                'unselected:job': function (childView, job) {
                    this.triggerMethod('unselected:job', job);
                }
            }
        });
   
        cloneView.Header = Marionette.ItemView.extend({
            template: headerTemplate,
            tagName: "div",
            className: "col-xs-12",
            events: {
                "click .btn-cancel": "goBackToCampaign",
                "click .btn-save": "saveCampaignEdits"
            },
            goBackToCampaign: function (e) {
                e.preventDefault();
                CommandCenter.trigger("campaigns:list", this.model.get("customerId"));
            },
            saveCampaignEdits: function (e) {
                e.preventDefault();
                $('form').submit();
            }
        });

        cloneView.Form = Marionette.LayoutView.extend({
            template: cloneTemplate,
            regions: {
                locs: "#cLocations",
                socs: "#cOccupations"
            },
            events: {
                "submit form": "cloneCampaign",
                "mouseover .dateRange": "campaignStartEndDateHandler"
            },
            templateHelpers: function () {
                return {
                    customer: this.options.customerId,
                    canActivate: CommandCenter.roleForActivity("activate campaign"),
                    campaignStatus: function () {
                        var statusID;
                        switch (this.status.toLowerCase()) {
                            case 'active':
                                statusID = 1;
                                break;
                            case 'pending':
                                statusID = 2;
                                break;
                            case 'disabled':
                                statusID = 3;
                                break;
                        }

                        return statusID;
                    },
                    hasLocations: function () {
                        return (this.locations || []).length;
                    },
                    locationString: _.chain(this.model.get('locations')).sortBy('Name').pluck('Name').map(function(val, key) {
                            return '<span class="label label-cc-default">' + val + '</span>';
                        }).value().join(" "),
                    hasOccupations: function() {
                        return (this.occupations || []).length;
                    },
                    occupationString: _.chain(this.model.get('occupations')).sortBy('Name').pluck('Name').map(function (val, key) {
                        return '<span class="label label-cc-default">' + val + '</span>';
                    }).value().join(" "),
                    isCampaignFeedEnabled: this.model.get('iscampaignfeedenabled')
                }
            },
            
            cloneCampaign: function (e) {
                e.preventDefault();

                $('.btn-save').addClass('disabled');

                var data = Backbone.Syphon.serialize(this);
                this.trigger("form:submit", data);
            },
            campaignStartEndDateHandler: function (e) {
                e.preventDefault();
                $('#cloneStartDatePicker').datepicker({ autoclose: true, startDate: '-0d', clearBtn: true })
                 .on("changeDate", function () {
                        if ($("#cloneStartDatePicker").datepicker('getFormattedDate').length > 0) {
                            $('#cloneEndDatePicker')
                                .datepicker('setStartDate', $('#cloneStartDatePicker').datepicker('getFormattedDate'));
                        } else {
                            $('#cloneEndDatePicker').datepicker('setStartDate', '-0d');
                        }
                    });
                $('#cloneEndDatePicker').datepicker({ autoclose: true, startDate: '-0d', clearBtn: true })
                    //.on("show", function () {
                    //    if ($('#cloneStartDatePicker').datepicker('getFormattedDate').length > 0) {
                    //        $('#cloneEndDatePicker').datepicker('setStartDate', $('#cloneStartDatePicker').datepicker('getFormattedDate'));
                    //    }
                    //})
                    .on("changeDate", function () {
                        $('#cloneStartDatePicker').datepicker('setEndDate', $('#cloneEndDatePicker').datepicker('getFormattedDate'));
                    });
            }
        });

        cloneView.CampaignedJob = Marionette.ItemView.extend({
            template: campaignedJobTmpl,
            tagName: "tr",
            className: "",
            initialize: function(options){
                this.isCampaignFeedEnabled = options.isCampaignFeedEnabled;
            },
            templateHelpers: function() {
                return {
                    location: _.str.join(", ", this.model.get("city"), this.model.get("stateAbbreviation")),
                    isCampaignFeedEnabled: this.isCampaignFeedEnabled
                };
            },
            events: {
                "click .campaign-toggle": "campaignToggle"
            },
            campaignToggle: function (e) {
                e.preventDefault();
                this.triggerMethod('unselected:job', this);
            }
        });

        cloneView.CampaignedJobs = Marionette.CompositeView.extend({
            template: campaignedJobsTmpl,
            tagName: "div",
            initialize: function (options) {
                this.isCampaignFeedEnabled = options.isCampaignFeedEnabled;
                this.listenTo(this.collection, "change", this.render);
            },
            className: "campaigned-jobs-section",
            childView: cloneView.CampaignedJob,
            childViewContainer: "tbody",
            childViewOptions: function (model, index) {
                return {
                    isCampaignFeedEnabled: this.isCampaignFeedEnabled,
                }
            },
            // Only show jobs that are active in the campaign, or are selected to be in the campaign
            filter: function (child, index, collection) {
                return ((child.get('isactiveincampaign') === true) || (child.get('selectedForCampaign') === true) );
            }
        });

        cloneView.Job = Marionette.ItemView.extend({
            template: jobTmpl,
            tagName: "tr",
            initialize: function (options) {
                this.customerId = options.customerId;
                this.campaignId = options.campaignId;

                this.listenTo(this.model, "change", this.modelChanged);
                if((this.campaignId === this.model.get("activecampaignid")) && this.model.get("isactiveincampaign")) {
                    this.model.set("selectedForCampaign", true);
                }
            },
            templateHelpers: function () {
                var cId = this.customerId;
                return {
                    showLocation: function () {
                        return ($("#select-location")[0].selectize.getValue() == '') ? true : false;
                    },
                    getLocation: function () {
                        var loc = $("#select-location")[0].selectize.getValue();
                        return (loc == '') ? (this.city + ', ' + this.stateAbbreviation) : "";
                    },
                    inAnotherCampaign: function () {
                        return _.isNull(this.activecampaignid) ? false : true;
                    }
                };
            },
            modelChanged: function () {
                // toggle the selected indicator
                $(this.$el).find("a.campaign-toggle i").toggleClass("fa-minus fa-plus");
                $(this.$el).find("a.campaign-toggle").toggleClass("selected");
            },
            events: {
                "click .campaign-toggle": "campaignToggle"
            },
            campaignToggle: function (e) {
                e.preventDefault();
                // add the selected job to the collection
                if (this.model.get("selectedForCampaign")) {
                    this.model.set({ "selectedForCampaign": false, "isactiveincampaign": false });
                    this.triggerMethod('unselected:job', this);
                } else {
                    this.model.set({ "selectedForCampaign": true, "isactiveincampaign": true });
                    this.triggerMethod('selected:job', this);
                }
            }
        });

        cloneView.Jobs = Marionette.CompositeView.extend({
            template: jobsTmpl,
            initialize: function (options) {
                this.customerId = options.customerId;
                this.campaignId = options.campaignId;
            },
            childView: cloneView.Job,
            childViewContainer: "tbody",
            childViewOptions: function (model, index) {
                return {
                    customerId: this.customerId,
                    campaignId: this.campaignId
                }
            },
            templateHelpers: function () {
                return {
                    showLocation: function () {
                        return ($("#select-location")[0].selectize.getValue() == '') ? true : false;
                    }
                };
            }
        });

        cloneView.Badge = Marionette.ItemView.extend({
            template: badgeTpl,
            tagName: "span",
            className: "label label-cc-default",
            initialize: function (e) {
                this.$el.attr({ "data-type": this.model.get("type"), "data-id": this.model.get("id") });
            },
            attributes: {
                "style": "margin: 0 2px; display: inline-block;"
            },
            ui: {
                removebtn: "i.fa"
            },
            events: {
                "click @ui.removebtn": "removeSelection"
            },
            removeSelection: function (e) {
                e.preventDefault();
                // if the card for this item is still showing, trigger a click to unselect it
                if ($(".filterContent .cards li[data-type-id='" + this.model.get("id") + "']").length !== 0) {
                    $(".filterContent .cards li[data-type-id='" + this.model.get("id") + "']").toggleClass("selected");
                }
                this.triggerMethod("remove:selection", this.model);
            }
        });
        cloneView.Filters = Marionette.CompositeView.extend({
            template: filtersTpl,
            tagName: "div",
            className: "panel-group",
            attributes: {
                "id": "filters",
                "role": "tablist",
                "aria-multiselectable": "true"
            },
            childView: cloneView.Badge,
            attachHtml: function (collectionView, childView, index) {
                var filterType = collectionView.collection.models[index].get("type").charAt(0).toUpperCase() + collectionView.collection.models[index].get("type").slice(1);
                var container = $("#collapse" + filterType + " .panel-body");

                container.append(childView.$el);
            },
            childEvents: {
                "remove:selection": function (childView, options) {
                    options.set("selected", false);
                    this.triggerMethod("update:form", { model: options });
                }
            },
            collectionEvents: {
                "add": "collectionEvent",
                "remove": "collectionEvent",
                "reset": "collectionEvent"
            },
            collectionEvent: function () {
                if (this.collection.length > 0) {
                    $('#defaultCriteria').hide();
                } else {
                    $('#defaultCriteria').show();
                }

                $(this.ui.locationsSelected).text(this.collection.where({ "type": "location", "selected": true }).length);
                $(this.ui.occupationsSelected).text(this.collection.where({ "type": "occupation", "selected": true }).length);
            },
            ui: {
                locationsSelected: "#filterByLocation .panel-title a small span",
                occupationsSelected: "#filterByOccupation .panel-title a small span"
            }
        });

        cloneView.Filter = Marionette.LayoutView.extend({
            template: filterTemplate,
            regions: {
                locs: "#cLocations",
                socs: "#cOccupations",
                campaignedJobs: "#selectedJobs > .row > .col-xs-12 > div"
            },
            templateHelpers: function () {
                return {
                    customer: this.options.customerId
                }
            },
            events: {
                "click .collapse-button": "toggleSelectedJobs"
            },
            toggleSelectedJobs: function (e) {
                e.preventDefault();

                // toogle collapse button icon
                $(".collapse-button a > i").toggleClass("fa-angle-down fa-angle-up");

                // toggle showing the selected jobs
                $("#selectedJobs").toggleClass("open");
            },
            childEvents: {
                'update:jobcount': function (childView, collection) {
                    if (collection.length > 0) {
                        // a la carte campaign
                        $("#campaign-job-count").val(collection.length);
                    } else {
                        // dynamic campaign
                        $("#campaign-job-count").val($("#jobs tbody tr").length);
                    }

                    $(".selected-job-count").text($("#campaign-job-count").val());
                },
                'uncampaign:job': function (childView, job) {
                    this.triggerMethod('uncampaign:job', job);
                }
            }
        });
   
    cloneView.Card = Marionette.ItemView.extend({
            template: cardTpl,
            tagName: "li",
            className: "card pull-left",
            initialize: function (options) {
                // Add Selected class to already existing Location or Occupation
                (this.model.get("selected")) ? this.$el.addClass('selected') : null;
            },
            events: {
                "click a" : "campaignItem",
                "click": "campaignItem"
            },
            ui: {
                campaignToggle: "i",
                tabForm: ".tab-pane.active form"
            },
            attributes: function () {
                return {
                    "data-type-id": this.model.id
                };
            },
            modelEvents: {
                "change:selected": "modelSelectionChanged"
            },
            campaignItem: function (e) {
                e.preventDefault();
                e.stopPropagation();

                // highlight the selected card
                this.$el.toggleClass("selected");

                if (this.$el.hasClass("selected")) {
                    this.model.set("selected", true);
                } else {
                    this.model.set("selected", false);
                }
            },
            modelSelectionChanged: function () {
                this.triggerMethod("update:criteria", this);
            }
        });

    cloneView.Cards = Marionette.CompositeView.extend({
            template: cardsTpl,
            className: "clearfix",
            childView: cloneView.Card,
            childViewContainer: ".cards",
            childEvents: {
                "update:criteria": function (args) {
                    this.triggerMethod("update:form", { model: args.model }); 
                }
            },
            viewComparator: "name",
            initialize: function (options) {
              
                this.modelType = options.modelType;
                this.customer = options.customer;
                this.form = options.form;
                this.campaign = options.campaign;
                this.vCollection = options.vCollection;

                $("#criteria" + this.modelType.toLowerCase()).hide();

                var existingItem = this.campaign.get(this.modelType.toLowerCase());
                if (existingItem !== null) {
                    var data = this.vCollection.models;

                    var arrMap = _.map(existingItem, function (val, key) {
                        return val.ID;
                    });
                    _.forEach(arrMap,function (ele, index, list) {
                            var item = _.findWhere(data, { id: ele });
                           // if (item !== undefined) {
                                item.set("selected", true);
                          //  }
                        });
                }
            },
            ui: {
                cardsTitle: "h4 span",
                filterBox: ".filter-box"
            },
            templateHelpers: function () {
                return {
                    items: this.collection.length,
                    modelType: this.modelType,
                    title: "", //_.str.toSentence([this.collection.length, this.modelType, this.model.get("name")], " ", " in "),
                    customerId: this.customer.get("id")
                };
            },
            events: {
                "keyup @ui.filterBox": "filterCards",
                "click .form-control-clear": "clearFilter",
                "click .campaign-all": "campaignAll",
                "click .campaign-none": "campaignNone"
            },
            collectionEvents: {
                //"filter": "collectionChanged"
            },
            filter: function (child, index, collection) {
                //return (child.get('all_jobs') !== 0) && (child.get("type") == this.modelType.toLowerCase().split('s')[0]);
                return (child.get("type") == this.modelType.toLowerCase().split('s')[0]);
            },
            filterCards: function (e) {
                var term = $(this.ui.filterBox).val().toLowerCase();
                _.debounce(this.trigger("filter:cards", term), 300);


                
            },
            clearFilter: function (e) {
                e.preventDefault();

                if (this.ui.filterBox.val() == '') { return; }
                if (this.ui.filterBox.attr('disabled') !== undefined) { return; }

                this.ui.filterBox.val('');
                //this.ui.filterBox.trigger('keyup');
                this.filterCards();
            },
            collectionChanged: function () {
                //this.ui.cardsTitle.text(_.str.toSentence([this.collection.length, this.modelType, this.model.get("name")], " ", " in "));
            },
            campaignAll: function (e) {
                e.preventDefault();

                var c = this.collection;
                _.each($("li.card:visible"), function (ele, index, list) {
                    // mark all the items shown as selected

                    // toggle the cards to indicate selected state
                    $(ele).addClass("selected");

                    // get the data-type-id
                    var item = _.findWhere(c.models, { id: Number($(ele).attr("data-type-id")) });
                    item.set("selected", true);
                });
            },
            campaignNone: function (e) {
                e.preventDefault();
                
                var c = this.collection;
                _.each($("li.card:visible"), function (ele, index, list) {
                    // mark all the items shown as unselected

                    // toggle the cards to indicate unselected state
                    $(ele).removeClass("selected");

                    // get the data-type-id
                    var item = _.findWhere(c.models, { id: Number($(ele).attr("data-type-id")) });
                    item.set("selected", false);
                });
            }
        });
    });
    return CommandCenter.CampaignsApp.Clone.View;
});