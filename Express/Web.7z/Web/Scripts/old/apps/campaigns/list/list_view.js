﻿define([
        "app",
        "tpl!apps/campaigns/list/templates/layout.html",
        "tpl!apps/campaigns/list/templates/view.html",
        "tpl!apps/campaigns/list/templates/providerOverview.html",
        "tpl!apps/campaigns/list/templates/campaign.html",
        "tpl!apps/campaigns/list/templates/active.html",
        "tpl!apps/campaigns/list/templates/pending.html",
        "tpl!apps/campaigns/list/templates/disabled.html",
        "tpl!apps/campaigns/list/templates/completed.html",
        "tpl!apps/campaigns/list/templates/paused.html",
        "tpl!common/templates/noData.html",
        "moment",
        "numeral"
    ],
    function(CommandCenter,
        layoutTemplate,
        viewTemplate,
        providerOverviewTpl,
        campaignTpl,
        activeTpl,
        pendingTpl,
        disabledTpl,
        completedTpl,
        pausedTpl,
        noDataTpl,
        moment) {
    CommandCenter.module("CampaignsApp.List.View", function (View, CommandCenter, Backbone, Marionette, $, _) {
        View.Layout = Marionette.LayoutView.extend({
            template: layoutTemplate,
            tagName: "div",
            className: "row",
            regions: {
                campaignRegion: "#customer-campaigns",
                customerHeader: "#customerHeader",
                customerBudgetInfo: "#customerBudgetInfo"
            },
            templateHelpers: function () {
                return {
                    companyId: this.options.customerId//,
                    //items: this.options.customerCampaigns
                }
            }
        });

        View.NoData = Marionette.ItemView.extend({
            template: noDataTpl,
            tagName: "div",
            className: "col-xs-12",

            title: "We're sorry, no items exist.",
            message: "",

            serializeData: function () {
                return {
                    title: Marionette.getOption(this, "title"),
                    message: Marionette.getOption(this, "message")
                }
            }
        });

        View.Campaign = Marionette.ItemView.extend({
            template: campaignTpl,
            tagName: "div",
            className: "col-xs-12 col-sm-6 col-md-4 col-lg-3",
            events: {
                "click .delete-campaign": "deleteCampaign",
                "click .close-campaign" : "closeCampaign"
            },
            initialize: function (options) {
                this.campaignfeedenabled = options.CampaignFeedEnabled;
            },
            templateHelpers: function () {
                return {
                    canEdit: CommandCenter.roleForActivity("edit " + this.model.get("active").toLowerCase() + " campaign"),
                    completedStatus: this.model.get("active") ? (this.model.get("active").toLowerCase() === "completed") : false,
                    pctComplete: numeral(this.model.get('realized') / this.model.get('budget')).format('0%'),
                    pctUnformatted: (this.model.get('realized') / this.model.get('budget')) * 100,
                    isCampaignFeedEnabled: this.campaignfeedenabled,
                    isInactiveCampaign: this.model.get("active") ? (this.model.get("active").toLowerCase() === "disabled") : false,
                    isPausedCampaign: this.model.get("active") ? (this.model.get("active").toLowerCase() === "paused") : false,
                    providerId: this.model.get('customerId'),
                    isBudgetRealized: function() {
                        if (this.budgetrealizeddate != null) {
                            return true;
                        }
                        return false;
                    },
                    dateBudgetRealized: function () {
                        var dte = "&nbsp;";

                        if (this.budgetrealizeddate != null) {
                            dte = "Budget Realized: " + moment(this.budgetrealizeddate).format('MMM DD, YYYY');
                        }

                        return dte;
                    },
                    endDateReached: function () {
                        var completedDateMet = "";
                        if (!this.budgetrealizeddate && this.completeddate != null) {
                            completedDateMet = "Completed on: " + moment(this.completeddate).format('MMM DD, YYYY');
                        }
                        return completedDateMet;
                    },
                    pausedCampaignText: function (isPausedCampaign) {
                        var pauseText = "";
                        if (isPausedCampaign && this.pauseddate) {
                            if (this.campaignstatusreasontype) {
                                if (this.campaignstatusreasontype.toLowerCase() === "brcampaigndailycappause") {
                                    pauseText = "Campaign Cap met on: " + moment(this.pauseddate).format('MMM DD, YYYY');
                                }
                                else if (this.campaignstatusreasontype.toLowerCase() === "brproviderdailycappause") {
                                    pauseText = "Provider Cap met on: " + moment(this.pauseddate).format('MMM DD, YYYY');
                                }
                            }
                            else {
                                pauseText = "Paused on: " + moment(this.pauseddate).format('MMM DD, YYYY');
                            }
                        }
                        return pauseText;
                    },
                    relevantDate: function () {
                        var rDate = "",
                            caption = "";

                        switch (this.active.toLowerCase()) {
                            case "active":
                                caption = "Activated";
                                rDate = this.startdate;
                                break;
                            case "pending":
                                caption = "Created";
                                rDate = this.created;
                                break;
                            case "disabled":
                                caption = "Inactivated";
                                rDate = this.enddate;
                                break;
                            case "completed":
                                caption = "Completed";
                                rDate = this.completeddate;
                                break;
                            case "paused":
                                caption = "Paused";
                                rDate = this.pauseddate;
                                break;
                        }

                        return caption + " " + moment.utc(rDate, "YYYY-MM-DDTHH:mm:ss Z").local().fromNow();
                    },
                    descFormatted: function () {
                        // find \d {occupations | locations}

                        // a la carte campaigns do not have descriptions
                        if (this.description == null) { return null; };

                        var regex = /(locations|occupations)+/g;
                        var matches = this.description.match(regex);
                        
                        if (matches !== null) {
                            var desc = this.description;
                            var that = this;

                            _.each(matches, function (ele, index, list) {
                                var sArr = _.sortBy(that[ele], 'Name');
                                var data = _.map(_.pluck(sArr, "Name"), function (val, index, list) { return '<small>' + val + '</small>'; });
                                var popover = '<a tabindex="0" class="list-popover" role="button" data-toggle="popover" data-trigger="click" title="' + ele + '" data-content="' + data.join(" ") + '">' + ele + '</a>';
                                var re = new RegExp(ele, "g");
                                desc = desc.replace(re, popover);
                            });
                            
                            return desc;
                        } else {
                            return this.description;
                        }
                        
                    }
                }
            },
            deleteCampaign: function (e) {
                e.preventDefault();
                CommandCenter.request("campaign:delete", this.model);
            },
            closeCampaign: function (e) {
                e.preventDefault();
                var that = this;

                $('#btnCloseCampaign').on('click', function () {
                    $('#closeCampaignModal').modal('toggle');
                    CommandCenter.request("campaign:close", that.model);
                });
                $('#closeCampaignModal').modal('toggle');
            }
        });

        View.ActiveCampaigns = Marionette.CompositeView.extend({
            childView: View.Campaign,
            childViewContainer: ".active",
            childViewOptions: function (model, index) {
                return {
                    CampaignFeedEnabled: this.model.get('company').campaignfeedenabled
                }
            },
            template: activeTpl,
            initialize: function () {
                this.listenTo(this.collection, 'add', this.render);
                this.listenTo(this.collection, 'change', this.render);
                //$(".active-campaign-count").text("(" + this.collection.length + ")");
            },
            emptyView: View.NoData,
            emptyViewOptions: {
                title: "No active campaigns currently exist.",
                message: "Activate some pending campaigns or create a new campaign."
            },
            filter: function (child, index, collection) {
                return child.get('active') === "Active";
            }
        });

        View.PendingCampaigns = Marionette.CompositeView.extend({
            childView: View.Campaign,
            childViewContainer: ".pending",
            childViewOptions: function (model, index) {
                return {
                    CampaignFeedEnabled: this.model.get('company').campaignfeedenabled
                }
            },
            template: pendingTpl,
            initialize: function () {
                this.listenTo(this.collection, 'add', this.render);
                this.listenTo(this.collection, 'change', this.render);

                //$(".pending-campaign-count").text("(" + this.collection.length + ")");
            },
            emptyView: View.NoData,
            emptyViewOptions: {
                title: "No pending campaigns currently exist.",
                message: "Create a new campaign."
            },
            filter: function (child, index, collection) {
                return child.get('active') === "Pending";
            }
        });

        View.InactiveCampaigns = Marionette.CompositeView.extend({
            childView: View.Campaign,
            childViewContainer: ".inactive",
            childViewOptions: function (model, index) {
                return {
                    CampaignFeedEnabled: this.model.get('company').campaignfeedenabled
                }
            },
            template: disabledTpl,
            initialize: function () {
                this.listenTo(this.collection, 'add', this.render);
                this.listenTo(this.collection, 'change', this.render);

                //$(".inactive-campaign-count").text("(" + this.collection.length + ")");
            },
            emptyView: View.NoData,
            emptyViewOptions: {
                title: "No disabled campaigns currently exist."
            },
            filter: function (child, index, collection) {
                return child.get('active') === "Disabled";
            }
        });

        View.CompletedCampaigns = Marionette.CompositeView.extend({
            childView: View.Campaign,
            childViewContainer: ".completed",
            childViewOptions: function (model, index) {
                return {
                    CampaignFeedEnabled: this.model.get('company').campaignfeedenabled
                }
            },
            template: completedTpl,
            initialize: function () {
                this.listenTo(this.collection, 'add', this.render);
                this.listenTo(this.collection, 'change', this.render);
                //$(".inactive-campaign-count").text("(" + this.collection.length + ")");
            },
            emptyView: View.NoData,
            emptyViewOptions: {
                title: "No completed campaigns currently exist."
            },
            filter: function (child, index, collection) {
                return child.get('active') === "Completed";
            }
        });

        View.PausedCampaigns = Marionette.CompositeView.extend({
            childView: View.Campaign,
            childViewContainer: ".paused-campaigns",
            childViewOptions: function (model, index) {
                return {
                    CampaignFeedEnabled: this.model.get('company').campaignfeedenabled
                }
            },
            template: pausedTpl,
            initialize: function () {
                this.listenTo(this.collection, 'add', this.render);
                this.listenTo(this.collection, 'change', this.render);
            },
            emptyView: View.NoData,
            emptyViewOptions: {
                title: "No paused campaigns currently exist."
            },
            filter: function (child, index, collection) {
                return child.get('active') === "Paused";
            }
        });

        View.ProviderOverView = Marionette.ItemView.extend({
            tagName: "div",
            className: "col-xs-12",
            template: providerOverviewTpl,
            initialize: function (options) {
                /**
                 * Getting a Function Defined in Controller, so that It can be used in view without code duplication #exemplify                 * 
                 */
                CommandCenter.fnRenderProviderDailyCapsChart = this.options.fnRenderProviderDailyCapsChart;
                this.usedDailyCaps = this.model.get("company").usedDailyCaps;
                this.listenTo(this.model, 'change', this.render);
            },
            events: {
                "click .chart-timeframe > a": "changeProviderChartTimeframe"
            },
            templateHelpers: function () {
                return {
                    name: this.model.get('name'),
                    dailyCapsProgressTemplate: function (usedDailyCaps) {
                        if (usedDailyCaps === null) {
                            usedDailyCaps = 0;
                        }
                        
                        usedDailyCaps = Math.floor(numeral(usedDailyCaps));
                       
                        return (
                            '<div class="daily-provider-progress progress"><div id="dailyCapsProgressBar" class="progress-bar daily-progress-bar-info progress-bar-striped" role="progressbar" ' +
                                'aria-valuenow=' + usedDailyCaps + ' aria-valuemin="0" aria-valuemax="100" style="width : ' + usedDailyCaps + '%" ></div></div><label>' +
                               usedDailyCaps + '% Daily Cap Used </div>');
                    }
                }
            },
            viewloaded: function () {
                //$("#dailyCapsProgressBar").css({ "width": "90%" });
            },
            changeProviderChartTimeframe: function (e) {
                e.preventDefault();
                $(e.target).siblings().removeClass("active disabled");
                $(e.target).addClass("active disabled");
                $("#provider-chart-spinner").show();
                this.model.dailyCapPerformance()
                    .fetch({cache: false, data: { numberOfDays: $(e.target).attr("data-content") } }).done(function (data) {
                        CommandCenter.fnRenderProviderDailyCapsChart(data);
                        $("#provider-chart-spinner").hide();
                       
                    });
            }
        });

        View.CustomerCampaigns = Marionette.LayoutView.extend({
            template: viewTemplate,
            regions: {
                activeCampaigns: "#active",
                pendingCampaigns: "#pending",
                inactiveCampaigns: "#inactive",
                pausedCampaigns: "#paused",
                completedCampaigns: "#completed",
                overviewCampaigns: "#overview"
            }
        });
    });

    return CommandCenter.CampaignsApp.List.View;
});