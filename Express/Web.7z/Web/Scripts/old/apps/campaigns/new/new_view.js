define(["app",
        //"tpl!apps/campaigns/new/templates/layout.html",
        //"tpl!apps/campaigns/new/templates/typeCampaign.html",
        //"tpl!apps/campaigns/new/templates/new.html",
        "tpl!apps/campaigns/new/templates/filter.html",
        "tpl!apps/campaigns/new/templates/jobs.html",
        "tpl!apps/campaigns/new/templates/job.html",
        //"tpl!apps/campaigns/new/templates/dynamic.html",
        "tpl!apps/campaigns/new/templates/errors.html",
        "tpl!apps/campaigns/new/templates/campaignedJobs.html",
        "tpl!apps/campaigns/new/templates/campaignedJob.html",
        "tpl!apps/campaigns/new/templates/newCampaign.html",
        //"tpl!apps/campaigns/new/templates/tabContent.html",
        "tpl!apps/campaigns/new/templates/form.html",
        //"tpl!apps/campaigns/new/templates/locationList.html",
        //"tpl!apps/campaigns/new/templates/locations.html",
        "tpl!apps/campaigns/new/templates/cards.html",
        "tpl!apps/campaigns/new/templates/card.html",
        "tpl!apps/campaigns/new/templates/filters.html",
        "tpl!apps/campaigns/new/templates/badge.html",
        "tpl!apps/campaigns/new/templates/alacarte.html",
        "moment",
        "bootstrap",
        "backbone.syphon",
        "lib/jquery.tablesorter",
        "numeral"
        ],
      function (CommandCenter, filterTemplate, jobsTemplate, jobTemplate, errorsTemplate, campaignedJobsTpl, campaignedJobTpl, newCampaignTpl, formTpl, cardsTpl, cardTpl, filtersTpl, badgeTpl, aLaCarteTpl, moment) {
    CommandCenter.module("CampaignsApp.New.View", function (View, CommandCenter, Backbone, Marionette, $, _) {
        View.ALaCarte = Marionette.LayoutView.extend({
            template: aLaCarteTpl,
            regions: {
                jobsRegion: "#jobs"
            }
        });

        View.FormErrors = Marionette.ItemView.extend({
            template: errorsTemplate,
            tagName: "div",
            className: "panel panel-danger",
            templateHelpers: function () {
                return {
                    errors: this.options.errors,
                    title: "Errors"
                }
            }
        });

        View.FormMessages = Marionette.ItemView.extend({
            template: errorsTemplate,
            tagName: "div",
            className: "panel panel-success",
            templateHelpers: function () {
                return {
                    errors: this.options.messages,
                    title: "Notifications"
                }
            }
        });

        View.CampaignedJob = Marionette.ItemView.extend({
            template: campaignedJobTpl,
            tagName: "tr",
            events: {
                "click .remove-from-campaign": "removeJob"
            },
            removeJob: function (e) {
                e.preventDefault();
                this.model.set("selectedForCampaign", false);
                this.trigger("job:unselected", { job: this });
            }
        });

        View.CampaignedJobs = Marionette.CompositeView.extend({
            template: campaignedJobsTpl,
            childView: View.CampaignedJob,
            childViewContainer: "tbody",
            tagName: "table",
            className: "table table-striped",

            initialize: function () {
                this.listenTo(this.collection, "add", this.collectionChanged),
                this.listenTo(this.collection, "remove", this.collectionChanged)
            },
            collectionChanged: function () {
                // update selected job count
                this.triggerMethod('update:jobcount', this.collection);
            },

            onChildviewJobUnselected: function (childView, model) {
                this.triggerMethod('job:unselected', model);
                this.triggerMethod('uncampaign:job', model);
            }
        });

        View.Job = Marionette.ItemView.extend({
            template: jobTemplate,
            tagName: "tr",
            initialize: function (options) {
                this.customerId = options.customerId;

                this.listenTo(this.model, "change", this.modelChanged);
            },
            templateHelpers: function () {
                var cId = this.customerId;
                return {
                    showOccupation: function () {
                        return ($("#select-occupation")[0].selectize.getValue() == '') ? true : false;
                    },
                    showLocation: function () {
                        return ($("#select-location")[0].selectize.getValue() == '') ? true : false;
                    },
                    getOccupation: function() {
                        var occ = $("#select-occupation")[0].selectize.getValue();
                        return (occ == '') ? this.occupation : "";
                    },
                    getLocation: function () {
                        var loc = $("#select-location")[0].selectize.getValue();
                        return (loc == '') ? (this.city + ', ' + this.stateAbbreviation) : "";
                    },
                    inAnotherCampaign: function () {
                        return _.isNull(this.activecampaignid) ? false : true;
                    }
                };
            },
            modelChanged: function () {
                // toggle the selected indicator
                $(this.$el).find("a.campaign-toggle i").toggleClass("fa-minus fa-plus");
            },
            events: {
                "click .campaign-toggle": "campaignToggle"
            },
            campaignToggle: function (e) {
                e.preventDefault();

                // job clicked, show selected job area
                $("#selectedJobs, .collapse-button").removeClass("hidden");

                // add the selected job to the collection
                if (this.model.get("selectedForCampaign")) {
                    this.model.set("selectedForCampaign", false);
                    $(this.$el).find("a").attr("title", "Add to Campaign");
                    this.trigger("job:unselected", { job: this });
                } else {
                    this.model.set("selectedForCampaign", true);
                    $(this.$el).find("a").attr("title", "Remove from Campaign");
                    this.trigger("job:selected", { job: this });
                }

                // trigger a budget recalculation
                $("#campaign-ppc").trigger("change");
            }
        });

        View.Jobs = Marionette.CompositeView.extend({
            template: jobsTemplate,
            initialize: function(options) {
                this.customerId = options.customerId;

                var campaignedJobs = CommandCenter.request("campaigned:jobs");
            },
            childView: View.Job,
            childViewContainer: "tbody",
            childViewOptions: function (model, index) {
                return {
                    customerId: this.customerId
                }
            },

            onChildviewJobSelected: function(childView, model) {
                this.triggerMethod('job:selected', model);
            },
            onChildviewJobUnselected: function(childView, model) {
                this.triggerMethod('job:unselected', model);
            },

            templateHelpers: function () {
                return {
                    showOccupation: function () {
                        return ($("#select-occupation")[0].selectize.getValue() == '') ? true : false;
                    },
                    showLocation: function () {
                        return ($("#select-location")[0].selectize.getValue() == '') ? true : false;
                    }
                };
            },
            campaignedJobsChanged: function (job) {
                var j = this.collection.findWhere({ id: job.id });
                if (j !== undefined) {
                    j.set("selectedForCampaign", false);
                }
            }
        });

        View.Badge = Marionette.ItemView.extend({
            template: badgeTpl,
            tagName: "span",
            className: "label label-cc-default",
            initialize: function (e) {
                this.$el.attr({ "data-type": this.model.get("type"), "data-id": this.model.get("id") });
            },
            attributes: {
                "style": "margin: 0 2px; display: inline-block;"
            },
            ui: {
                removebtn: "i.fa"
            },
            events: {
                "click @ui.removebtn": "removeSelection"
            },
            removeSelection: function (e) {
                e.preventDefault();

                // if the card for this item is still showing, trigger a click to unselect it
                if ($(".filterContent .cards li[data-type-id='" + this.model.get("id") + "']").length != 0) {
                    //    $(".filterContent .cards li[data-type-id='" + this.model.get("id") + "']").trigger("click");
                    $(".filterContent .cards li[data-type-id='" + this.model.get("id") + "']").toggleClass("selected");
                }
                //} else {
                //this.model.set("selected", false);
                this.triggerMethod("remove:selection", this.model);
                    //this.triggerMethod("update:form", { model: this.model });
                //}
            }
        });

        View.Filters = Marionette.CompositeView.extend({
            template: filtersTpl,
            tagName: "div",
            className: "panel-group",
            attributes: {
                "id": "filters",
                "role": "tablist",
                "aria-multiselectable": "true"
            },
            childView: View.Badge,
            attachHtml: function (collectionView, childView, index) {
                var filterType = collectionView.collection.models[index].get("type").charAt(0).toUpperCase() + collectionView.collection.models[index].get("type").slice(1);
                var container = $("#collapse" + filterType + " .panel-body");

                container.append(childView.$el);
            },
            childEvents: {
                "remove:selection": function (childView, options) {
                    options.set("selected", false);
                    this.triggerMethod("update:form", { model: options });
                }
            },
            collectionEvents: {
                "add": "collectionEvent",
                "remove": "collectionEvent",
                "reset": "collectionEvent"
            },
            collectionEvent: function() {
                this.ui.locationsSelected.text(this.collection.where({ "type": "location", "selected": true }).length);
                this.ui.occupationsSelected.text(this.collection.where({ "type": "occupation", "selected": true }).length);
            },
            ui: {
                locationsSelected: "#filterByLocation .panel-title a small span",
                occupationsSelected: "#filterByOccupation .panel-title a small span",
            }
        });

        View.Filter = Marionette.LayoutView.extend({
            template: filterTemplate,
            regions: {
                locs: "#cLocations",
                socs: "#cOccupations",
                campaignedJobs: "#selectedJobs > .row > .col-xs-12 > div"
            },
            templateHelpers: function () {
                return {
                    customer: this.options.customerId
                }
            },
            events: {
                "click .collapse-button": "toggleSelectedJobs"
            },
            toggleSelectedJobs: function (e) {
                e.preventDefault();

                // toogle collapse button icon
                $(".collapse-button a > i").toggleClass("fa-angle-down fa-angle-up");

                // toggle showing the selected jobs
                $("#selectedJobs").toggleClass("open");
            },
            childEvents: {
                'update:jobcount': function (childView, collection) {
                    if (collection.length > 0) {
                        // a la carte campaign
                        $("#campaign-job-count").val(collection.length);
                    } else {
                        // dynamic campaign
                        $("#campaign-job-count").val($("#jobs tbody tr").length);
                    }

                    $(".selected-job-count").text($("#campaign-job-count").val());
                },
                'uncampaign:job': function (childView, job) {
                    this.triggerMethod('uncampaign:job', job);
                }
            }
        });

        /* New campaign layout */
        View.NewCampaign = Marionette.LayoutView.extend({
            template: newCampaignTpl,
            tagName: "div",
            className: "newCampaignScreen",

            regions: {
                locations: "#locations",
                occupations: "#occupations",
                future: "#future",

                form: ".new-campaign-form",
                filters: ".filters",
                content: ".filterContent",

                errorRegion: ".form-errors",

                campaignedJobs: "#selectedJobs > .row > .col-xs-12 > div",

                customerBudgetInfo: "#customerBudgetInfo"
            },
            ui: {
                campaignType: ".new-campaign-type",
                selectedJobCount: ".selected-job-count",
                alacarteButton: ".new-campaign-type > button[data-type='alacarte']",
                dynamicButton: ".new-campaign-type > button[data-type='dynamic']",
            },
            events: {
                "click .new-campaign-type > button": "switchCampaignType",
                "click .selectedToggle": "toggleSelectedJobs"
            },
            childEvents: {
                'update:jobcount': function (childView, collection) {
                    this.ui.selectedJobCount.text(collection.length);

                    // trigger a budget recalculation
                    $("#campaign-ppc").trigger("change");
                },
                'uncampaign:job': function (childView, job) {
                    this.triggerMethod('uncampaign:job', job);
                }
            },
            switchCampaignType: function (e) {
                e.preventDefault();

                // don't do anything if they clicked the button that is already active
                if ($(e.target).hasClass("active")) { return; }

                $(e.target).parent().children().toggleClass("active");
                $(this.ui.selectedJobCount).text(0);
                
                this.triggerMethod("switch:campaign:type", this);
            },
            toggleSelectedJobs: function (e) {
                e.preventDefault();

                // toogle collapse button icon
                $(".selectedToggle").toggleClass("fa-angle-right fa-angle-down");

                // toggle showing the selected jobs
                $("#selectedJobs").toggleClass("open");
            }
        });

        View.NewCampaignForm = Marionette.ItemView.extend({
            template: formTpl,
            tagName: "form",
            attributes: {
                "id": "newCampaignForm",
                "role": "form"
            },
            ui: {
                campaignName: "#campaign-name",
                campaignCriteria: ".campaign-criteria",
                campaignJobCount: "#campaign-job-count",
                locationId: "#campaign-location",
                occupationId: "#campaign-occupation",
                ppcAmount: "#campaign-ppc",
                budget: "#campaign-budget",
                submitButton: ".btn-campaign",
                getPPCRecommendation: "#get-ppc-recommendation",
                campaignType: "#campaign-is-dynamic"
            },
            events: {
                "click .campaign-close": "uncampaign",
                "submit": "createCampaign",
                'click @ui.getPPCRecommendation': 'getPPCRecommendation',
                "mouseover .dateRange": "datepicker_datetimepicker"
            },
            modelEvents: {
                "change:isdynamic": "changeCampaignType"
            },
            datepicker_datetimepicker: function (ev) {
                $('#createStartDate').datepicker({ autoclose: true, startDate: '-0d', clearBtn: true })
                    .on("changeDate", function () {
                        if ($("#createStartDate").datepicker('getFormattedDate').length > 0) {
                            $('#createEndDate').datepicker('setStartDate', $('#createStartDate').datepicker('getFormattedDate'));
                        } else {
                            $('#createEndDate').datepicker('setStartDate', '-0d');
                        }
                    });
                $('#createEndDate').datepicker({ autoclose: true, startDate: '-0d', clearBtn: true })
                    .on("changeDate", function () {
                        $('#createStartDate').datepicker('setEndDate', $('#createEndDate').datepicker('getFormattedDate'));
                    });
            },
            changeCampaignType: function () {
                if (this.model.get("isdynamic")) {
                    this.ui.getPPCRecommendation.removeClass("hidden");
                } else {
                    this.ui.getPPCRecommendation.addClass("hidden");
                }
                
                this.ui.campaignType.val(this.model.get("isdynamic"));
            },
            formReset: function () {
                // no need to reset the form if it isn't shown
                if ($(this.$el).is(":hidden")) { return; }

                this.ui.campaignName.val("");
                this.ui.campaignJobCount.val("");
                this.ui.campaignCriteria.empty();
                this.ui.ppcAmount.val("");
                this.ui.budget.val("");
                this.ui.submitButton.removeClass("disabled");

                // remove any form errors
                $('.form-group, .input-group').removeClass('has-error');
                $('.tab-pane.active .form-errors').hide();

                // reactivate the filter box
                $('.tab-pane.active .filter-box').removeAttr("disabled");
            },
            uncampaign: function (e) {
                e.preventDefault();

                // reset the selected card
                $("li.card a i.fa-check-square-o").toggleClass("fa-plus-circle fa-check-square-o");

                // unhighlight the selected card
                $("li.card.selected").removeClass("selected");

                // reset the form values
                $(e.target).parent().remove();
                this.ui.campaignJobCount.val("");

                this.formReset();
                this.hideForm();
            },
            createCampaign: function (e) {
                e.preventDefault();
                $('.btn-campaign').addClass('disabled');
                var data = Backbone.Syphon.serialize(this);
                this.trigger("form:submit", data);
            },
            hideForm: function () {
                // hide the form
                $(this.$el).addClass("hidden");
            },
            getPPCRecommendation: function (e) {
                e.preventDefault();

                // if it is an a la carte campaign just return out of here
                if (!this.model.get("isdynamic")) { return false; }

                var locs = this.model.get("locations") || [],
                    occs = this.model.get("occupations") || [];

                // see if they have 1 loc/occ or have selected multiple  
                if ((locs.length > 1) || (occs.length > 1)) {
                    // multiple selected, get the default ppc
                    this.trigger("show:recommendations");
                } else if ((locs.length == 1) || (occs.length == 1)) {
                    // only one selected, use them to get the recommendation, like always
                    this.trigger("show:recommendations", { location: locs[0], occupation: occs[0] });
                } else {
                    // they haven't chosen anything, just return the highest
                    this.trigger("show:recommendations");
                }
            },
            templateHelpers: function () {
                var todaysDate = moment().utc().format('MM/DD/YYYY');
                return {
                    startDate: todaysDate
                };
            }
        });

        View.Card = Marionette.ItemView.extend({
            template: cardTpl,
            tagName: "li",
            className: "card pull-left",
            initialize: function (options) {
                (this.model.get("selected")) ? this.$el.addClass('selected') : null;
            },
            events: {
                "click a" : "campaignItem",
                "click": "campaignItem"
            },
            ui: {
                campaignToggle: "i",
                tabForm: ".tab-pane.active form"
            },
            attributes: function () {
                return {
                    "data-type-id": this.model.id
                };
            },
            modelEvents: {
                "change:selected": "modelSelectionChanged"
            },
            campaignItem: function (e) {
                e.preventDefault();
                e.stopPropagation();

                // highlight the selected card
                this.$el.toggleClass("selected");

                if (this.$el.hasClass("selected")) {
                    this.model.set("selected", true);
                } else {
                    this.model.set("selected", false);
                }
            },
            modelSelectionChanged: function () {
                this.triggerMethod("update:criteria", this);
            }
        });

        View.Cards = Marionette.CompositeView.extend({
            template: cardsTpl,
            className: "clearfix",
            childView: View.Card,
            childViewContainer: ".cards",
            childEvents: {
                "update:criteria": function (args) {
                    // get the number of selected items
                    //var selected = this.collection.where({ selected: true }).length
                    this.triggerMethod("update:form", { model: args.model }); //, selected: selected });
                }
            },
            viewComparator: "name",
            initialize: function(options) {
                this.modelType = options.modelType;
                this.customer = options.customer;
                this.form = options.form;
            },
            ui: {
                cardsTitle: "h4 span",
                filterBox: ".filter-box"
            },
            templateHelpers: function () {
                return {
                    items: this.collection.length,
                    modelType: this.modelType,
                    title: "", //_.str.toSentence([this.collection.length, this.modelType, this.model.get("name")], " ", " in "),
                    customerId: this.customer.get("id")
                };
            },
            events: {
                "keyup @ui.filterBox": "filterCards",
                "click .form-control-clear": "clearFilter",
                "click .campaign-all": "campaignAll",
                "click .campaign-none": "campaignNone"
            },
            collectionEvents: {
                //"filter": "collectionChanged"
            },
            filter: function (child, index, collection) {
                //return (child.get('all_jobs') !== 0) && (child.get("type") == this.modelType.toLowerCase().split('s')[0]);
                return (child.get("type") == this.modelType.toLowerCase().split('s')[0]);
            },
            filterCards: function (e) {
                var term = $(this.ui.filterBox).val().toLowerCase();
                _.debounce(this.trigger("filter:cards", term), 300);
            },
            clearFilter: function (e) {
                e.preventDefault();

                if (this.ui.filterBox.val() == '') { return; }
                if (this.ui.filterBox.attr('disabled') !== undefined) { return; }

                this.ui.filterBox.val('');
                //this.ui.filterBox.trigger('keyup');
                this.filterCards();
            },
            collectionChanged: function () {
                //this.ui.cardsTitle.text(_.str.toSentence([this.collection.length, this.modelType, this.model.get("name")], " ", " in "));
            },
            campaignAll: function (e) {
                e.preventDefault();

                var c = this.collection;
                _.each($("li.card:visible"), function (ele, index, list) {
                    // mark all the items shown as selected

                    // toggle the cards to indicate selected state
                    $(ele).addClass("selected");

                    // get the data-type-id
                    var item = _.findWhere(c.models, { id: Number($(ele).attr("data-type-id")) });
                    item.set("selected", true);
                });
            },
            campaignNone: function (e) {
                e.preventDefault();
                
                var c = this.collection;
                _.each($("li.card:visible"), function (ele, index, list) {
                    // mark all the items shown as unselected

                    // toggle the cards to indicate unselected state
                    $(ele).removeClass("selected");

                    // get the data-type-id
                    var item = _.findWhere(c.models, { id: Number($(ele).attr("data-type-id")) });
                    item.set("selected", false);
                });
            }
        });
        /* End new agency work */
        
    });

    return CommandCenter.CampaignsApp.New.View;
});