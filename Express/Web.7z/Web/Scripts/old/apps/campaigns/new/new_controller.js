define(["app", "apps/campaigns/new/new_view","moment", "selectize"], function (CommandCenter, View,moment) {
    CommandCenter.module("CampaignsApp.New", function (New, CommandCenter, Backbone, Marionette, $, _) {
        New.Controller = {

            /* buildNewCampaign */
            buildNewCampaign: function(id) {
                require(['common/views','wookmark', 'models/Customer', 'backbone.fetch-cache', 'lib/backbone.virtual-collection', 'datepicker', 'chosen'], function (CommonViews,Wookmark) {
                    var fetchingCustomer = CommandCenter.request("customer:entity", id),
                        newCampaign = CommandCenter.request("campaign:entity:new"),
                        baseView = new View.NewCampaign({ customerId: id }),
                        formView = new View.NewCampaignForm({ model: newCampaign }),
                        //selectedFilters = new Backbone.Collection,
                        //filterView = new View.Filters({ collection: selectedFilters }),
                        newCollection = new Backbone.Collection(null),
                        vCollection = new Backbone.VirtualCollection(newCollection, {
                            filter: function (model) {
                                return model.get('all_jobs') !== 0;
                            }
                        }),
                        fCollection = new Backbone.VirtualCollection(newCollection, {
                            filter: function (model) {
                                return model.get('selected') == true;
                            }
                        }),
                        filterView = new View.Filters({ collection: fCollection }),
                        customer,
                        fetchingList,
                        chained,
                        location_options = {
                            baseview: baseView,
                            contentview: 'locations',
                            list: 'locations',
                            modeltype: 'Location',
                            cards: 'location:occupations',
                            cardtype: 'Location',
                            container: 'ul.cards',
                            form: formView
                        },
                        occupation_options = {
                            baseview: baseView,
                            contentview: 'occupations',
                            list: 'occupations',
                            modeltype: 'Occupation',
                            cards: 'occupation:locations',
                            cardtype: 'Occupation',
                            container: 'ul.cards',
                            form: formView
                        };

                    baseView.on("show", function (e) {
                        baseView.form.show(formView);
                        baseView.filters.show(filterView);
                    });

                    baseView.on("childview:update:form", function (childview, options) {
                        // find the right panel to put the criteria (loc, occ, job)
                        if (options.model.get("selected")) {
                            // add model to selectedFilters collection
                            //selectedFilters.add(options.model);

                            // append to the form
                            var arr = newCampaign.get(options.model.get("type") + "s");
                            arr = (arr === null) ? [] : arr;
                            arr.push(options.model.get("id"));
                            newCampaign.set(options.model.get("type") + "s", arr);
                            newCampaign.trigger("change:" + options.model.get("type") + "s");
                        } else {
                            // remove model from selectedFilters collection
                            //selectedFilters.remove(options.model);

                            // ensure the card model get updated
                            var cardModel = baseView.content.currentView.collection.findWhere({ id: options.model.get("id") });
                            if (cardModel !== undefined) {
                                cardModel.set("selected", false);
                            }

                            // ensure the filter model gets updated
                            var filtersModel = baseView.filters.currentView.collection.findWhere({ id: options.model.get("id") });
                            if (filtersModel !== undefined) {
                                filtersModel.set("selected", false);
                            }

                            // remove from the form
                            var obj = newCampaign.get(options.model.get("type") + "s");
                            var item = obj.indexOf(options.model.get("id"));
                            obj.splice(item, 1);
                            newCampaign.set(options.model.get("type") + "s", obj);
                            newCampaign.trigger("change:" + options.model.get("type") + "s");
                        }
                    });

                    baseView.on("switch:campaign:type", function (view) {
                        // remove the views from the filters and content regions
                        //baseView.filters.reset();
                        newCollection.reset(null);
                        baseView.filters.destroy();
                        if (baseView.content.hasView()) {
                            baseView.content.currentView.destroy();
                        }

                        // clear the error region
                        baseView.errorRegion.reset();
                        $('.form-group, .input-group').removeClass('has-error');

                        // ensure the selected locations and occupations are reset
                        customer.locations().reset(null);
                        customer.occupations().reset(null);
                        //selectedFilters.reset(null);
                        newCampaign.jobs().reset(null);

                        // reset the ppc and the budget
                        formView.ui.ppcAmount.val("");
                        formView.ui.budget.val("");;

                        $('#selectedJobs, .selectedJobsToggle').toggleClass('hidden');

                        // what is the campaign type
                        var cType = $(view.ui.campaignType).find("> button.active").attr("data-type");
                        switch (cType) {
                            case "dynamic":
                                newCampaign.set("isdynamic", true);
                                baseView.filters.show(new View.Filters({ collection: fCollection }));
                                break;
                            case "alacarte":
                                newCampaign.set("isdynamic", false);
                                New.Controller.alaCarteCampaign({ customer: id, baseview: baseView });
                                break;
                        };
                    });

                    baseView.filters.on("show", function () {
                        var callback;
                        $('#filters').on('show.bs.collapse', function (e) {
                            vCollection.updateFilter(function (model) {
                                return model.get('all_jobs') !== 0;
                            });

                            switch (e.target.id) {
                                case "collapseLocation":
                                    callback = New.Controller.getData(customer, location_options);
                                    break;
                                case "collapseOccupation":
                                    callback = New.Controller.getData(customer, occupation_options);
                                    break;
                            }

                            $.when(callback).then(function (c) {
                                // put into virtual collection to make sorting / filtering easier
                                newCollection.add(c.objects);
    
                                cardView = new View.Cards({ collection: vCollection, modelType: ((c.objects.length == 1) ? c.options.cardtype : _.str.join('', c.options.cardtype, 's')), customer: customer, form: c.options.form });
                                cardView.on("show", function () {
                                    wookmark = new Wookmark(c.options.container, {
                                        offset: 10, // Optional, the distance between grid items
                                        //flexibleWidth: '100%', // Optional, the maximum width of a grid item
                                        //itemWidth: '25%',
                                        autoResize: true, // This will auto-update the layout when the browser window is resized.
                                        //container: $('.content-cards ul'), // Optional, used for some extra CSS styling
                                        fillEmptySpace: false
                                    });
    
                                    cardView.on("filter:cards", function (args) {
                                        if (args.length == 0) {
                                            vCollection.updateFilter(function (model) {
                                                return model.get('all_jobs') !== 0;
                                            });
                                        } else {
                                            vCollection.updateFilter(function (model) {
                                                return model.get('name').toLowerCase().indexOf(args) != -1;
                                            });
                                        }
    
                                        wookmark.initItems();
                                        wookmark.layout(true);
                                    });
                                });
    
                                baseView.content.show(cardView);
                            });
                        });

                        $('#filters').on('hide.bs.collapse', function (e) {
                            //baseView.content.empty();
                            baseView.content.reset();
                        });
                    });

                    formView.on("show:recommendations", function (options) {
                        var loc = null,
                            occ = null;

                        if (options !== undefined) {
                            loc = options.location;
                            occ = options.occupation;
                        }

                        CommandCenter.CampaignsApp.New.Controller.getRecommendations(formView, { location: loc, occupation: occ });
                    });

                    formView.on("form:submit", function (data) {
                        var cId = data.customer;

                        // compile the list of jobids (a la carte only)
                        var jobs = newCampaign.jobs().models;
                        if (jobs.length > 0) {
                            data.jobids = _.pluck(jobs, "id");
                        }

                        // hide the form errors
                        $('.form-group, .input-group').removeClass('has-error');

                        // validate campaign data
                        var me = this;
                        var options = {
                            success: function (model, response, options) {
                                // clear the error region
                                baseView.errorRegion.reset();

                                // clear the campaigns from cache
                                Backbone.fetchCache.clearItem("api/customers/" + cId);

                                // reset the form to allow for rapid creation
                                $(me.$el)[0].reset();
                                $('.btn-campaign').removeClass('disabled');
                                // remove the location and occupation array hidden fields
                                $(me.$el).find('input:hidden[id*="-locations"], input:hidden[id*="-occupations"]').remove();
                                // reset the panels
                                $('#filters .panel-heading .panel-title a').attr('aria-expanded', false).addClass('collapsed');
                                $('#filters .panel-collapse').removeClass('in');
                                //selectedFilters.reset(null);
                                newCollection.reset(null);

                                //Reset DatePicker
                                $('#createEndDate').datepicker('clearDate');
                                $('#createStartDate').datepicker('setStartDate', '-0d');

                                newCampaign.set('locations', null);
                                newCampaign.set('occupations', null);

                                customer.locations().reset(null);
                                customer.occupations().reset(null);

                                if (baseView.content.hasView()) {
                                    // reset the filter content area to be empty
                                    if (baseView.content.currentView.collection !== undefined) {
                                        _.each(baseView.content.currentView.collection.models, function (val, key, list) {
                                            if (val.get("selected")) {
                                                val.set("selected", false);
                                            }
                                        });
                                    }
                                    baseView.content.currentView.destroy();
                                    baseView.content.reset();
                                }

                                // make sure it is reset to a new campaign, this keeps bindings in tack
                                newCampaign.clear().set(newCampaign.defaults);

                                // reload the default screen (dynamic campaign) since the form is reset to isdynamic = true
                                baseView.ui.dynamicButton.trigger('click');

                                baseView.errorRegion.show(new View.FormMessages({ messages: [{ message: "Campaign created successfully." }] }));
                                // set an interval to hide the success messages
                                window.setTimeout(function () {
                                    if (baseView.getRegion("errorRegion") !== undefined) {
                                        baseView.errorRegion.reset();
                                    }
                                }, 3000);
                            },
                            error: function (model, response, options) {
                                // requires errors response from the server to get here
                                $('.btn-campaign').removeClass('disabled');
                                $('.form-errors').show();

                                var serverErrors = response.responseJSON;
                                var errorMessages = serverErrors.ExceptionMessage;
                                if (!errorMessages) {
                                    errorMessages = (!serverErrors.Message) ? "An Error has occured on the Server" : serverErrors.Message;
                                }

                                baseView.errorRegion.show(new View.FormErrors({ errors: [{ name: "", message: errorMessages }] }));
                            }
                        };

                        // client-side validation
                        Backbone.listenTo(newCampaign, 'invalid', function (model, errors, options) {
                            $('.has-error').removeClass('has-error');
                            _.each(errors, function (error) {
                                var controlGroup = $('[name="' + error.name + '"]').parent();
                                controlGroup.addClass('has-error');
                            }, this);

                            $('.btn-campaign').removeClass('disabled');
                            $('.form-errors').show();

                            baseView.errorRegion.show(new View.FormErrors({ errors: errors }));
                        });

                        newCampaign.save(data, options);
                    }); // end on form:submit

                    $.when(fetchingCustomer).done(function (data) {
                        customer = data;

                        // setup the new campaign
                        newCampaign.set({ customer: customer.get("id") });
                        // show base view
                        CommandCenter.contentRegion.show(baseView);
                        //show customer Budget Info
                        var customerBudgetInfo = new CommonViews.CustomerBudgetInfo({ model: customer });
                        baseView.customerBudgetInfo.show(customerBudgetInfo);
                    });
                }); // end require
            },
            /* end buildNewCampaign */

            /* getData:: get a customers job locations */
            getData: function(customer, options) {
                var fetchingList,
                    chained,
                    listView,
                    id = customer.get("id"),
                    wookmark,
                    container = options.container,
                    $container = $(container),
                    cardView;

                var dfd = $.Deferred();

                var getAllListItems = CommandCenter.request(options.cardtype.toLowerCase() + ":entities");
                chained = $.when(getAllListItems).then(function (items) {
                    options.allItems = items;

                    return customer.get(options.list).fetch({ cache: true });
                });

                $.when(chained).done(function (datalist) {
                    // merge all and customer locations into a virtual collection
                    var newArray;
                    newArray = _.map(options.allItems.models, function (val, key) {
                        var itemFound = _.findWhere(datalist.models, { id: val.get("id") });
                        if (itemFound !== undefined) {
                            return itemFound;
                        } else {
                            return val;
                        }
                    });
                    
                    dfd.resolve({ objects: newArray, options: options });
                }); // end fetching datalist

                return dfd.promise();
            },
            /* end getData */

            /* a la carte campaigning */
            alaCarteCampaign: function (args) {
                require(['common/views', 'models/Campaign', 'models/Job', 'backbone.fetch-cache'], function (CommonViews) {
                    var id = args.customer,
                        baseview = args.baseview,
                        newCampaign = baseview.form.currentView.model,
                        filterView = new View.Filter({ customerId: id }),
                        locView,
                        socView,
                        aLaCarte = new View.ALaCarte();

                    // loading data view
                    var loadingView = new CommonViews.Loading();
                    baseview.content.show(loadingView);
                    
                    var fetchingCustomer = CommandCenter.request("customer:entity", id);
                    $.when(fetchingCustomer).done(function (customer) {
                        var fetchingLocations = customer.get('locations').fetch({ cache: true }),
                            fetchingOccupations;
                        var chained = $.when(fetchingLocations).then(function (locs) {
                            locView = new CommonViews.Locations({ collection: locs, customerId: customer.id });

                            locView.on("show:jobs", function (args) {
                                args.selectedJobs = newCampaign.jobs();
                                CommandCenter.CampaignsApp.New.Controller.showJobs(aLaCarte, args);
                            });

                            locView.on("show:recommendations", function (options) {
                                CommandCenter.CampaignsApp.New.Controller.getRecommendations(null, { location: options.location, occupation: options.occupation });
                            });

                            filterView.locs.show(locView);
                            return customer.get('occupations').fetch({ cache: true });
                        });

                        chained.done(function (socs) {
                            socView = new CommonViews.Occupations({ collection: socs, customerId: customer.id });

                            socView.on("show:jobs", function (args) {
                                args.selectedJobs = newCampaign.jobs();
                                CommandCenter.CampaignsApp.New.Controller.showJobs(aLaCarte, args);
                            });

                            socView.on("show:recommendations", function (options) {
                                CommandCenter.CampaignsApp.New.Controller.getRecommendations(null, { location: options.location, occupation: options.occupation });
                            });

                            filterView.socs.show(socView);



                            $select0 = $('#select-location').selectize({
                                create: false,
                                valueField: 'id',
                                labelField: 'name',
                                sortField: {
                                    field: 'name',
                                    direction: 'asc'
                                },
                                dropdownParent: 'body',
                                searchField: 'name',
                                render: {

                                    option: function (item, escape) {
                                        var label = item.name;
                                        var caption = item.name;
                                        return '<div class="locDD">' +
                                             escape(label) + '</div>';
                                    }
                                }
                            });

                            $select1 = $('#select-occupation').selectize({
                                create: false,
                                valueField: 'id',
                                labelField: 'name',
                                sortField: {
                                    field: 'name',
                                    direction: 'asc'
                                },
                                dropdownParent: 'body',
                                searchField: 'name',
                                render: {

                                    option: function (item, escape) {
                                        var label = item.name;
                                        var caption = item.name;
                                        return '<div class="occDD">' +
                                             escape(label) + '</div>';
                                    }
                                }
                            });




                        //   alert('Document Ready Reading from same source');
                        //$(function () {
                        //        console.log('Document Ready');

                        //        $(".selectize-dropdown-content").each(function () {

                        //            console.log($(this));
                        //        });

                        //        $(".locDD").each(function (index, element) {
                        //            console.log(index + element);
                        //            console.log($(this));
                        //            $(element).attr("id", index);

                        //            console.log($(".locDD").length);
                        //            $('.selectize-dropdown-content:eq(1)').attr("whichBlock", "locBlock");
                        //        });
                        //    });








                        });

                        baseview.filters.show(filterView);
                    });

                    filterView.on("show", function () {
                        baseview.content.show(aLaCarte);
                        baseview.campaignedJobs.show(new View.CampaignedJobs({ collection: newCampaign.jobs() }));
                    });
                   
                    aLaCarte.on("childview:job:selected", function (childView, item) {
                        newCampaign.jobs().add(item.job.model);
                    });

                    aLaCarte.on("childview:job:unselected", function (childView, item) {
                        newCampaign.jobs().remove(item.job.model);
                    });

                    baseview.on("childview:job:unselected", function (childView, item) {
                        newCampaign.jobs().remove(item.job.model);
                    });
                }); // end require
            },
            /* end a la carte campaigning */

            showJobs: function (layout, args) {
                if (args.jobcount <= 500 || args.showTheJobs) {
                    // show the jobs
                    require(['common/views', 'models/Job'], function (CommonViews) {
                        // loading data view
                        var loadingView = new CommonViews.Loading({
                            title: "Loading Job Data",
                            message: "Please wait while the job data is loading."
                        });
                        layout.jobsRegion.show(loadingView);

                        var fetchingJobs = CommandCenter.request("job:entities", args.customer, args.location, args.occupation);
                        $.when(fetchingJobs).done(function (jobs) {
                            // see if the user has already put the job in the campaign
                            if (args.selectedJobs.length > 0) {
                                // user has selected jobs to be campaigned
                                var selected = _.pluck(args.selectedJobs.models, 'id');
                                var available = _.pluck(jobs.models, 'id');
                                var alreadySelected = _.intersection(selected, available);
                                _.each(alreadySelected, function (jId) {
                                    jobs.findWhere({ id: jId }).set("selectedForCampaign", true);
                                });
                            }

                            var jobsView = new View.Jobs({ collection: jobs, customerId: args.customer });
                            layout.jobsRegion.show(jobsView);

                            layout.on("childview:uncampaign:job", function (childview, args) {
                                if (jobs.get(args.job.model) !== undefined) {
                                    jobs.get(args.job.model).set("selectedForCampaign", false);
                                }
                            });

                            $("table").tablesorter({ debug: false });

                            // populate the job count in the new campaign form
                            if ($("#selectedJobs tbody tr").length == 0) {
                                $("#campaign-job-count").val(jobs.length).trigger("change");
                            }
                        });
                    });
                } else {
                    // clear the jobs, if currently shown
                    layout.jobsRegion.empty();

                    // show a button to confirm they want to load the volume of data
                    require(['common/views'], function (CommonViews) {
                        var areYouSureView = new CommonViews.AreYouSure({ customerId: args.customer, location: args.location, occupation: args.occupation, jobcount: args.jobcount });
                        layout.jobsRegion.show(areYouSureView);

                        areYouSureView.on("show:jobs", function (args) {
                            args.selectedJobs = CommandCenter.request("campaign:entity:new").jobs();
                            args.showTheJobs = true;
                            CommandCenter.CampaignsApp.New.Controller.showJobs(layout, args);
                        });
                    });
                }
            },

            getRecommendations: function (layout, args) {
                var field;
                field = (layout == null) ? field = '#campaign-ppc' : $(layout.$el).find('#campaign-ppc');

                require(['models/Recommendation'], function () {
                    var fetchingRecommendations = CommandCenter.request("recommendation:entity", args.location, args.occupation);
                    $.when(fetchingRecommendations).done(function (recommendations) {
                        // populate the recommended ppc
                        $(field).val(numeral(recommendations.get('ppc')).format('0,0.00')).trigger("change");
                    }).fail(function () {
                        //console.log("DEFERRED FAILED");
                        $(field).val("");
                    });
                });
            }
        } // end New.Controller
    });

    return CommandCenter.CampaignsApp.New.Controller;
});