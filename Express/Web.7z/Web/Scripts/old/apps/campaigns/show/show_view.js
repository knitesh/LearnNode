﻿define(["app",
        "tpl!apps/campaigns/show/templates/noJobs.html",
        "tpl!apps/campaigns/show/templates/layout.html",
        "tpl!apps/campaigns/show/templates/info.html",
        "tpl!apps/campaigns/show/templates/stats.html",
        "tpl!apps/campaigns/show/templates/jobs.html",
        "tpl!apps/campaigns/show/templates/job.html",
        "tpl!apps/campaigns/show/templates/view.html",
        "chartjs",
        "underscore-string"],
      function (CommandCenter, noDataTpl, layoutTemplate, infoTemplate, statsTemplate, jobsTemplate, jobDetailTemplate, viewTemplate) {
          CommandCenter.module("CampaignsApp.Show.View", function (View, CommandCenter, Backbone, Marionette, $, _) {
              View.Layout = Marionette.LayoutView.extend({
                  template: layoutTemplate,
                  tagName: "div",
                  className: "row",
                  regions: {
                      campaignInfo: "#campaignInfo",
                      campaignStats: "#campaignStats",
                      campaign: "#campaignPerformance",
                      campaignJobs: "#campaignJobs"
                  }
              });

              View.Campaign = Marionette.ItemView.extend({
                  template: viewTemplate,
                  tagName: "div",
                  className: "row",
                  events: {
                      "click .chart-timeframe > a": "changeChartTimeframe"
                  },
                  changeChartTimeframe: function (e) {
                      e.preventDefault();

                      $(e.target).siblings().removeClass("active disabled");
                      $(e.target).addClass("active disabled");

                      this.trigger("reloadChartData", $(e.target).attr("data-content"));
                  }
              });

              View.NoData = Marionette.ItemView.extend({
                  template: noDataTpl,
                  tagName: "tr",

                  title: "We're sorry, no items exist.",
                  message: "",

                  serializeData: function () {
                      return {
                          title: Marionette.getOption(this, "title"),
                          message: Marionette.getOption(this, "message")
                      }
                  }
              });

              View.CampaignJob = Marionette.ItemView.extend({
                  template: jobDetailTemplate,
                  tagName: "tr",
                  className: function() {
                      return (!this.model.get('active')) ? "text-muted" : "";
                  },

                  initialize: function (options) {
                      this.jobclicklimit = options.jobclicklimit;
                  },

                  templateHelpers: function () {
                      return {
                          jobclicklimit: this.jobclicklimit
                      }
                  }
              });

              View.CampaignJobs = Marionette.CompositeView.extend({
                  tagName: "div",
                  className: "row",
                  template: jobsTemplate,
                  initialize: function (options) {
                      this.jobclicklimit = options.jobclicklimit;
                  },

                  childView: View.CampaignJob,
                  childViewContainer: "tbody",
                  childViewOptions: function (model, index) {
                      return {
                          jobclicklimit: this.jobclicklimit
                      }
                  },

                  getEmptyView: function () {
                      return View.NoData;
                  },
                  emptyViewOptions: {
                      title: "No jobs currently exist in the campaign.",
                      message: ""
                  },

                  viewComparator: function (item) {
                      return [!item.get("isactiveincampaign"), item.get("title")]
                  }
              });

              View.CampaignInfo = Marionette.ItemView.extend({
                  template: infoTemplate,
                  tagName: "div",
                  className: "row",
                  initialize: function (options) {
                      this.customer = options.customer.get('company');
                  },
                  templateHelpers: function () {
                      return {
                          showDescription: function () {
                              var locs = this.locations || [],
                                  occs = this.occupations || [];

                              return ((locs.length <= 1) && (occs.length <= 1));
                          },
                          locationString: _.chain(this.model.get("locations")).sortBy('Name').pluck('Name').value().join(", "),
                          occupationString: _.chain(this.model.get("occupations")).sortBy('Name').pluck('Name').value().join(", "),
                          isCampaignFeedEnabled: this.customer.campaignfeedenabled,
                          noCriteria: function () {
                              var locs = this.locations || [],
                                  occs = this.occupations || [];

                              return ((locs.length == 0) && (occs.length == 0)) ? true : false;
                          }
                      }
                  },
                  events: {
                      "click .delete-campaign": "deleteCampaign",
                      "click i[class*='fa-toggle']": "toggleText",
                      "click .truncated-text": "toggleText"
                  },
                  deleteCampaign: function (e) {
                      e.preventDefault();
                      CommandCenter.request("campaign:delete", this.model);
                  },
                  toggleText: function (e) {
                      e.preventDefault();

                      var obj;
                      obj = ($(e.target).hasClass('truncated-text')) ? $(e.target) : $(e.target).parent();
                      obj.toggleClass("truncated");
                      obj.find('.fa').toggleClass("fa-toggle-right fa-toggle-down");
                  }
              });

              View.CampaignStats = Marionette.ItemView.extend({
                  template: statsTemplate,
                  tagName: "div",
                  className: "row",
                  initialize: function (options) {
                      this.customer = options.customer.get('company');
                  },
                  templateHelpers: function () {
                      var budget = this.model.get('budget');
                      return {
                          pctComplete: numeral(budget.realized / budget.total).format('0%'),
                          pctUnformatted: (budget.realized / budget.total) * 100,
                          isCampaignFeedEnabled: this.customer.campaignfeedenabled,
                          dailyCapsProgressTemplate: function (usedDailyCaps) {
                              if (usedDailyCaps === null) {
                                  usedDailyCaps = 0;
                              } 
                              usedDailyCaps = Math.floor(numeral(usedDailyCaps));
                              
                              return (
                                  '<div class="daily-provider-progress progress"><div id="dailyCapsProgressBar" class="progress-bar daily-progress-bar-info progress-bar-striped" role="progressbar" ' +
                                      'aria-valuenow=' + usedDailyCaps + ' aria-valuemin="0" aria-valuemax="100" style="width : ' + usedDailyCaps + '%" ></div></div><label>' +
                                      usedDailyCaps + '% Daily Cap Used </label>');
                          }
                      }
                  },
                  onDomRefresh: function () {
                      if ((!this.customer.campaignfeedenabled) && ($(this.$el).find("#budget-chart").parent().css("display") !== "none")) {
                          var that = this;
                          var budget = this.model.get('budget');
                          var doughnut_overrides = {
                              animationSteps: 20,
                              percentageInnerCutout: 82,
                              segmentShowStroke: true,
                              showTooltips: false,
                              //responsive: true,
                              onAnimationComplete: function () {
                                  var chart = $("#budget-chart");

                                  canvasObj.font = "1.6em 'Helvetica Neue', Helvetica, Arial, sans-serif";
                                  canvasObj.textBaseline = "middle";
                                  canvasObj.fillStyle = "#333";

                                  var canvasWidth = $(chart).width(),
                                      canvasHeight = $(chart).height(),
                                      chartText = numeral(budget.realized / budget.total).format('0%'),
                                      textWidth = canvasObj.measureText(chartText).width,
                                      textPosX = Math.round((canvasWidth - textWidth) / 2);

                                  canvasObj.fillText(chartText, textPosX, (canvasHeight / 2));
                              }
                          };

                          var pctComplete = (budget.realized / budget.total);
                          var pctLeft = (1 - pctComplete);
                          var data = [
                              { value: pctComplete, color: "#F7464A", highlight: "#FF5A5E", label: "Red" },
                              { value: ((pctLeft > 0) ? pctLeft : 0), color: "#d3d3d3" }
                          ];
                          // chart.js donut charts
                          // Get context with jQuery - using jQuery's .get() method.
                          var canvasObj = $(this.$el).find("#budget-chart").get(0).getContext("2d");
                          var chartObj = new Chart(canvasObj).Doughnut(data, doughnut_overrides);
                      }
                  }
              });
          });

          return CommandCenter.CampaignsApp.Show.View;
      });