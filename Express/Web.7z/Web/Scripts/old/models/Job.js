﻿define(['app','localstorage'],
    function (CommandCenter) {
        CommandCenter.module("Models", function (Models, CommandCenter, Backbone, Marionette, $, _) {
            Models.Job = Backbone.Model.extend({
                urlRoot: "api/jobs",

                defaults: {
                    title: "",
                    selectedForCampaign: false
                }
            });

            Models.JobsCollection = Backbone.Collection.extend({
                url: function () {
                    var url = "",
                        baseUrl = 'api/customers/';

                    if (this.locationId != null) {
                        url += '/locations/' + this.locationId;
                    }

                    if (this.occupationId != null) {
                        url += '/occupations/' + this.occupationId;
                    }

                    return baseUrl + this.customerId + url + '/jobs';
                },
                model: Models.Job,
                comparator: "title",
                initialize: function (models, options) {
                    this.customerId = options.customerId;
                    this.locationId = options.locationId;
                    this.occupationId = options.occupationId;
                }
            });

            Models.CampaignJobs = Backbone.Collection.extend({
                localStorage: new Backbone.LocalStorage("CampaignJobs"),
                model: Models.Job
            });

            var CampaignJobs = new Models.CampaignJobs();

            var API = {
                getJobEntity: function (jobId) {
                    //console.log("getJobEntity:: " + jobId);
                },

                getJobEntities: function (companyId, locationId, occupationId) {
                    var jobs = new Models.JobsCollection([], { customerId: companyId, locationId: locationId, occupationId: occupationId });
                    var defer = $.Deferred();
                    jobs.fetch({
                        success: function (data) {
                            defer.resolve(data);
                            //defer.resolveWith(data, [customers]);
                        }
                    });

                    return defer.promise();
                },
            };

            CommandCenter.reqres.setHandler("job:entity", function (id) {
                return API.getJobEntity(id);
            });

            CommandCenter.reqres.setHandler("job:entities", function (companyId, locationId, occupationId) {
                return API.getJobEntities(companyId, locationId, occupationId);
            });

            //CommandCenter.reqres.setHandler("campaigned:jobs", function () {
            //    return CampaignJobs;
            //});

            /*
            CommandCenter.reqres.setHandler("is:campaigned:job", function (job) {
                var retVal = false;
    
                if (CampaignJobs.findWhere({ id: job.get("id") }) !== undefined) {
                    job.set("selectedForCampaign", true);
                    retVal = true;
                }
    
                return retVal;
            });
            */

            //CommandCenter.reqres.setHandler("remove:campaigned:jobs", function () {
            //    CampaignJobs.reset();
            //});

            //CommandCenter.reqres.setHandler("select:job", function (job) {
            //    job.set("selectedForCampaign", true);
            //    CampaignJobs.add(job);
            //    return CampaignJobs;
            //});

            //CommandCenter.reqres.setHandler("unselect:job", function (job) {
            //    job.set("selectedForCampaign", false);
            //    CampaignJobs.remove(job);
            //    return CampaignJobs;
            //});
        });

        return;
    });
