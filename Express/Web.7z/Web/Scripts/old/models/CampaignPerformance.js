﻿define(['app'],
    function (CommandCenter) {
        CommandCenter.module("Models", function (Models, CommandCenter, Backbone, Marionette, $, _) {
            Models.CampaignPerformance = Backbone.Model.extend({
                urlRoot: "api/campaigns",

                defaults: {
                    name: ""
                }
            });

            Models.CampaignPerformanceCollection = Backbone.Collection.extend({
                //url: function () { return '/api/campaigns/' + this.campaignId + '/performance'; },
                model: Models.CampaignPerformance//,
                //initialize: function (models, options) {
                //    this.campaignId = options.campaignId;
                //}
            });

            var API = {
                getCampaignPerformance: function () {
                    var defer = $.Deferred();
                    var performance = new Models.CampaignPerformanceCollection();
                    performance.fetch({
                        // TODO: cache these?
                        success: function (data) {
                            defer.resolve(data);
                        }
                    })
                    return defer.promise();
                }
            };

            //CommandCenter.reqres.setHandler("location:entities", function () {
            //    return API.getCampaignPerformance();
            //});
        });

        return;
    });
