﻿define(['app'],
    function (CommandCenter) {
        CommandCenter.module("Models", function (Models, CommandCenter, Backbone, Marionette, $, _) {
            Models.Occupation = Backbone.Model.extend({
                urlRoot: "api/occupations",

                defaults: {
                    name: "",
                    agg_jobs: 0,
                    ppc_jobs: 0,
                    all_jobs: 0,
                    "type": "occupation",
                    selected: false
                    //locations: []
                },

                initialize: function () {
                    //this.locations = new Models.OccupationLocationCollection(this.get('locations'));
                    //this.locations.url = function () {
                    //    return self.url() + '/locations';
                    //};
                }
            });

            Models.OccupationCollection = Backbone.Collection.extend({
                url: "api/occupations",
                model: Models.Occupation,
                comparator: "name"
            });

            Models.CustomersOccupationsCollection = Backbone.Collection.extend({
                model: Models.Occupation
            });

            Models.OccupationLocationCollection = Backbone.Collection.extend({
                url: function () { return 'api/customers/' + this.customerId + '/occupations/' + this.occupationId + '/locations'; },
                //model: Models.Location,
                initialize: function (models, options) {
                    this.customerId = options.customerId;
                    this.occupationId = options.occupationId;
                }
            });

            var API = {
                getAllOccupations: function () {
                    var defer = $.Deferred();
                    var occupations = new Models.OccupationCollection();
                    occupations.fetch({
                        // TODO: cache these?
                        success: function (data) {
                            defer.resolve(data);
                        }
                    })
                    return defer.promise();
                },

                getOccupationEntity: function (occupationId) {
                    //console.log("getOccupationEntity:: " + occupationId);
                },

                getOccupationLocations: function (customerId, occupationId) {
                    var locs = new Models.OccupationLocationCollection([], { customerId: customerId, occupationId: occupationId });
                    var defer = $.Deferred();
                    locs.fetch({
                        success: function (data) {
                            defer.resolve(data);
                            //defer.resolveWith(data, [customers]);
                        },
                        error: function (data) {
                            defer.resolve(undefined);
                        }
                    });

                    return defer.promise();
                }
            };

            CommandCenter.reqres.setHandler("occupation:entities", function () {
                return API.getAllOccupations();
            });

            CommandCenter.reqres.setHandler("occupation:entity", function (id) {
                return API.getOccupationEntity(id);
            });

            CommandCenter.reqres.setHandler("occupation:locations", function (customerId, occId) {
                return API.getOccupationLocations(customerId, occId);
            });
        });

        return;
    });
