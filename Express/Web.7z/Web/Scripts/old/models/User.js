﻿define(['app'],
    function (CommandCenter) {
        CommandCenter.module("Models", function (Models, CommandCenter, Backbone, Marionette, $, _) {
            Models.User = Backbone.Model.extend({
                defaults: {
                    userName: "",
                    given_name: "",
                    family_name: "",
                    expires: "",
                    roles: []
                },
                urlRoot: "api/user"
            });

            //CommandCenter.loggedInUser = new Models.User();

            Models.UserCollection = Backbone.Collection.extend({
                url: "/api/user",
                model: Models.User
            });

            var API = {
                getUserRoles: function () {
                    var defer = $.Deferred();
                    CommandCenter.loggedInUser.fetch({
                        cache: true,
                        success: function (data) {
                            defer.resolve(data);
                        },
                        error: function (data) {
                            defer.resolve(undefined);
                            //defer.reject(undefined);
                        }
                    });
                    return defer.promise();
                }
            };

            CommandCenter.reqres.setHandler("user:roles", function () {
                return API.getUserRoles();
            });

            CommandCenter.reqres.setHandler("user:entity", function () {
                return CommandCenter.loggedInUser;
            });
        });

        return;
    });