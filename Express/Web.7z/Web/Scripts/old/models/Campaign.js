define(['app',
    'moment',
    'lib/backbone.virtual-collection',
    'lib/backbone.associate',
    'models/Job',
    'models/CampaignPerformance'],
    function (CommandCenter, moment) {
        CommandCenter.module("Models",
            function (Models, CommandCenter, Backbone, Marionette, $, _) {
                Models.Campaign = Backbone.Model.extend({
                    urlRoot: "api/campaigns",

                    defaults: {
                        name: "",
                        description: "",
                        locations: null,
                        occupations: null,
                        ppc: 0,
                        jobcount: null,
                        jobclicklimit: 250,
                        budget: 0,
                        jobids: null,
                        jobs: null,
                        isdynamic: true,
                        startdate: null,
                        enddate: null,
                        iscampaignfeedenabled: false,
                        futuredailycap: 0,
                        campaignCap: {
                            futureCap: 0,
                            dailyCap: 0
                        },
                        campaignCriteria: [{
                            criteriaKey: null,
                            criteriaCondition: null,
                            criteriaValue: null
                        }]
                    },

                    validate: function (attrs, options) {

                        //Close Campaign
                        if (attrs['CampaignStatusID'] === 4) {
                            return false;
                        }
                        var errors = [],
                            isDynamic = (String(attrs['isdynamic']) === "true");

                        var iscampaignFeed = attrs['iscampaignfeedenabled'];
                        // campaign name is required
                        if (attrs['name'] === "") {
                            if (!iscampaignFeed) {
                                errors.push({ name: 'name', message: 'Campaign name is required.' });
                            }
                        }

                        //campaign start date is require
                        if (attrs['startdate'] === "" || attrs['startdate'] === null) {

                            errors.push({ name: 'startdate', message: 'Campaign start date is required.' });

                        }

                        //campaign start date should be equla to or greater than Todays Date
                        if (!attrs['isEdit']) {
                            //campaign start date should be equla to or greater than Todays Date
                            if (attrs['startdate'] !== "" || attrs['startdate'] !== null) {

                                var current = new Date().setHours(0, 0, 0, 0);;

                                if (moment(attrs['startdate']).local() < moment(current)) {
                                    errors.push({ name: 'startdate', message: 'Campaign Start Date needs to be greater or equal to current date.' });
                                }

                            }
                        }


                        // ppc price is required
                        if (!attrs['ppc'] || (numeral().unformat(attrs['ppc']) <= 0)) {
                            if (!iscampaignFeed) {
                                errors.push({ name: 'ppc', message: 'PPC is required and must be greater than $0.00.' });
                            }
                        }


                        // clicks per job is required and must be a number
                        if ((attrs['jobclicklimit'] == null) || !_.isNumber(Number(attrs['jobclicklimit'])) || (_.isNaN(Number(attrs['jobclicklimit'])))) {
                            if (!iscampaignFeed) {
                                errors.push({ name: 'jobclicklimit', message: 'Clicks Per Job is required.' });
                            }
                        } else if (attrs['jobclicklimit'] <= 0) {
                            if (!iscampaignFeed) {
                                errors.push({ name: 'jobclicklimit', message: 'Clicks Per Job must be greater than 0.' });
                            }
                        }

                        // budget is required and must be greater than 0
                        if (!attrs['budget']) {
                            if (!iscampaignFeed) {
                                errors.push({ name: 'budget', message: 'A budget is required.' });
                            }

                        } else if (numeral().unformat(attrs['budget']) <= 0) {
                            if (!iscampaignFeed) {
                                errors.push({ name: 'budget', message: 'Your budget must be greater than 0.' });
                            }
                        }
                        console.log(attrs['futuredailycap']);
                        if (attrs['futuredailycap']) {
                            var strCap = String(attrs['futuredailycap']);
                            if ((strCap) && !(/^[1-9]\d*(((,\d{3}){1})?(\.\d{0,2})?)$/.test(strCap))) {
                                errors.push({ name: 'futuredailycap', message: 'Daily Cap must be greater than 0.' });
                            }
                            else {
                                if (numeral().unformat(attrs['futuredailycap']) > 1000000) {
                                    errors.push({ name: 'futuredailycap', message: 'Daily Cap greater than $1,000,000.00 is not allowed' });
                                }
                            }
                        }

                        // a la carte campaigns have to have job(s) selected for inclusion
                        //No more applicable
                        //if (!isDynamic) {
                        //    if (attrs['jobs'].length == 0) {
                        //        errors.push({ name: "jobs", message: "You must select at least one job to include in your new campaign." });
                        //    }
                        //}

                        return (errors.length > 0) ? errors : false;
                    }
                });

                Models.CampaignJobsCollection = Backbone.Collection.extend({
                    model: Models.Job,
                    comparator: function (item) {
                        return item.get("title");
                    }
                });

                Backbone.associate(Models.Campaign, {
                    jobs: { type: Models.CampaignJobsCollection, url: '/jobs' },
                    performance: { type: Models.CampaignPerformance, url: '/performance' },
                    dailyCapPerformance: { type: Models.CampaignPerformance, url: '/dailyCapPerformance' }
                });

                Models.CampaignCollection = Backbone.Collection.extend({
                    url: "/api/campaigns",
                    model: Models.Campaign,

                    // sort models by status and name
                    comparator: function (item) {
                        return [item.get("active"), item.get("name")];
                    }
                });

                Models.Statuses = Backbone.Model.extend({
                    url: function () {
                        return "api/campaigns/" + this.get('id') + "/statuses/" + this.get('CampaignStatusID');
                    },
                    default: {
                        statuses: ""
                    }
                });

                Models.CustomersCampaignCollection = Backbone.Collection.extend({
                    //url: function() { return '/campaigns'; },
                    model: Models.Campaign,
                    comparator: function (first, second) {
                        if (first.get('ppc') > second.get('ppc')) {
                            return -1;
                        } else if (first.get('ppc') < second.get('ppc')) {
                            return 1;
                        } else {
                            if (first.get('name') > second.get('name')) {
                                return 1;
                            } else if (first.get('name') < second.get('name')) {
                                return -1;
                            } else {
                                return 0;
                            }
                        }
                    },
                    fetch: function (options) {
                        var statusID = 1;
                        switch (options.data.status) {
                            case "active":
                                statusID = 1;
                                break;
                            case "pending":
                                statusID = 2;
                                break;
                            case "inactive":
                                statusID = 3;
                                break;
                            case "completed":
                                statusID = 4;
                                break;
                            case "paused":
                                statusID = 5;
                                break;
                        };

                        var newUrl = this.url() + "/" + statusID;
                        options || (options = {});
                        options.data = {};
                        options.url = newUrl;
                        //var data = (options.data || {});

                        return Backbone.Collection.prototype.fetch.call(this, options);
                    },
                    getCacheKey: function (options) {
                        //var pos = options.url.lastIndexOf("/");
                        //return options.url.substring(0, pos);
                    }
                });

                var API = {
                    getCampaignEntity: function (campaignId) {
                        var campaign = new Models.Campaign({ id: campaignId });
                        var defer = $.Deferred();

                        campaign.fetch({
                            success: function (data) {
                                defer.resolve(data);
                            },
                            error: function (data) {
                                defer.resolve(undefined);
                            }
                        });

                        return defer.promise();
                    },

                    deleteCampaign: function (campaign) {
                        var customer = campaign.get("customerId");

                        // clear the campaign tab counts
                        Backbone.fetchCache.clearItem("api/customers/" + customer);

                        campaign.destroy({
                            success: function (model, response, options) {
                                CommandCenter.trigger("campaigns:list", customer);
                            },
                            error: function (model, response, options) {
                                //console.log("***UNSUCCESSFUL DESTROY***");
                            }
                        });
                    },
                    getCampaignStatuses: function (id, statusId) {

                        var statuses = new Models.Statuses({ id: id, CampaignStatusID: statusId });

                        var defer = $.Deferred();

                        statuses.fetch({
                            success: function (data) {
                                defer.resolve(data);
                            },
                            error: function (data) {
                                defer.resolve(undefined);
                            }
                        });

                        return defer.promise();
                    },
                    closeCampaign: function (campaign) {

                        var customerId = campaign.get("customerId");
                        Backbone.fetchCache.clearItem("api/customers/" + customerId);
                        var options = {
                            success: function (model, response, options) {
                                campaign.set("active", "Completed");
                                campaign.trigger('change', campaign);
                                CommandCenter.trigger("campaigns:list", customerId);
                            },
                            error: function (model, response, options) {
                                console.log("***Error Updating Status****" + JSON.stringify(response));
                            }
                        };
                        campaign.save({ CampaignStatusID: 4, Customer: customerId }, options);
                    }
                };

                CommandCenter.reqres.setHandler("campaign:entity", function (id) {
                    return API.getCampaignEntity(id);
                });

                CommandCenter.reqres.setHandler("campaign:entity:new", function (id) {
                    return new Models.Campaign();
                });

                CommandCenter.reqres.setHandler("campaign:delete", function (campaign) {
                    return API.deleteCampaign(campaign);
                });
                CommandCenter.reqres.setHandler("campaign:close", function (campaign) {
                    return API.closeCampaign(campaign);
                });
                CommandCenter.reqres.setHandler("campaign:statuses", function (id, statusId) {
                    return API.getCampaignStatuses(id, statusId);
                });
            });
        return;
    });
