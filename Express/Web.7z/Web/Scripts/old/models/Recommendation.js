﻿define(['app'],
    function (CommandCenter) {
        CommandCenter.module("Models", function (Models, CommandCenter, Backbone, Marionette, $, _) {
            Models.Recommendation = Backbone.Model.extend({
                urlRoot: function () {
                    var url = "",
                        baseUrl = '/api/recommendations';

                    if (this.locationId != null) {
                        url += '/locations/' + this.locationId;
                    }

                    if (this.occupationId != null) {
                        url += '/occupations/' + this.occupationId;
                    }

                    return baseUrl + url;
                },
                initialize: function (attributes, options) {
                    this.locationId = options.locationId;
                    this.occupationId = options.occupationId;
                },
                defaults: {}
            });

            Models.RecommendationsCollection = Backbone.Collection.extend({
                url: function () {
                    var url = "",
                        baseUrl = '/api/recommendations';

                    if (this.locationId != null) {
                        url += '/locations/' + this.locationId;
                    }

                    if (this.occupationId != null) {
                        url += '/occupations/' + this.occupationId;
                    }

                    return baseUrl + url;
                },
                model: Models.Recommendation,
                initialize: function (models, options) {
                    this.locationId = options.locationId;
                    this.occupationId = options.occupationId;
                }
            });

            var API = {
                getRecommendationEntity: function (locationId, occupationId) {
                    var recommendations = new Models.Recommendation(null, { locationId: locationId, occupationId: occupationId });
                    var defer = $.Deferred();
                    recommendations.fetch({
                        success: function (data) {
                            //defer.resolve(data);
                            defer.resolveWith(data, [recommendations]);
                        },
                        error: function (collection, response, options) {
                            //defer.resolve(undefined);
                            defer.reject(undefined);
                        }
                    });

                    return defer.promise();
                }
            };

            CommandCenter.reqres.setHandler("recommendation:entity", function (locationId, occupationId) {
                return API.getRecommendationEntity(locationId, occupationId);
            });
        });

        return;
    });
