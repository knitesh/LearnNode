﻿define(['app', 'moment'],
    function (CommandCenter, moment) {
        CommandCenter.module("Models", function (Models, CommandCenter, Backbone, Marionette, $, _) {
            Models.Report = Backbone.Model.extend({
                urlRoot: "api/report",
                defaults: function (id) {
                    var today = new Date();
                    var lastDayOfYear = new Date(today.getFullYear(), 11, 31);

                    return {
                        ProviderID: "",
                        ReportStartDate: "",
                        ReportEndDate: "",
                        IntervalBreakDown: "",
                        DataPointsRequested: {}
                    }
                },



                parse: function (response, options) {
                    // figure out if the report is expired
                    var today = new Date();
                    response["isExpired"] = (moment(response.expirationDate).unix() < moment(today).unix()) ? true : false;
                    return response;
                },

                validate: function (attrs, options) {
                    var errors = [];

                    // Report Type is required
                    if (!attrs['IntervalBreakDown']) {
                        errors.push({ name: 'IntervalBreakDown', message: 'A display interval is required' });
                    }

                    if (!attrs['ReportType']) {
                        errors.push({ name: 'ReportType', message: 'A Report Type is Required' });
                    }

                    // report type id is required
                    if (!attrs['ReportStartDate']) {
                        errors.push({ name: 'ReportStartDate', message: 'A "from date" must be selected' });
                    }

                    // report type id is required
                    if (!attrs['ReportEndDate']) {
                        errors.push({ name: 'ReportEndDate', message: 'A "to date" must be selected' });
                    }

                    // report type id is required
                    if (!attrs['DataPointsRequested']) {
                        errors.push({ name: 'DataPointsRequested', message: 'A data point must be selected' });
                    }



                    return (errors.length > 0) ? errors : false;
                }
            });

            Models.ReportCollection = Backbone.Collection.extend({
                url: function () {
                    return 'api/campaigns/' + this.customerId + '/reports';
                },
                model: Models.Report,
                initialize: function (models, options) {
                    this.ProviderID = options.customerId;
                },

                // sort models by expirationDate then activeDate
                comparator: function (item) {
                    //return [moment(item.get("expirationDate")).unix(), moment(item.get("activeDate")).unix()]
                    return -moment(item.get("expirationDate")).unix(), -moment(item.get("activeDate")).unix();
                }
            });

            var API = {
                getReportEntity: function (reportId) {
                    var report = new Models.Report({ id: reportId });
                    var defer = $.Deferred();

                    report.fetch({
                        success: function (data) {
                            defer.resolve(data);
                        },
                        error: function (data) {
                            defer.resolve(undefined);
                        }
                    });

                    return defer.promise();
                },

                getReportEntities: function (customerId) {



                    var data = [{
                        providername: "",
                        jobtitle: "",
                        jobadrefcode: "",
                        jobadid: "",
                        jobadpricingtypename: "",
                        activedate: "",
                        daysactive: "",
                        recommendedcostperclick: "",
                        cpc: "",
                        clicks: "",
                        Day: "",
                        Month: "",
                        Year: "",
                        Company: "",
                        cityname: "",
                        stateabbrev: "",
                        Location_ID_Name: "",
                        mescoid: "",
                        soc1occupationtitle: "",
                        soc2occupationtitle: "",
                        soc3occupationtitle: "",
                        campaignid: "",
                        CampaignName: "",
                        DaysinCampaign: ""
                    }]

                    return data;
                }
            };

            CommandCenter.reqres.setHandler("report:entity", function (id) {
                return API.getReportEntity(id);
            });

            CommandCenter.reqres.setHandler("report:entities", function (id) {
                return API.getReportEntities(id);
            });

            CommandCenter.reqres.setHandler("report:entity:new", function (id) {
                return new Models.Report();
            });

        });

        return;
    });