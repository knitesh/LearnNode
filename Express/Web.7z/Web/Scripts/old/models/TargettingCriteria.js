﻿define(['app'],
    function (commandCenter) {
        commandCenter.module("Models", function (Models, CommandCenter, Backbone, Marionette, $, _) {
            Models.TargetingCriteria = Backbone.Model.extend({
                urlRoot: "api/TargetingCriteria",

                defaults: {
                    Text: "",
                    Value: "",
                    selected: false
                }
            });

            Models.TargetingCriteriaKeyCollection = Backbone.Collection.extend({
                url: "/api/TargetingCriteria/Key",
                model: Models.TargetingCriteria,
                comparator: "value"
               
            });

            Models.CustomersTargetingCriteriaKeyCollection = Backbone.Collection.extend({
                url: function() { return '/api/customers/' + this.customerId + '/TargetingCriteria/Keys' },
                model: Models.TargetingCriteria,
                initialize: function (models, options) {
                    this.customerId = options.customerId;
                }
            });

            Models.TargetingCriteriaValueCollection = Backbone.Collection.extend({
                url: "/api/TargetingCriteria/Value",
                model: Models.TargetingCriteria,
                comparator: "Value"

            });

            Models.CustomersTargetingCriteriaValueCollection = Backbone.Collection.extend({
                url: function () { return 'api/customers/' + this.customerId + '/TargetingCriteria/' +this.keyname +'/Values'},
                model: Models.TargetingCriteria,
                initialize: function (models, options) {
                    this.customerId = options.customerId;
                    this.keyname = options.keyname;
                }
            });
            var api = {
                getAllTargetingCriteriaKey: function (customerId) {
                    var customersTargetingCriteriaKeyCollection = new Models.CustomersTargetingCriteriaKeyCollection([],{
                        customerId: customerId
                    });
                    var defer = $.Deferred();
                    customersTargetingCriteriaKeyCollection.fetch({
                        cache: false,
                        success: function(data) {
                            defer.resolve(data);
                        }
                    });
                    return defer.promise();
                },
                getAllTargetingCriteriaValueForGivenKey: function (customerId, keyname) {
                   
                    var customersTargetingCriteriaValueCollection = new Models.CustomersTargetingCriteriaValueCollection([],{
                        customerId: customerId,
                        keyname: keyname
                    });
                    var defer = $.Deferred();
                    customersTargetingCriteriaValueCollection.fetch({
                        cache: false,
                        success: function (data) {
                            defer.resolve(data);
                        }
                    });
                    return defer.promise();
                }
            };

            CommandCenter.reqres.setHandler("TargetingCriteria:key", function (customerId) {
                return api.getAllTargetingCriteriaKey(customerId);
            });

            CommandCenter.reqres.setHandler("TargetingCriteria:Key:Values", function (customerId, keyname) {
                return api.getAllTargetingCriteriaValueForGivenKey(customerId, keyname);
            });

          
        });

        return;
    });
