﻿define(['app', 'moment'], function (CommandCenter, moment) {
    CommandCenter.module("Models", function (Models, CommandCenter, Backbone, Marionette, $, _) {
        Models.Contract = Backbone.Model.extend({
            urlRoot: "api/contracts",
            idAttribute: "contractID",
            defaults: function () {
                return {
                    karmaID: "",
                    contractTypeID: "",
                    currencyID: 1,
                    activeDate: "",
                    expirationDate: "",
                    budgetAmount: "",
                    availableBudget: 0,
                    budgetSpent:0,
                    mid: "",
                    providerid: "",
                    isExpired: false,
                    networkCredit: [],
                    newNetworkCredit:[]
                }
            },

            parse: function (response, options) {
                // figure out if the contract is expired
                var today = new Date();
                response["isExpired"] = (moment(response.expirationDate).unix() < moment(today).unix()) ? true : false;
                return response;
            },

            validate: function (attrs, options) {
                var errors = [];
                // karma id is required
                if (!attrs['karmaID']) {
                    errors.push({ name: 'karmaID', message: 'A Karma ID is required.' });
                }

                // contract type id is required
                if (!attrs['contractTypeID']) {
                    errors.push({ name: 'contractTypeID', message: 'You must choose a contract type.' });
                }

                // budget is required
                if (!attrs['budgetAmount']) {
                    errors.push({ name: 'budgetAmount', message: 'You must specify a budget amount.' });
                }
                // budget should not be greater than $100000 -- database restriction required
                if (attrs['budgetAmount'] > 1000000) {
                    errors.push({ name: 'budgetAmount', message: 'You must specify a budget amount lesser or equal to $1,000,000.00' });
                }

                // date active is required
                if (!attrs['activeDate']) {
                    errors.push({ name: 'activeDate', message: 'A date the contract is active is required.' });
                }
                // date active should not be greater than 
                if (attrs["contractID"] && moment(this.attributes['activeDate']) < moment()) {
                    if (moment(attrs['activeDate']) > moment(this.attributes['activeDate'])) {
                        errors.push({
                            name: 'activeDate',
                            message: 'Active contract start date can not be changed to future.'
                        });
                    }
                }

                // date expires is required
                if (!attrs['expirationDate']) {
                    errors.push({ name: 'expirationDate', message: 'A date the contract expires is required' });
                }

                // date expires date should be in future is required
                if (moment(attrs['expirationDate']).isBefore(moment(), 'day') && attrs['newNetworkCredit']!==null && !attrs['newNetworkCredit'].length) {
                    errors.push({ name: 'expirationDate', message: 'Contract expire date cannot be in past.' });
                }

                // date expires date should be greater than active date
                if (moment(attrs['expirationDate']) < moment(attrs['activeDate'])  ) {
                    errors.push({ name: 'expirationDate', message: 'Contract expire date needs to be greater or equal to active date' });
                }

                //Validate Any Network Credit here
                //check If network credit is present
                if (attrs['newNetworkCredit']!==null && attrs['newNetworkCredit'].length) {
                    _.each(attrs['newNetworkCredit'],
                        function (item) {
                            // date expires date should be greater than active date
                            if (!item.Reason) {
                                errors.push({ name: 'reason', message: 'You must specify a reason for credit' });
                            }
                            if (!/^-?[0-9]\d*(((,\d{3}){1})?(\.\d{0,2})?)$/.test(item.credit)) {
                                errors.push({ name: 'credit', message: 'You must enter dollar amount as credit' });
                            }
                            if (item.credit > 1000000) {
                                errors.push({ name: 'credit', message: 'You must specify a Network credit amount lesser or equal to $1,000,000.00'});
                            }
                            if (moment(item.ExpirationDate) < moment(attrs['expirationDate'])) {
                                errors.push({ name: 'ncEndDate', message: 'You must specify a network credit end date greater or equal to contract end date.' });
                            }
                            if (moment(item.ExpirationDate).isBefore(moment(), 'day')) {
                                errors.push({ name: 'ncEndDate', message: 'You must specify a network credit end date in future.' });
                            }
                            if (!item.ExpirationDate) {
                                errors.push({ name: 'ncEndDate', message: 'You must specify a network credit end date.' });
                            }

                        });
                } else {
                    console.log('No Network Credit Present');
                }

                return (errors.length > 0) ? errors : false;
            }
        });

        Models.ContractCollection = Backbone.Collection.extend({
            url: function() {
                return 'api/contracts/customers/' + this.customerId  ;
            },
            model: Models.Contract,
            initialize: function (models, options) {
                this.customerId = options.customerId;
            },

            // sort models by expirationDate then activeDate
            comparator: function (item) {
                //return [moment(item.get("expirationDate")).unix(), moment(item.get("activeDate")).unix()]
                return -moment(item.get("expirationDate")).unix(), -moment(item.get("activeDate")).unix();
            }
        });

        var API = {
            getContractEntity: function (contractId) {
                var contract = new Models.Contract({ id: contractId });
                var defer = $.Deferred();

                contract.fetch({
                    success: function (data) {
                        defer.resolve(data);
                    },
                    error: function (data) {
                        defer.resolve(undefined);
                    }
                });

                return defer.promise();
            },

            getContractEntities: function (customerId) {
                var contracts = new Models.ContractCollection([], { customerId: customerId });
                var defer = $.Deferred();

                contracts.fetch({
                    cache: false,
                    //prefill: true,
                    prefillSuccess: function (data) {
                        //console.log("CONTRACT FETCH prefillSuccess");
                    },
                    success: function (data) {
                        defer.resolve(data);
                        //defer.resolveWith(data, [customers]);
                    },
                    error: function (data) {
                        defer.resolve(undefined);
                    }
                });

                return defer.promise();
            }
        };

        CommandCenter.reqres.setHandler("contract:entity", function (id) {
            return API.getContractEntity(id);
        });

        CommandCenter.reqres.setHandler("contract:entities", function (id) {
            return API.getContractEntities(id);
        });

        CommandCenter.reqres.setHandler("contract:entity:new", function () {
            return new Models.Contract();
        });

    });

    return;
});