﻿using Monster.JobAds.Auditing;
using Monster.JobAds.Auditing.Authentication.AD;
using Monster.JobAds.CommandCenter.Web.App_Start;
using Monster.JobAds.CommandCenter.Helpers;
using Monster.JobAds.Logging;
using System.IdentityModel.Services;
using System.Reflection;
using System.Security.Claims;
using System.Threading;
using System.Web;
using System.Web.Helpers;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace Monster.JobAds.CommandCenter.Web
{
    public class MvcApplication : HttpApplication
    {
        //private readonly HandleApplicationErrors _handleApplicationErrors = new HandleApplicationErrors(typeof(ErrorController), "Index"/*All other errors action name*/, "NotFound"/*404 action name*/);

        protected void Application_Start()
        {
            const string APP_NAME = "commandCenter";

            Application.Set("BUILD_VERSION", Assembly.GetExecutingAssembly().GetName().Version.ToString());
            AntiForgeryConfig.UniqueClaimTypeIdentifier = ClaimTypes.NameIdentifier;

            JobAdsLogFactory.Current.Initialize(APP_NAME);
            AuditContextProviderFactory.Current.Default = new MemberClaimAuditContextProvider();

            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }

        protected void Application_PostAuthenticateRequest()
        {
            ClaimsAuthenticationManager transformer = FederatedAuthentication.FederationConfiguration.IdentityConfiguration.ClaimsAuthenticationManager;
            if (transformer == null)
            {
                return;
            }
            if (Request.IsAuthenticated)
            {
                ClaimsPrincipal newPrincipal = transformer.Authenticate(string.Empty, ClaimsPrincipal.Current);

                Thread.CurrentPrincipal = newPrincipal;
                HttpContext.Current.User = newPrincipal;
            }
            else
            {
                ((CustomClaimsAuthenticationManager)transformer).Signout();
            }
        }

        /*
        protected void Application_Error()
        {
            Exception exception = Server.GetLastError();
            Server.ClearError();

            HttpContextBase httpContext = new HttpContextWrapper(Context);

            try
            {
                _handleApplicationErrors.HandleApplicationError(exception, httpContext);
            }
            catch (Exception ex)
            {
                var logger = JobAdsLogFactory.Current.GetLogger();
                logger.LogError(ex);
            }
        }
        */
    }
}
